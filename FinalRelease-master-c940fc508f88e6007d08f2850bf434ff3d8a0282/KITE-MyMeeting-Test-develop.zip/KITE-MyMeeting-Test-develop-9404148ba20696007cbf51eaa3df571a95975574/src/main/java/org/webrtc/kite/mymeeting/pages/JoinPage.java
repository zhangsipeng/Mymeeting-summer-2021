package org.webrtc.kite.mymeeting.pages;

import io.cosmosoftware.kite.interfaces.Runner;
import io.cosmosoftware.kite.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import static io.cosmosoftware.kite.util.TestUtils.waitAround;

public class JoinPage extends BasePage {

  public JoinPage(Runner runner) {
    super(runner);
  }

  public void open(String url) {
    loadPage(url, 5);
  }

  public void createMeeting(Integer roomId) {
    WebElement createMeetingButton =
        webDriver.findElement(
            By.xpath(
                "/html/body/div[1]/div/div/div[1]/div/div/div/div/div[2]/div[2]/div/div/div/div[1]/div/div[2]/div[1]/div[1]/div"));
    createMeetingButton.click();
    waitAround(1000);

    WebElement displayName =
        webDriver.findElement(
            By.xpath(
                "/html/body/div[1]/div/div/div[2]/div/div[2]/div/div[1]/div[1]/div/div[2]/input"));
    displayName.sendKeys(roomId.toString());
    waitAround(1000);

    WebElement password =
        webDriver.findElement(
            By.xpath(
                "/html/body/div[1]/div/div/div[2]/div/div[2]/div/div[1]/div[2]/div/div[2]/input"));
    password.sendKeys("123");
    waitAround(1000);

    WebElement createButton =
            webDriver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div[2]/div/div[2]/div/div/div/div"));
    createButton.click();
  }
}
