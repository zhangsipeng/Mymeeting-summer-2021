package org.webrtc.kite.mymeeting.steps;

import io.cosmosoftware.kite.exception.KiteTestException;
import io.cosmosoftware.kite.interfaces.Runner;
import io.cosmosoftware.kite.steps.TestStep;
import org.webrtc.kite.mymeeting.pages.JoinPage;

import static io.cosmosoftware.kite.util.TestUtils.waitAround;

public class CreateMeetingStep extends TestStep {

  private final JoinPage joinPage;
  private final String url;
  private final Integer roomId;

  public CreateMeetingStep(Runner runner, String url, Integer roomId) {
    super(runner);
    this.joinPage = new JoinPage(runner);
    this.url = url;
    this.roomId = roomId;
  }

  @Override
  public String stepDescription() {
    return "Open Blank Page";
  }

  @Override
  protected void step() throws KiteTestException {
    joinPage.open(url);
    //    joinPage.createMeeting(roomId);
    waitAround(1000);
  }
}
