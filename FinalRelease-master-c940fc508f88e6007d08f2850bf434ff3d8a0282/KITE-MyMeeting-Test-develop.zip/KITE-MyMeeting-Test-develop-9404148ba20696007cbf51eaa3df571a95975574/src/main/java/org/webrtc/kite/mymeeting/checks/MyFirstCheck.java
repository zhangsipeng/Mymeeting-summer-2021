package org.webrtc.kite.mymeeting.checks;

import io.cosmosoftware.kite.exception.KiteTestException;
import io.cosmosoftware.kite.interfaces.Runner;
import io.cosmosoftware.kite.steps.TestCheck;

import static io.cosmosoftware.kite.util.ReportUtils.saveScreenshotPNG;
import static io.cosmosoftware.kite.util.TestUtils.waitAround;

public class MyFirstCheck extends TestCheck {

  public MyFirstCheck(Runner runner) {
    super(runner);
  }

  @Override
  public String stepDescription() {
    return "Nothing";
  }

  @Override
  protected void step() throws KiteTestException {
    waitAround(30000);
    int tries = 0;
    while (tries < 3) {
      try {
        reporter.screenshotAttachment(report, saveScreenshotPNG(webDriver));
        break;
      } catch (Exception e) {
        waitAround(1000);
        tries++;
      }
    }
  }
}
