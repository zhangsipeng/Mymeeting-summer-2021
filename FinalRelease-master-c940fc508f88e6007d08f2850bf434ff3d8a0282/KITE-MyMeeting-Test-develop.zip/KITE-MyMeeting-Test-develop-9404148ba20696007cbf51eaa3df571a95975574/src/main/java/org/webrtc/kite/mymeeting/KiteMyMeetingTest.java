package org.webrtc.kite.mymeeting;

import org.webrtc.kite.mymeeting.checks.MyFirstCheck;
import org.webrtc.kite.mymeeting.steps.CreateMeetingStep;
import org.webrtc.kite.mymeeting.steps.JoinRoomStep;
import org.webrtc.kite.mymeeting.steps.StartVideoStep;
import org.webrtc.kite.tests.KiteBaseTest;
import org.webrtc.kite.tests.TestRunner;

import java.util.Random;

// modify configs/mymeeting.config.json
// tupleSize: roomNumber
// participantsPerRoom
public class KiteMyMeetingTest extends KiteBaseTest {
  private final Integer roomId = new Random().nextInt(1000);
  private Integer participantsPerRoom = 5;

  @Override
  protected void payloadHandling() {
    super.payloadHandling();
    if (this.payload != null) {
      url = payload.getString("url") + "/meeting/";
      participantsPerRoom = payload.getInt("participantsPerRoom");
    }
  }

  @Override
  public void populateTestSteps(TestRunner runner) {
    Random random = new Random();
    Integer roomId = random.nextInt(10000);
    runner.addStep(new CreateMeetingStep(runner, "https://www.baidu.com", roomId));
    runner.addStep(new JoinRoomStep(runner, url, roomId, participantsPerRoom));
    runner.addStep(new StartVideoStep(runner));
    runner.addStep(new MyFirstCheck(runner));
  }
}
