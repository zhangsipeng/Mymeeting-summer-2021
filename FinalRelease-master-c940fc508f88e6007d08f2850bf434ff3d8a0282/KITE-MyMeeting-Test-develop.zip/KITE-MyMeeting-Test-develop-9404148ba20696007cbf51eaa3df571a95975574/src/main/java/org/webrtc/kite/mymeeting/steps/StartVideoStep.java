package org.webrtc.kite.mymeeting.steps;

import io.cosmosoftware.kite.exception.KiteTestException;
import io.cosmosoftware.kite.interfaces.Runner;
import io.cosmosoftware.kite.steps.TestStep;
import org.webrtc.kite.mymeeting.pages.MeetingPage;

import java.util.ArrayList;
import java.util.Random;

import static io.cosmosoftware.kite.util.ReportUtils.saveScreenshotPNG;
import static io.cosmosoftware.kite.util.TestUtils.waitAround;

public class StartVideoStep extends TestStep {
  private final MeetingPage meetingPage;

  public StartVideoStep(Runner runner) {
    super(runner);
    this.meetingPage = new MeetingPage(runner);
  }

  @Override
  public String stepDescription() {
    return "Open videos";
  }

  @Override
  protected void step() throws KiteTestException {
    ArrayList<String> tabs = new ArrayList<>(webDriver.getWindowHandles());
    tabs.remove(0);
    Random random = new Random();
    for (String tab : tabs) {
      int tries = 0;
      boolean succeed = false;
      while (tries < 5 && !succeed) {
        try {
          tries++;
          this.webDriver.switchTo().window(tab);
          waitAround(random.nextInt(2000));
          meetingPage.startVideo();
          waitAround(random.nextInt(2000));
          waitAround(2000);
          succeed = true;
        } catch (Exception e) {
          waitAround(1000);
        }
      }
      reporter.screenshotAttachment(report, saveScreenshotPNG(webDriver));
    }
  }
}
