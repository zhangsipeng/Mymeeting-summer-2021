package org.webrtc.kite.mymeeting.steps;

import io.cosmosoftware.kite.exception.KiteTestException;
import io.cosmosoftware.kite.interfaces.Runner;
import io.cosmosoftware.kite.steps.TestStep;
import org.openqa.selenium.JavascriptExecutor;
import org.webrtc.kite.mymeeting.pages.MeetingPage;

import java.util.ArrayList;
import java.util.Random;

import static io.cosmosoftware.kite.util.ReportUtils.saveScreenshotPNG;
import static io.cosmosoftware.kite.util.TestUtils.waitAround;

public class JoinRoomStep extends TestStep {

  private final MeetingPage meetingPage;
  private final String url;
  private final Integer roomId;
  private final Integer participantsPerRoom;

  public JoinRoomStep(Runner runner, String url, Integer roomId, Integer participantsPerRoom) {
    super(runner);
    this.meetingPage = new MeetingPage(runner);
    this.url = url;
    this.roomId = roomId;
    this.participantsPerRoom = participantsPerRoom;
  }

  @Override
  public String stepDescription() {
    return "Join " + url + roomId;
  }

  @Override
  protected void step() throws KiteTestException {
    Random random = new Random();
    for (int i = 0; i < participantsPerRoom; i++) {
      JavascriptExecutor js = (JavascriptExecutor) webDriver;
      String originalWindow = webDriver.getWindowHandle();
      js.executeScript("window.open('')");
      ArrayList<String> tabs = new ArrayList<>(webDriver.getWindowHandles());
      this.webDriver.switchTo().window(tabs.get(tabs.size() - 1));
      waitAround(random.nextInt(2000));
      meetingPage.joinMeeting(url + roomId + "?displayName=" + i);
      waitAround(random.nextInt(2000));
      waitAround(2000);
      int tries = 0;
      while (tries < 3) {
        try {
          reporter.screenshotAttachment(report, saveScreenshotPNG(webDriver));
          break;
        } catch (Exception e) {
          waitAround(1000);
          tries++;
        }
      }
    }
  }
}
