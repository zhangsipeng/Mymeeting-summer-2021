package org.webrtc.kite.mymeeting.pages;

import io.cosmosoftware.kite.interfaces.Runner;
import io.cosmosoftware.kite.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MeetingPage extends BasePage {

  public MeetingPage(Runner runner) {
    super(runner);
  }

  public void open(String url) {
    loadPage(url, 5);
  }

  public void joinMeeting(String url) {
    //    webDriver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "T");
    this.webDriver.get(url);
    WebDriverWait driverWait = new WebDriverWait(this.webDriver, 10);
    driverWait.until(
        driver ->
            ((JavascriptExecutor) driver)
                .executeScript("return document.readyState")
                .equals("complete"));
  }

  public void startVideo() {
    WebElement cameraButton =
        webDriver.findElement(
            By.xpath(
                "/html/body/div[1]/div/div/div[1]/div/div/div/div/div[2]/div[2]/div/div/div/div[1]/div/div/div/div[2]/div[2]/div/div/div/div[1]/div/div/div[3]/div/div[2]/div"));
    cameraButton.click();
  }
}
