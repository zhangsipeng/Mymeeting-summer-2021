import ReactNativeForegroundService from "@supersami/rn-foreground-service";
import { registerRootComponent } from "expo";
import "expo-dev-client";
import { Platform } from "react-native";
import "react-native-gesture-handler";
import App from "./App";

if (Platform.OS === "android") {
  ReactNativeForegroundService.register();

  require("@formatjs/intl-locale/polyfill");

  require("@formatjs/intl-datetimeformat/polyfill");
  require("@formatjs/intl-datetimeformat/locale-data/zh-Hans.js");

  require("@formatjs/intl-datetimeformat/add-golden-tz.js");

  if ("__setDefaultTimeZone" in Intl.DateTimeFormat) {
    Intl.DateTimeFormat.__setDefaultTimeZone(
      require("expo-localization").timezone
    );
  }
}

// registerRootComponent calls AppRegistry.registerComponent('main', () => App);
// It also ensures that whether you load the app in Expo Go or in a native build,
// the environment is set up appropriately
registerRootComponent(App);
