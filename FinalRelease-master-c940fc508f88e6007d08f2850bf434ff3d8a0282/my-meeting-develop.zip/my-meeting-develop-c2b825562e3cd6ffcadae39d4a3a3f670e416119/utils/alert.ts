import {
  Alert as NativeAlert,
  AlertButton,
  AlertOptions,
  Platform,
} from "react-native";

const alertPolyfill = (
  title: string,
  message?: string,
  buttons?: AlertButton[],
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  options?: AlertOptions
) => {
  // eslint-disable-next-line no-alert
  const result = window.confirm(message);

  if (result) {
    const confirmOption = buttons?.find(({ style }) => style !== "cancel");
    if (confirmOption && confirmOption.onPress) {
      confirmOption.onPress();
    }
  } else {
    const cancelOption = buttons?.find(({ style }) => style === "cancel");
    if (cancelOption && cancelOption.onPress) {
      cancelOption.onPress();
    }
  }
};

const Alert = Platform.OS === "web" ? alertPolyfill : NativeAlert.alert;

export default Alert;
