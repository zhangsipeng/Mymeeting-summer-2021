export function socketPromise(socket: CustomSocket) {
  return function request(method: string, data = {}) {
    return new Promise((resolve) => {
      socket.emit("request", { method, data }, resolve);
    });
  };
}
