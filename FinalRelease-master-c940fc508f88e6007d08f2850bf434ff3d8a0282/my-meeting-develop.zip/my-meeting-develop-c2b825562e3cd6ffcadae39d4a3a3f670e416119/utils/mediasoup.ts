import { Device } from "mediasoup-client";
import { RtpCapabilities } from "mediasoup-client/lib/RtpParameters";
import { Transport } from "mediasoup-client/lib/types";
import React from "react";
import { Socket } from "socket.io-client";

export const loadDevice = async (routerRtpCapabilities: RtpCapabilities) => {
  let device;
  try {
    device = new Device();
    await device.load({ routerRtpCapabilities });
    return device;
  } catch (error) {
    if ((error as Error).name === "UnsupportedError") {
      console.error("browser not supported");
    }
  }
  return null;
};

type MediasoupContextValue = {
  device: Device | null;
  socket:
    | (Socket & { request: (type: string, data?: {}) => Promise<any> })
    | null;
  consumerTransport: Transport | null;
};

export const MediasoupContext = React.createContext<MediasoupContextValue>({
  device: null,
  socket: null,
  consumerTransport: null,
});
