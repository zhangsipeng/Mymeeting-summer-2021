import {
  consumerStatus,
  downloadProgress,
  fileSize,
  producerStatus,
} from "../helpers";

describe("test consumerStatus", () => {
  test("correctly determines status", () => {
    expect(consumerStatus(undefined)).toBe(undefined);
    expect(consumerStatus(undefined)).toBe(undefined);
    expect(consumerStatus({ paused: true, closed: true })).toBe(false);
    expect(consumerStatus({ paused: true, closed: false })).toBe(false);
    expect(consumerStatus({ paused: false, closed: false })).toBe(true);
  });
});

describe("test producerStatus", () => {
  test("correctly determines status", () => {
    expect(producerStatus(undefined)).toBe(false);
    expect(producerStatus(undefined)).toBe(false);
    expect(producerStatus({ paused: true, closed: true })).toBe(false);
    expect(producerStatus({ paused: true, closed: false })).toBe(false);
    expect(producerStatus({ paused: false, closed: false })).toBe(true);
  });
});

describe("test fileSize", () => {
  test("properly handles exception", () => {
    expect(fileSize(-1)).toBe("未知");
  });

  test("correctly calculates file size", () => {
    expect(fileSize(0)).toBe("0.00 B");
    expect(fileSize(1023)).toBe("1023.00 B");
    expect(fileSize(1024)).toBe("1.00 KB");
    expect(fileSize(1024 * 1023)).toBe("1023.00 KB");
    expect(fileSize(1024 * 1024)).toBe("1.00 MB");
  });
});

describe("test downloadProgress", () => {
  test("properly handles exception", () => {
    expect(downloadProgress(null)).toBe("下载进度未知");
    expect(
      downloadProgress({ totalBytesExpectedToWrite: -1, totalBytesWritten: 1 })
    ).toBe("1.00 B / 未知");
    expect(
      downloadProgress({
        totalBytesExpectedToWrite: -1,
        totalBytesWritten: 1024,
      })
    ).toBe("1.00 KB / 未知");
  });

  test("correctly calculates download progress", () => {
    expect(
      downloadProgress({
        totalBytesExpectedToWrite: 1024,
        totalBytesWritten: 0,
      })
    ).toBe("0.00 / 1.00 KB");
    expect(
      downloadProgress({
        totalBytesExpectedToWrite: 1024,
        totalBytesWritten: 512,
      })
    ).toBe("0.50 / 1.00 KB");
  });
});
