import { NavigationProp } from "@react-navigation/core";
import { StackNavigationProp } from "@react-navigation/stack";
import * as FileSystem from "expo-file-system";
import { Consumer } from "mediasoup-client/lib/types";
import { Platform, PlatformOSType } from "react-native";

export const onMobile = Platform.OS === "android" || Platform.OS === "ios";

const UNITS = ["B", "KB", "MB", "GB", "TB"];

/**
 * 根据Consumer的暂停和关闭状态判断媒体状态
 * @return true为开启，false为关闭，undefined为异常
 */
export const consumerStatus = (consumer: Consumer | undefined) => {
  if (!consumer) {
    return undefined;
  }
  return !consumer.paused && !consumer.closed;
};

export const producerStatus = (producer: Producer | undefined) => {
  if (!producer) {
    return false;
  }
  return !producer.paused && !producer.closed;
};

/**
 * 根据字节数显示文件大小
 * @param size 字节数
 */
export const fileSize = (size: number): string => {
  if (size < 0) {
    return "未知";
  }
  let unitIndex = 0;
  while (size >= 1024) {
    size /= 1024;
    ++unitIndex;
  }
  return size.toFixed(2) + " " + UNITS[unitIndex];
};

/**
 * 根据已下载和总大小字节数显示文件下载进度
 */
export const downloadProgress = (
  progress?: FileSystem.DownloadProgressData
): string => {
  if (!progress) {
    return "下载进度未知";
  }
  let total = progress.totalBytesExpectedToWrite;
  if (total < 0) {
    return `${fileSize(progress.totalBytesWritten)} / 未知`;
  }
  let unitIndex = 0,
    base = 1,
    totalSize,
    unit;
  while (total >= 1024) {
    total /= 1024;
    base *= 1024;
    ++unitIndex;
  }
  totalSize = total.toFixed(2);
  unit = UNITS[unitIndex];
  const downloaded = Number(progress.totalBytesWritten / base).toFixed(2);
  return `${downloaded} / ${totalSize} ${unit}`;
};

export const goBack = (
  navigation: StackNavigationProp<any> | NavigationProp<any>
) => {
  if (navigation.canGoBack()) {
    navigation.goBack();
  } else {
    location.href = "/";
  }
};

export const getOrientation = (platform?: PlatformOSType): Orientation => {
  if (!platform || ["web", "windows", "macos"].includes(platform)) {
    return "landscape";
  }
  return "portrait";
};
