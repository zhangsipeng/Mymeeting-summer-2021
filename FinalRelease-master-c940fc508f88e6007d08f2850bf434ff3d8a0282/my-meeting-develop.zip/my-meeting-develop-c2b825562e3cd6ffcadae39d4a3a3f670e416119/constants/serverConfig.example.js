export const serverUrl = `http://elbIp:port/`;
