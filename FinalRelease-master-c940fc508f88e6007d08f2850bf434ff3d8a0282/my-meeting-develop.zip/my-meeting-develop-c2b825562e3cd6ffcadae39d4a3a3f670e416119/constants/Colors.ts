const tintColorLight = "#2f95dc";
const tintColorDark = "#fff";

export default {
  primary: "#3880ff",
  success: "#2dd36f",
  warning: "#ffc409",
  danger: "#eb445a",
  light: {
    text: "#000",
    background: "#fff",
    placeholder: "#aaa",
    ripple: "rgba(0, 0, 0, .2)",
    tint: tintColorLight,
    tabIconDefault: "#ccc",
    tabIconSelected: tintColorLight,
  },
  dark: {
    text: "#fff",
    background: "#000",
    ripple: "rgba(255, 255, 255, .2)",
    tint: tintColorDark,
    tabIconDefault: "#ccc",
    tabIconSelected: tintColorDark,
  },
};
