export enum ContentType {
  video = "video",
  audio = "audio",
}

export enum MediaType {
  webcam = "webcam",
  screen = "screen",
  audio = "audio",
}

export enum Role {
  Participant = "Participant",
  CoHost = "CoHost",
  Host = "Host",
}

export enum MeetingStatus {
  NotConnected = "未连接",
  Connecting = "连接中",
  Reconnecting = "重连中",
  Connected = "已连接",
  Error = "错误",
  KickedOut = "已被踢出",
  Ended = "已结束",
}
