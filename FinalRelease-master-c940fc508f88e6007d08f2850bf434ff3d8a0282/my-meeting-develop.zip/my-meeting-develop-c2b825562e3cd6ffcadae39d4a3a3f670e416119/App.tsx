import { Ionicons } from "@expo/vector-icons";
import { StatusBar } from "expo-status-bar";
import React from "react";
import "react-native-gesture-handler";
import {
  DarkTheme,
  DefaultTheme,
  Provider as PaperProvider,
} from "react-native-paper";
import { SafeAreaProvider } from "react-native-safe-area-context";
import Colors from "./constants/Colors";
import useCachedResources from "./hooks/useCachedResources";
import useColorScheme from "./hooks/useColorScheme";
import { MeetingContext } from "./hooks/useMeetingContainer";
import Navigation from "./navigation";

declare global {
  namespace ReactNativePaper {
    interface ThemeColors {
      success: string;
      warning: string;
      danger: string;
    }
  }
}

// For react-native-paper-dates
const iconNamePolyfill = (name: string) => {
  switch (name) {
    case "chevron-left":
      return "chevron-back-outline";
    case "chevron-right":
      return "chevron-forward-outline";
    case "chevron-up":
      return "chevron-up-outline";
    case "chevron-down":
      return "chevron-down-outline";
    case "keyboard-outline":
      return "keypad-outline";
    case "clock-outline":
      return "time-outline";
    default:
      return name;
  }
};

export default function App() {
  const isLoadingComplete = useCachedResources();
  const colorScheme = useColorScheme();
  const baseTheme = colorScheme === "dark" ? DarkTheme : DefaultTheme;
  const theme = {
    ...baseTheme,
    colors: {
      ...baseTheme.colors,
      primary: Colors.primary,
      success: Colors.success,
      warning: Colors.warning,
      danger: Colors.danger,
      background:
        colorScheme !== "dark"
          ? Colors.light.background
          : baseTheme.colors.background,
      placeholder:
        colorScheme !== "dark"
          ? Colors.light.placeholder
          : baseTheme.colors.placeholder,
    },
  };

  if (!isLoadingComplete) {
    return null;
  } else {
    return (
      <PaperProvider
        theme={theme}
        settings={{
          icon: (props) => (
            // @ts-ignore
            <Ionicons {...{ ...props, name: iconNamePolyfill(props.name) }} />
          ),
        }}
      >
        <SafeAreaProvider>
          <MeetingContext>
            <Navigation colorScheme={colorScheme} />
          </MeetingContext>
          <StatusBar />
        </SafeAreaProvider>
      </PaperProvider>
    );
  }
}
