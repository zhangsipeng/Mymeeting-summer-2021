import { useNavigation } from "@react-navigation/native";
import ReactNativeForegroundService from "@supersami/rn-foreground-service";
import * as Mediasoup from "mediasoup-client";
import { useRef } from "react";
import { Platform } from "react-native";
import { io } from "socket.io-client";
import { MeetingStatus, Role } from "../constants/enums";
import Alert from "../utils/alert";
import { goBack, onMobile } from "../utils/helpers";
import { loadDevice } from "../utils/mediasoup";
import { socketPromise } from "../utils/socketPromise";
import useChatManager from "./useChatManager";
import { MeetingContainer } from "./useMeetingContainer";
import useParticipantsManager from "./useParticipantsManager";
import usePeerManager from "./usePeerManager";
import useProducerManager from "./useProducerManager";
import axios from "axios";
import { serverUrl } from "../constants/serverConfig";

const useMeetingManager = () => {
  const navigation = useNavigation();

  const {
    socket,
    consumerTransport,
    producerTransport,
    meetingInfo: [meetingInfo, setMeetingInfo],
    producerInfo: [producerInfo, setProducerInfo],
    screenSharing: [screenSharing, setScreenSharing],
    meetingStatus: [, setMeetingStatus],
  } = MeetingContainer.useContainer();

  const producerManager = useProducerManager();
  const peerManager = usePeerManager();
  const chatManager = useChatManager();
  const participantsManager = useParticipantsManager();

  const reconnectCount = useRef(0);

  const createTransport = async (
    device: Mediasoup.types.Device,
    isConsumer: boolean
  ) => {
    if (!socket.current) {
      console.log("[Error] No socket");
      return;
    }
    console.log(
      `[Info] Creating ${isConsumer ? "consumer" : "producer"} transport...`
    );
    const transportData = await socket.current.request(
      "createWebRtcTransport",
      {
        forceTcp: false,
        rtpCapabilities: device.rtpCapabilities,
        consuming: isConsumer,
        producing: !isConsumer,
      }
    );
    if (transportData.error) {
      console.log("[Error] Can not get transport data: ", transportData.error);

      return;
    }

    const transport = isConsumer
      ? device.createRecvTransport(transportData)
      : device.createSendTransport(transportData);
    transport.on("connect", ({ dtlsParameters }, callback, errback) => {
      socket.current
        ?.request("connectWebRtcTransport", {
          transportId: transportData.id,
          dtlsParameters,
        })
        .then(callback)
        .catch(errback);
    });

    if (!isConsumer) {
      transport.on(
        "produce",
        async ({ kind, rtpParameters, appData }, callback, errback) => {
          try {
            const { id } = await socket.current?.request("produce", {
              transportId: transport.id,
              kind,
              rtpParameters,
              appData,
            });
            callback({ id });
          } catch (err) {
            errback(err);
          }
        }
      );
    }

    transport.on("connectionstatechange", async (state: string) => {
      switch (state) {
        case "connecting":
          break;
        case "connected": {
          console.log(
            `[Info] ${
              isConsumer ? "Consumer" : "Producer"
            } transport connected, receiving...`
          );
          break;
        }
        case "failed":
          console.log(
            `[Info] ${isConsumer ? "Consumer" : "Producer"} transport failed`
          );
          transport.close();
          break;

        default:
          break;
      }
    });
    if (isConsumer) {
      consumerTransport.current = transport;
    } else {
      producerTransport.current = transport;
    }
  };

  /**
   * 加入会议
   * @param roomId 房间号
   * @param displayName 用户名
   * @param password
   */
  const joinMeeting = async (
    roomId: string,
    displayName: string,
    password: string
  ) => {
    console.log("[Info] Joining a room...");
    console.log("[Info] Connecting socket...");
    setMeetingStatus(MeetingStatus.Connecting);
    const res = await axios.get(serverUrl + "getRoomServer/" + roomId);
    if (res.status === 404) {
      Alert("错误", res.data.message);
      goBack(navigation);
      return;
    }
    const { url } = res.data;

    socket.current = io(url, {
      path: "/server",
      transports: ["websocket"],
      query: {
        roomId,
        displayName,
        password,
      },
      reconnection: false,
    }) as CustomSocket;

    setUpSocket(displayName, password, url);
  };

  /**
   * 创建房间并加入会议
   * @param displayName 用户名
   * @param password
   */
  const createMeeting = async (displayName: string, password: string) => {
    console.log("[Info] Creating a room...");
    console.log("[Info] Connecting socket...");
    setMeetingStatus(MeetingStatus.Connecting);
    const res = await axios.get(serverUrl + "getAvailableServer");
    if (res.status === 404) {
      Alert("错误", res.data.message);
      goBack(navigation);
      return;
    }
    const { url } = res.data;

    socket.current = io(url, {
      path: "/server",
      transports: ["websocket"],
      query: {
        createRoom: "true",
        displayName,
        password,
      },
      reconnection: false,
    }) as CustomSocket;

    setUpSocket(displayName, password, url);
  };

  const setUpSocket = (displayName: string, password: string, url: string) => {
    if (!socket.current) {
      console.log("[Error] No socket");
      return;
    }
    socket.current.request = socketPromise(socket.current);
    socket.current.on("connect", async () => {
      setMeetingStatus(MeetingStatus.Connected);
    });
    init(displayName, password, url);
  };

  // TODO: fix reconnect
  const registerReconnectSocketEvent = (
    displayName: string,
    password: string,
    url: string
  ) => {
    socket.current?.on("connect", async () => {
      if (!socket.current) {
        console.log("[Error] No socket");
        return;
      }
      // restart transport
      const consumerIce = await socket.current.request("restartIce", {
        transportId: consumerTransport.current?.id,
      });
      consumerTransport.current?.restartIce(consumerIce);
      const producerIce = await socket.current.request("restartIce", {
        transportId: producerTransport.current?.id,
      });
      producerTransport.current?.restartIce(producerIce);
      // rejoin the room
      const { peers } = await socket.current.request("rejoin");
      peerManager.initPeers(peers);
    });
    init(displayName, password, url);
  };

  const init = (displayName: string, password: string, url: string) => {
    peerManager.init();
    producerManager.init();
    chatManager.init();
    participantsManager.init();
    showNotification();
    socket.current?.on(
      "notification",
      async (request: ServerNotificationType) => {
        switch (request.method) {
          case "serverReady": {
            // create device
            console.log("[Info] Creating device...");
            if (!socket.current) {
              console.log("[Error] No socket");
              return;
            }
            const capData = await socket.current.request(
              "getRouterRtpCapabilities"
            );
            const device = await loadDevice(capData);
            if (!device) {
              console.log("[Error] Creating device failed");
              return;
            }

            // create producer and consumer transport
            await createTransport(device, true);
            await createTransport(device, false);
            if (!producerTransport.current || !consumerTransport.current) {
              console.log("[Error] Creating transport failed");
              return;
            }

            // join the room
            let producerInfo: ProducerInfo = {
              displayName,
              role: Role.Participant,
              platform: Platform.OS,
              rtpCapabilities: device.rtpCapabilities,
              id: "unknown",
            };
            const { peers, role, peerId, roomId } =
              await socket.current.request("join", {
                displayName,
                platform: Platform.OS,
                rtpCapabilities: device.rtpCapabilities,
              });
            setProducerInfo({ ...producerInfo, id: peerId, role });
            setMeetingInfo({ roomId, password });

            // init all other managers
            peerManager.initPeers(peers);

            setMeetingStatus(MeetingStatus.Connected);

            // enable reconnect manually
            // TODO: reconnect multiple times & remove reconnection filed in query after implementing UUID
            socket.current.on("disconnect", (reason) => {
              // only reconnect when there is an Internet error
              if (
                reason === "io client disconnect" ||
                reason === "io server disconnect"
              ) {
                return;
              }
              peerManager.cleanUp();
              reconnectCount.current = 0;
              const intervalId = setInterval(async () => {
                if (socket.current?.connected) {
                  clearInterval(intervalId);
                  return;
                }
                if (reconnectCount.current > 3) {
                  clearInterval(intervalId);
                  cleanUp();
                  if (onMobile && navigation.canGoBack()) {
                    goBack(navigation);
                  } else if (!onMobile) {
                    goBack(navigation);
                  }
                }
                reconnectCount.current++;
                socket.current?.close();
                socket.current = io(url, {
                  path: "/server",
                  transports: ["websocket"],
                  query: {
                    peerId,
                    roomId,
                    displayName,
                    password: password,
                  },
                  reconnection: false,
                }) as CustomSocket;
                socket.current.request = socketPromise(socket.current);
                registerReconnectSocketEvent(displayName, password, url);
              }, 10000);
            });
            break;
          }
          case "kickedOut":
            Alert("通知", "主持人请您离开了会议");
            cleanUp();
            if (onMobile && navigation.canGoBack()) {
              goBack(navigation);
            } else if (!onMobile) {
              goBack(navigation);
            }
            break;
          case "meetingStopped":
            Alert("通知", "主持人结束了会议");
            cleanUp();
            if (onMobile && navigation.canGoBack()) {
              goBack(navigation);
            } else if (!onMobile) {
              if (onMobile && navigation.canGoBack()) {
                goBack(navigation);
              } else if (!onMobile) {
                goBack(navigation);
              }
            }
            break;
          default:
            break;
        }
      }
    );
    socket.current?.on("connect_error", (err) => {
      if (err instanceof Error) {
        Alert("错误", "连接失败");
      } else {
        cleanUp();
      }
      if (onMobile && navigation.canGoBack()) {
        goBack(navigation);
      } else if (!onMobile) {
        goBack(navigation);
      }
    });
  };

  const cleanUp = async () => {
    stopNotification();
    if (socket) {
      await socket.current?.request("exitMeeting");
      consumerTransport.current?.close();
      producerManager.closeAll();
      peerManager.cleanUp();
      screenSharing.consumer?.close();
      setScreenSharing({
        consumer: undefined,
        stream: undefined,
        peer: undefined,
        active: false,
      });
      socket.current?.disconnect();
    }
  };

  const stopMeeting = async () => {
    if (producerInfo?.role !== Role.Host) {
      return false;
    }
    const { status, message }: RequestResponse = await socket.current?.request(
      "stopMeeting"
    );
    if (status === "fail") {
      Alert("错误", message);
      return false;
    }
    return true;
  };

  const exitMeeting = async () => {
    cleanUp();
    if (onMobile && navigation.canGoBack()) {
      goBack(navigation);
    } else if (!onMobile) {
      goBack(navigation);
    }
  };

  const showNotification = () => {
    if (Platform.OS === "android" && Platform.constants.Version >= 29) {
      ReactNativeForegroundService.stop();
      ReactNativeForegroundService.start({
        id: 1,
        title: "MyMeeting",
        message: "会议进行中，点击此处返回会议",
      });
    }
  };

  const stopNotification = () => {
    if (Platform.OS === "android") {
      ReactNativeForegroundService.stop();
    }
  };

  return {
    joinMeeting,
    createMeeting,
    meetingInfo,
    stopMeeting,
    cleanUp,
    exitMeeting,
    screenSharing,
  };
};

export default useMeetingManager;
