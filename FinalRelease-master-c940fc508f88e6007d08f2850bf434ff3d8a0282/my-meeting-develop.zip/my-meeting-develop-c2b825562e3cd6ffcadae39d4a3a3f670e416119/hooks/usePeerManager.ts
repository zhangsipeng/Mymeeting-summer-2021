import { Consumer } from "mediasoup-client/lib/types";
import { MediaStream } from "react-native-webrtc-web-shim";
import { MediaType, Role } from "../constants/enums";
import { MeetingContainer } from "./useMeetingContainer";

const usePeerManager = () => {
  const {
    socket,
    consumerTransport,
    peers: [peers, setPeers],
    screenSharing: [screenSharing, setScreenSharing],
  } = MeetingContainer.useContainer();

  const initPeers = (peers: Array<PeerInfo>) => {
    setPeers(
      new Map(
        peers.map((peerInfo: PeerInfo) => [
          peerInfo.id,
          { ...peerInfo, stream: new MediaStream([]) },
        ])
      )
    );
  };

  /**
   * 初始化peers
   */
  const init = () => {
    socket.current?.on("request", async (request: ServerRequestType) => {
      switch (request.method) {
        case "newConsumer": {
          const {
            peerId,
            kind,
            rtpParameters,
            producerId,
            appData,
            id,
          }: NewConsumerRequestData = request.data;
          const consumerInfo: ConsumerInfo = {
            rtpParameters,
            producerId,
            id,
            kind,
          };
          if (!consumerTransport.current) {
            console.log("[Error] No consumer transport yet!");
            return;
          }
          addConsumer(
            peerId,
            await consumerTransport.current.consume(consumerInfo),
            appData.mediaType
          );
          break;
        }
        default: {
          break;
        }
      }
    });
    socket.current?.on("notification", (request: ServerNotificationType) => {
      switch (request.method) {
        case "newPeer": {
          addPeer(request.data);
          break;
        }
        case "peerClosed": {
          const { id } = request.data;
          removePeer(id);
          break;
        }
        case "consumerPaused": {
          const { consumerId, peerId } = request.data;
          updateConsumerState(peerId, consumerId, "paused");
          break;
        }
        case "consumerResumed": {
          const { consumerId, peerId } = request.data;
          updateConsumerState(peerId, consumerId, "playing");
          break;
        }
        case "consumerClosed": {
          const { consumerId, peerId } = request.data;
          updateConsumerState(peerId, consumerId, "closed");
          break;
        }
        case "peerRoleChanged": {
          const { peerId, role }: PeerRoleChangedRequestData = request.data;
          updateRole(peerId, role);
          break;
        }
        default: {
          break;
        }
      }
    });
  };

  /**
   * 加入新的peer
   * @param peerInfo 新加入的peer信息
   */
  const addPeer = (peerInfo: PeerInfo) => {
    setPeers((peers) =>
      new Map(peers).set(peerInfo.id, {
        ...peerInfo,
        stream: new MediaStream([]),
      })
    );
  };

  /**
   * 移除已退出的Peer
   * @param peerId
   */
  const removePeer = (peerId: string) => {
    setPeers((peers) => {
      peers.forEach((peer) => {
        peer.audioConsumer?.close();
        peer.videoConsumer?.close();
      });
      const newPeers = new Map(peers);
      newPeers.delete(peerId);
      return newPeers;
    });
  };

  /**
   * 更新用户角色信息
   * @param peerId
   * @param role
   */
  const updateRole = (peerId: string, role: Role) => {
    setPeers((peers) => {
      const peer = peers.get(peerId);
      if (!peer) {
        console.log("[Error] Unknown peerId: " + peerId);
        return peers;
      }
      peer.role = role;
      return new Map(peers).set(peerId, peer);
    });
  };

  /**
   * 将新的Consumer加入到相应Peer的数据结构中
   * @param peerId
   * @param consumer
   * @param mediaType
   */
  const addConsumer = (
    peerId: string,
    consumer: Consumer,
    mediaType: MediaType
  ) => {
    setPeers((peers) => {
      if (mediaType === MediaType.screen) {
        screenSharing.consumer?.close();
        const stream = new MediaStream([]);
        // @ts-ignore
        stream.addTrack(consumer.track);
        setScreenSharing({
          consumer,
          stream,
          peer: peers.get(peerId),
          active: true,
        });
        return peers;
      }
      const peer = peers.get(peerId);
      if (!peer) {
        console.log("[Error] Unknown peerId: " + peerId);
        return peers;
      }
      // @ts-ignore
      peer.stream.addTrack(consumer.track);
      if (consumer.kind === "video") {
        peer.videoConsumer = consumer;
      } else {
        peer.audioConsumer = consumer;
      }
      return new Map(peers).set(peerId, peer);
    });
  };

  /**
   * 更新Consumer状态
   * @param peerId
   * @param consumerId
   * @param type "paused" | "playing" | "closed"
   */
  const updateConsumerState = (
    peerId: string,
    consumerId: string,
    type: ConsumerStatus
  ) => {
    // intercept screen sharing
    let screen = false;
    setScreenSharing((screenSharing) => {
      if (screenSharing.consumer?.id === consumerId) {
        screen = true;
        if (type === "playing") {
          screenSharing.consumer.resume();
          return { ...screenSharing, active: true };
        } else if (type === "paused") {
          screenSharing.consumer.pause();
          return { ...screenSharing, active: false };
        } else {
          return {
            consumer: undefined,
            stream: undefined,
            peer: undefined,
            active: false,
          };
        }
      }
      return screenSharing;
    });
    if (screen) {
      return;
    }

    setPeers((peers) => {
      const peer = peers.get(peerId);
      if (!peer) {
        console.log("[Error] Unknown peerId: " + peerId);
        return peers;
      }
      const consumer =
        peer.videoConsumer && peer.videoConsumer.id === consumerId
          ? peer.videoConsumer
          : peer.audioConsumer;
      switch (type) {
        case "closed":
          consumer.close();
          // @ts-ignore
          peer.stream.removeTrack(consumer.track);
          break;
        case "paused":
          consumer.pause();
          break;
        case "playing":
          consumer.resume();
          break;
        default:
          break;
      }
      return new Map(peers).set(peerId, peer);
    });
  };

  const cleanUp = () => {
    setPeers((peers) => {
      peers.forEach((peer) => {
        // TODO: close consumers in the backend
        peer.audioConsumer?.close();
        peer.videoConsumer?.close();
      });
      return new Map();
    });
  };

  return {
    init,
    cleanUp,
    initPeers,
    peers,
  };
};

export default usePeerManager;
