import { MediaStream } from "react-native-webrtc-web-shim";
import { MediaType } from "../constants/enums";
import Alert from "../utils/alert";
import { producerStatus } from "../utils/helpers";
import useMediaDevice from "./useMediaDevice";
import { MeetingContainer } from "./useMeetingContainer";

const useProducerManager = () => {
  const {
    socket,
    producerTransport: transport,
    producerInfo: [producerInfo, setProducerInfo],
    producer: [producer, setProducer],
  } = MeetingContainer.useContainer();

  const { audio, video, screenSharing, cameraStream } = useMediaDevice();

  const init = () => {
    socket.current?.on("notification", (request: ServerRequestType) => {
      switch (request.method) {
        case "toPauseProducer": {
          const { mediaType } = request.data;
          pauseByServer(mediaType);
          break;
        }
        case "changeRole": {
          const { role }: ChangeRoleRequestData = request.data;
          setProducerInfo((producerInfo) => {
            if (!producerInfo) {
              return producerInfo;
            }
            return { ...producerInfo, role };
          });
          break;
        }
        default:
          break;
      }
    });
  };

  const checkRights = async (mediaType: MediaType) => {
    const { status, message }: RequestResponse = await socket.current?.request(
      "getRights",
      {
        mediaType,
      }
    );
    if (status === "fail") {
      console.log("[Error] " + message);
      switch (mediaType) {
        case MediaType.audio:
          Alert("错误", "主持人已禁用麦克风");
          break;
        case MediaType.screen:
          Alert("错误", "主持人已禁用屏幕共享");
          break;
        case MediaType.webcam:
          Alert("错误", "主持人已禁用摄像头");
          break;
      }
      return false;
    }
    return true;
  };

  /**
   * 更新摄像头视频流生产者
   * @description 根据音视频开启情况，创建、继续或暂停生产者
   * @param status 音视频开启状态
   * @param stream 视频流
   */
  const updateCameraProducers = async (
    status: MediaStreamConstraints,
    stream?: MediaStream
  ) => {
    if (!stream || !socket) {
      console.log("[Error] No stream or socket");
      return;
    }
    const newCameraProducer = { ...producer.webcam, stream };
    if (status.audio) {
      const track = stream.getAudioTracks()[0];
      if (!(await checkRights(MediaType.audio))) {
        return;
      }
      if (newCameraProducer.audio) {
        if (newCameraProducer.audio.paused) {
          await socket.current?.request("resumeProducer", {
            id: newCameraProducer.audio.id,
          });
          newCameraProducer.audio.resume();
        }
      } else {
        newCameraProducer.audio = await transport.current?.produce({
          // @ts-ignore
          track,
          appData: { mediaType: MediaType.audio },
        });
      }
    } else {
      if (newCameraProducer.audio && !newCameraProducer.audio.paused) {
        await socket.current?.request("pauseProducer", {
          id: newCameraProducer.audio.id,
        });
        newCameraProducer.audio.pause();
      }
    }
    if (status.video) {
      const track = stream.getVideoTracks()[0];
      if (!(await checkRights(MediaType.webcam))) {
        return;
      }
      if (newCameraProducer.video) {
        if (newCameraProducer.video.paused) {
          await socket.current?.request("resumeProducer", {
            id: newCameraProducer.video.id,
          });
          newCameraProducer.video.resume();
        }
      } else {
        newCameraProducer.video = await transport.current?.produce({
          // @ts-ignore
          track,
          appData: { mediaType: MediaType.webcam },
        });
      }
    } else {
      if (newCameraProducer.video && !newCameraProducer.video.paused) {
        await socket.current?.request("pauseProducer", {
          id: newCameraProducer.video.id,
        });
        newCameraProducer.video.pause();
      }
    }
    setProducer({ ...producer, webcam: newCameraProducer });
    // setAudioEnabled(status.audio as boolean);
    // setVideoEnabled(status.video as boolean);
  };

  /**
   * 更新屏幕共享视频流生产者
   * @description 根据音视频开启情况，创建、继续或暂停生产者
   * @param enabled 屏幕共享开启状态
   * @param stream 视频流
   */
  const updateScreenProducers = async (
    enabled: boolean,
    stream?: MediaStream
  ) => {
    if (!stream || !socket) {
      console.log("[Error] No stream or socket");
      return;
    }
    const newScreenProducer = { ...producer.screen, stream };
    if (enabled) {
      if (!(await checkRights(MediaType.screen))) {
        return;
      }
      const videoTrack = stream.getVideoTracks()[0];
      if (newScreenProducer.video) {
        if (newScreenProducer.video.paused) {
          await socket.current?.request("resumeProducer", {
            id: newScreenProducer.video.id,
          });
          newScreenProducer.video.resume();
        }
      } else {
        const videoProducer = videoTrack
          ? await transport.current?.produce({
              // @ts-ignore
              track: videoTrack,
              appData: { mediaType: MediaType.screen },
            })
          : undefined;
        videoProducer?.on("trackended", () => {
          socket.current?.request("pauseProducer", {
            id: videoProducer.id,
          });
          videoProducer.pause();
        });
        newScreenProducer.video = videoProducer;
      }

      const audioTrack = stream.getAudioTracks()[0];
      if (newScreenProducer.audio) {
        if (newScreenProducer.audio.paused) {
          await socket.current?.request("resumeProducer", {
            id: newScreenProducer.audio.id,
          });
          newScreenProducer.audio.resume();
        }
      } else {
        const audioProducer = audioTrack
          ? await transport.current?.produce({
              // @ts-ignore
              track: audioTrack,
              appData: { mediaType: MediaType.screen },
            })
          : undefined;
        audioProducer?.on("trackended", () => {
          socket.current?.request("pauseProducer", {
            id: audioProducer.id,
          });
          audioProducer.pause();
        });
        newScreenProducer.audio = audioProducer;
      }
    } else {
      if (newScreenProducer.audio && !newScreenProducer.audio.paused) {
        await socket.current?.request("pauseProducer", {
          id: newScreenProducer.audio.id,
        });
        newScreenProducer.audio.pause();
      }
      if (newScreenProducer.video && !newScreenProducer.video.paused) {
        await socket.current?.request("pauseProducer", {
          id: newScreenProducer.video.id,
        });
        newScreenProducer.video.pause();
      }
    }
    setProducer({
      ...producer,
      screen: newScreenProducer,
    });
  };

  /**
   * 开启音频
   */
  const enableAudio = async () => {
    if (!transport) {
      throw new Error("Transport not initialized");
    }
    if (producerStatus(producer.webcam.audio)) {
      return;
    }
    try {
      const stream = await audio.enable();
      if (!stream) {
        throw new Error("No camera stream");
      }
      await updateCameraProducers(
        { audio: true, video: producerStatus(producer.webcam.video) },
        stream
      );
    } catch (error) {
      Alert("开启音频", "音频获取失败，请检查权限");
    }
  };

  /**
   * 开启视频
   */
  const enableVideo = async () => {
    if (!transport) {
      throw new Error("Transport not initialized");
    }
    if (producerStatus(producer.webcam.video)) {
      return;
    }
    try {
      const stream = await video.enable();
      if (!stream) {
        throw new Error("No camera stream");
      }
      await updateCameraProducers(
        { audio: producerStatus(producer.webcam.audio), video: true },
        stream
      );
    } catch (error) {
      Alert("开启视频", "视频获取失败，请检查权限");
    }
  };

  /**
   * 关闭音频
   */
  const disableAudio = async () => {
    if (!producerStatus(producer.webcam.audio)) {
      return;
    }
    await updateCameraProducers(
      { audio: false, video: producerStatus(producer.webcam.video) },
      cameraStream
    );
  };

  /**
   * 关闭视频
   */
  const disableVideo = async () => {
    if (!producerStatus(producer.webcam.video)) {
      return;
    }
    await updateCameraProducers(
      { audio: producerStatus(producer.webcam.audio), video: false },
      cameraStream
    );
  };

  /**
   * 关闭音视频流和屏幕共享
   */
  const closeAll = () => {
    producer.webcam.audio?.close();
    producer.webcam.video?.close();
    producer.screen.audio?.close();
    producer.screen.video?.close();
    transport.current?.close();
    audio.disable();
    video.disable();
    screenSharing.stop();
    setProducer({
      webcam: {
        audio: undefined,
        video: undefined,
        stream: new MediaStream([]),
      },
      screen: {
        audio: undefined,
        video: undefined,
        stream: new MediaStream([]),
      },
    });
  };

  /**
   * 开始共享屏幕
   */
  const startSharing = async () => {
    if (!transport) {
      throw new Error("Transport not initialized");
    }
    if (producerStatus(producer.screen.video)) {
      return;
    }
    try {
      const stream = await screenSharing.start();
      await updateScreenProducers(true, stream);
      stream.getTracks().forEach((track) => {
        track.onended = handleTrackEnded;
      });
    } catch (error) {
      console.error(error);
      Alert("屏幕共享", "屏幕共享失败，请检查权限");
    }
  };

  /**
   * 停止共享屏幕
   */
  const stopSharing = async () => {
    if (!producerStatus(producer.screen.video)) {
      return;
    }
    await updateScreenProducers(false, screenSharing.stream);
  };

  /**
   * 暂停所有视频（被服务器禁止视频时）
   */
  const pauseByServer = (type: MediaType) => {
    setProducer((producers) => {
      const newProducers = { ...producers };
      switch (type) {
        case MediaType.audio:
          if (!newProducers.webcam.audio?.paused) {
            newProducers.webcam.audio?.pause();
          }
          break;

        case MediaType.screen:
          if (!newProducers.screen.audio?.paused) {
            newProducers.screen.audio?.pause();
          }
          if (!newProducers.screen.video?.paused) {
            newProducers.screen.video?.pause();
          }
          break;

        case MediaType.webcam:
          if (!newProducers.webcam.video?.paused) {
            newProducers.webcam.video?.pause();
          }
          break;

        default:
          break;
      }
      return newProducers;
    });
  };

  /*
   * 用户使用浏览器控制栏停止屏幕共享
   */
  const handleTrackEnded = () => {
    screenSharing.stop();
    setProducer({
      ...producer,
      screen: {
        audio: undefined,
        video: undefined,
        stream: new MediaStream([]),
      },
    });
  };

  return {
    init,
    webcam: {
      audio: {
        enabled: producerStatus(producer.webcam.audio),
        enable: enableAudio,
        disable: disableAudio,
      },
      video: {
        enabled: producerStatus(producer.webcam.video),
        enable: enableVideo,
        disable: disableVideo,
      },
      stream: producer.webcam.stream,
    },
    screenSharing: {
      enabled: producerStatus(producer.screen.video),
      start: startSharing,
      stop: stopSharing,
      stream: producer.screen.stream,
    },
    closeAll,
    producerInfo,
  };
};

export default useProducerManager;
