import { useState } from "react";
import {
  mediaDevices,
  MediaStream,
  MediaStreamConstraints,
} from "react-native-webrtc-web-shim";

const useMediaDevice = () => {
  /**
   * 语音与视频开启状态
   */
  const [status, setStatus] = useState<MediaStreamConstraints>({
    audio: false,
    video: false,
  });
  /**
   * 是否启用屏幕共享
   */
  const [sharingEnabled, setSharingEnabled] = useState<boolean>(false);
  /**
   * 摄像头音视频流
   */
  const [cameraStream, setCameraStream] = useState<MediaStream>(
    new MediaStream([])
  );
  /**
   * 屏幕共享音视频流
   */
  const [screenStream, setScreenStream] = useState<MediaStream>(
    new MediaStream([])
  );

  const getUserMedia = async (
    constraints: MediaStreamConstraints
  ): Promise<MediaStream> => {
    try {
      const stream = await mediaDevices.getUserMedia(constraints);
      if (typeof stream === "boolean") {
        throw new Error("Failed to get stream");
      }
      return stream;
    } catch (error) {
      console.error("getUserMedia() failed:", (error as Error).message);
      throw error;
    }
  };

  const getDisplayMedia = async (
    constraints: MediaStreamConstraints
  ): Promise<MediaStream> => {
    try {
      // @ts-ignore https://github.com/microsoft/TypeScript/issues/33232
      const stream = await mediaDevices.getDisplayMedia(constraints);
      return stream;
    } catch (error) {
      console.error("getDisplayMedia() failed:", (error as Error).message);
      throw error;
    }
  };

  /**
   * 开启音频
   * @returns 最新的摄像头音视频流
   */
  const enableAudio = async () => {
    if (status?.audio) {
      return cameraStream;
    }
    const stream = await getUserMedia({ audio: true });
    cameraStream.getTracks().forEach((track) => {
      stream.addTrack(track);
    });
    const newConstraints = { ...status, audio: true };
    setStatus(newConstraints);
    setCameraStream(stream);
    return stream;
  };

  /**
   * 开启视频
   * @returns 最新的摄像头音视频流
   */
  const enableVideo = async () => {
    if (status?.video) {
      return cameraStream;
    }
    const stream = await getUserMedia({ video: true });
    cameraStream.getTracks().forEach((track) => {
      stream.addTrack(track);
    });
    const newConstraints = { ...status, video: true };
    setStatus(newConstraints);
    setCameraStream(stream);
    return stream;
  };

  /**
   * 停止音频
   * @returns 最新的摄像头音视频流
   */
  const disableAudio = () => {
    if (!status?.audio) {
      return cameraStream;
    }
    const stream = cameraStream;
    stream.getAudioTracks().forEach((track) => {
      track.stop();
      stream.removeTrack(track);
    });
    const newConstraints = { ...status, audio: false };
    setStatus(newConstraints);
    setCameraStream(stream);
    return stream;
  };

  /**
   * 停止视频
   * @returns 最新的摄像头音视频流
   */
  const disableVideo = () => {
    if (!status?.video) {
      return cameraStream;
    }
    const stream = cameraStream;
    stream.getVideoTracks().forEach((track) => {
      track.stop();
      stream.removeTrack(track);
    });
    const newConstraints = { ...status, video: false };
    setStatus(newConstraints);
    setCameraStream(stream);
    return stream;
  };

  /**
   * 开启共享屏幕
   * @returns stream 屏幕共享流
   */
  const startSharing = async () => {
    if (sharingEnabled) {
      return screenStream;
    }
    const constraints: MediaStreamConstraints = { audio: true, video: true };
    const stream = await getDisplayMedia(constraints);
    setSharingEnabled(true);
    setScreenStream(stream);
    return stream;
  };

  /**
   * 停止共享屏幕
   */
  const stopSharing = () => {
    const stream = screenStream;
    stream.getTracks().forEach((track) => {
      track.stop();
      stream.removeTrack(track);
    });
    setScreenStream(stream);
    setSharingEnabled(false);
  };

  return {
    audio: {
      enabled: status.audio,
      enable: enableAudio,
      disable: disableAudio,
    },
    video: {
      enabled: status.video,
      enable: enableVideo,
      disable: disableVideo,
    },
    screenSharing: {
      stream: screenStream,
      enabled: sharingEnabled,
      start: startSharing,
      stop: stopSharing,
    },
    cameraStream,
  };
};

export default useMediaDevice;
