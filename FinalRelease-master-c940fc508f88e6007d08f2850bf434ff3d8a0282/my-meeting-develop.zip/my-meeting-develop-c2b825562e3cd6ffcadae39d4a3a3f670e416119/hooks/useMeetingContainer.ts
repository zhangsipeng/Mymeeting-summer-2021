import { Transport } from "mediasoup-client/lib/Transport";
import { useRef, useState } from "react";
import { MediaStream } from "react-native-webrtc-web-shim";
import { createContainer } from "unstated-next";
import { MeetingStatus } from "../constants/enums";

const useMeetingContainer = () => {
  return {
    socket: useRef<CustomSocket>(),
    consumerTransport: useRef<Transport>(),
    producerTransport: useRef<Transport>(),
    meetingInfo: useState<MeetingInfo>(),
    meetingStatus: useState<MeetingStatus>(MeetingStatus.NotConnected),
    producerInfo: useState<ProducerInfo>(),
    producer: useState<ProducerState>({
      webcam: {
        audio: undefined,
        video: undefined,
        stream: new MediaStream([]),
      },
      screen: {
        audio: undefined,
        video: undefined,
        stream: new MediaStream([]),
      },
    }),
    peers: useState<Map<string, PeerInfo>>(new Map()),
    chatMessages: useState<Message[]>([]),
    unreadCount: useState<number>(0),
    screenSharing: useState<screenSharingState>({
      consumer: undefined,
      stream: undefined,
      peer: undefined,
      active: false,
    }),
  };
};

export const MeetingContainer = createContainer(useMeetingContainer);
export const MeetingContext = MeetingContainer.Provider;
