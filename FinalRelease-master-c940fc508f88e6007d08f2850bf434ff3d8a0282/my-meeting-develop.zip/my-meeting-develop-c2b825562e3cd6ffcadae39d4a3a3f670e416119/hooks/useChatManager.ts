import { MeetingContainer } from "./useMeetingContainer";

const useChatManager = () => {
  const {
    socket,
    producerInfo: [producerInfo],
    chatMessages: [messages, setMessages],
    unreadCount: [, setUnreadCount],
  } = MeetingContainer.useContainer();

  const addMessage = (message: Message) => {
    setMessages((messages) => [...messages, message]);
  };

  const init = () => {
    socket.current?.on("notification", (request: ServerNotificationType) => {
      if (request.method === "chatMessage") {
        const message: Message = { ...request.data, time: new Date() };
        addMessage(message);
        setUnreadCount((unreadCount) => unreadCount + 1);
      }
    });
    setMessages([]);
  };

  const send = async (message: TextMessage | FileMessage) => {
    if (!socket || !producerInfo?.displayName) {
      console.log("[Error] ChatManager not initialized");
      return;
    }
    const payload = {
      message,
      from: producerInfo.displayName,
      to: "all",
      time: new Date(),
    };
    await socket.current?.request("chatMessage", payload);
    addMessage(payload);
  };

  return {
    init,
    send,
    messages,
  };
};

export default useChatManager;
