import { MediaType, Role } from "../constants/enums";
import { MeetingContainer } from "./useMeetingContainer";

const useParticipantsManager = () => {
  const {
    socket,
    producerInfo: [producerInfo],
  } = MeetingContainer.useContainer();

  const init = () => {};

  const muteAll = async (mediaType: MediaType) => {
    if (producerInfo?.role === Role.Participant) {
      return;
    }
    const { status, message }: RequestResponse = await socket.current?.request(
      "muteAll",
      { mediaType }
    );
    if (status === "fail") {
      console.log("[Error] mute all failed, msg: " + message);
    }
  };

  const unmuteAll = async (mediaType: MediaType) => {
    if (producerInfo?.role === Role.Participant) {
      return;
    }
    const { status, message }: RequestResponse = await socket.current?.request(
      "unmuteAll",
      { mediaType }
    );
    if (status === "fail") {
      console.log("[Error] mute all failed, msg: " + message);
    }
  };

  const changePeerRole = async (peerId: string, role: Role) => {
    if (producerInfo?.role === Role.Participant) {
      return;
    }
    const { status, message }: RequestResponse = await socket.current?.request(
      "changeRole",
      { toPeerId: peerId, role }
    );
    if (status === "fail") {
      console.log("[Error] mute all failed, msg: " + message);
    }
  };

  const mutePeer = async (peerId: string, mediaType: MediaType) => {
    if (producerInfo?.role === Role.Participant) {
      return;
    }
    const { status, message }: RequestResponse = await socket.current?.request(
      "mutePeer",
      { toPeerId: peerId, mediaType }
    );
    if (status === "fail") {
      console.log("[Error] mute all failed, msg: " + message);
    }
  };

  const getRoomRights = async () => {
    return (await socket.current?.request("getRoomRights")) as RoomRights;
  };

  const kickOut = async (peerId: string) => {
    const { status, message }: RequestResponse = await socket.current?.request(
      "kickOutPeer",
      { toPeerId: peerId }
    );
    if (status === "fail") {
      console.log("[Error] kick out peer failed, msg: " + message);
    }
  };

  return {
    muteAll,
    changePeerRole,
    mutePeer,
    unmuteAll,
    getRoomRights,
    init,
    kickOut,
  };
};

export default useParticipantsManager;
