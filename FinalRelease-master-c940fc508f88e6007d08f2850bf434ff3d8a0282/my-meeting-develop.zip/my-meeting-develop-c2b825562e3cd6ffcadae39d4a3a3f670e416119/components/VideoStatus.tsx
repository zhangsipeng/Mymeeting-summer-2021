import { Ionicons } from "@expo/vector-icons";
import * as React from "react";
import { StyleProp, TextStyle } from "react-native";
import VideoCamOffOutline from "./VideoCamOffOutline";

type VideoStatusProps = {
  status?: boolean;
  size?: number;
  style?: StyleProp<TextStyle>;
};

/**
 * 视频状态图标
 * @param status 视频状态，undefined为异常状态
 * @param size 图标大小
 */
const VideoStatus = ({ status, size, style }: VideoStatusProps) => {
  if (status === undefined) {
    return <Ionicons name="alert-circle-outline" size={size} style={style} />;
  }

  return status ? (
    <Ionicons name="videocam-outline" size={size} style={style} />
  ) : (
    // SVG颜色与图标颜色不一致
    <VideoCamOffOutline width={size} height={size} style={style} />
  );
};

export default VideoStatus;
