import * as React from "react";
import ParticipantVideo from "./ParticipantVideo";

type RemoteVideoProps = {
  remoteStream: GeneralMediaStream;
  videoState: boolean;
  audioState: boolean;
  peerId: string;
  style?: object;
};

const RemoteVideo = ({
  remoteStream,
  videoState,
  audioState,
  peerId,
  style,
}: RemoteVideoProps) => {
  return (
    <ParticipantVideo
      displayName={peerId}
      stream={remoteStream}
      audio={audioState}
      video={videoState}
      style={style}
    />
  );
};

export default RemoteVideo;
