import AsyncStorage from "@react-native-async-storage/async-storage";
import * as React from "react";
import { useEffect, useState } from "react";
import { StyleSheet } from "react-native";
import { Button, Dialog, TextInput } from "react-native-paper";
import { serverUrl } from "../constants/serverConfig";
import Alert from "../utils/alert";
import { onMobile } from "../utils/helpers";
import DateTimePicker from "./DateTimePicker";
import axios from "axios";

type Props = {
  visible: boolean;
  onDismiss: () => void;
};

const ScheduleMeetingDialog = ({ visible, onDismiss }: Props) => {
  const [password, setPassword] = useState<string>("");
  const [startTime, setStartTime] = useState<Date>(new Date());
  const [stopTime, setStopTime] = useState<Date>(new Date());
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    const now = new Date();
    now.setSeconds(0);
    setStartTime(now);
    setStopTime(now);
  }, [visible]);

  const storeMeeting = (meeting: ScheduledMeeting) => {
    AsyncStorage.getItem("scheduledMeetings")
      .then((data) => (data ? JSON.parse(data) : []))
      .then((meetings) => {
        meetings.push(meeting);
        AsyncStorage.setItem("scheduledMeetings", JSON.stringify(meetings));
      });
  };

  const handleScheduleMeeting = async () => {
    if (stopTime <= startTime) {
      Alert("错误", "会议结束时间需晚于开始时间");
      return;
    }
    setLoading(true);
    const { url } = (await axios.get(serverUrl + "getAvailableServer")).data;
    await fetch(
      url +
        `scheduleAMeeting?startTime=${startTime.toJSON()}&stopTime=${stopTime.toJSON()}&password=${password}`
    )
      .then((response) => response.json())
      .then((data) => {
        if (data.roomId) {
          Alert("预定会议", "预定成功，会议号码：" + data.roomId);
          storeMeeting({ roomId: data.roomId, startTime, stopTime, password });
          onDismiss();
          if (!onMobile) {
            location.reload();
          }
        } else if (data.error) {
          Alert("预定会议", "预定失败，错误：" + data.error);
        }
      })
      .catch((error) => {
        Alert("预定会议", "预定失败，错误：" + (error as Error).message);
      });
    setLoading(false);
  };

  const handleStartTimeChange = (time: Date) => {
    let startTime = time;
    if (startTime < new Date()) {
      startTime = new Date();
    }
    setStartTime(startTime);
    if (stopTime < time) {
      setStopTime(time);
    }
  };

  const handleStopTimeChange = (time: Date) => {
    let stopTime = time;
    if (stopTime < new Date()) {
      stopTime = new Date();
    }
    if (stopTime < startTime) {
      stopTime = startTime;
    }
    setStopTime(stopTime);
  };

  return (
    <Dialog
      visible={visible}
      onDismiss={onDismiss}
      style={!onMobile && styles.dialog}
    >
      <Dialog.Title>预定会议</Dialog.Title>
      <Dialog.Content>
        <DateTimePicker
          value={startTime}
          onChange={handleStartTimeChange}
          prefix="开始"
          itemStyle={styles.formItem}
          minDate={new Date()}
        />
        <DateTimePicker
          value={stopTime}
          onChange={handleStopTimeChange}
          prefix="结束"
          itemStyle={styles.formItem}
          minDate={startTime}
        />
        <TextInput
          style={styles.formItem}
          mode="outlined"
          label="会议密码"
          value={password}
          onChangeText={setPassword}
        />
      </Dialog.Content>
      <Dialog.Actions>
        <Button onPress={onDismiss}>取消</Button>
        <Button
          onPress={handleScheduleMeeting}
          loading={loading}
          disabled={loading}
        >
          确定
        </Button>
      </Dialog.Actions>
    </Dialog>
  );
};

const styles = StyleSheet.create({
  dialog: {
    minWidth: 500,
    alignSelf: "center",
  },
  formItem: {
    margin: 5,
  },
});

export default ScheduleMeetingDialog;
