import * as Clipboard from "expo-clipboard";
import React from "react";
import { Platform, ToastAndroid } from "react-native";
import { Button, Dialog, Paragraph } from "react-native-paper";
import Alert from "../utils/alert";
import { onMobile } from "../utils/helpers";

type MeetingInfoDialogProps = {
  name?: string;
  info?: MeetingInfo;
  visible: boolean;
  onDismiss: () => void;
};

const MeetingInfoDialog = ({
  name,
  info,
  visible,
  onDismiss,
}: MeetingInfoDialogProps) => {
  const copyToClipboard = () => {
    let text = `${name}邀请您使用MyMeeting加入会议\n会议号码：${info?.roomId}`;
    const host = onMobile ? "https://www.mymeeting.cf" : location.origin;
    let url = `${host}/meeting/${info?.roomId}`;
    if (info?.password) {
      text += `\n会议密码：${info.password}`;
      url += `?password=${info.password}`;
    }
    text += `\n点击链接加入会议：${url}`;

    Clipboard.setString(text);
    if (Platform.OS === "android") {
      ToastAndroid.show("会议信息已复制到剪贴板", ToastAndroid.SHORT);
    } else {
      Alert("会议详情", "会议信息已复制到剪贴板");
    }
    onDismiss();
  };

  return (
    <Dialog
      visible={visible}
      onDismiss={onDismiss}
      style={
        !onMobile && {
          minWidth: 500,
          alignSelf: "center",
        }
      }
    >
      <Dialog.Title>会议详情</Dialog.Title>
      <Dialog.Content>
        <Paragraph>会议号：{info?.roomId ?? "未知"}</Paragraph>
        {info?.password ? (
          <Paragraph>会议密码：{info.password}</Paragraph>
        ) : null}
      </Dialog.Content>
      <Dialog.Actions>
        <Button onPress={copyToClipboard}>复制</Button>
        <Button onPress={onDismiss}>关闭</Button>
      </Dialog.Actions>
    </Dialog>
  );
};

export default MeetingInfoDialog;
