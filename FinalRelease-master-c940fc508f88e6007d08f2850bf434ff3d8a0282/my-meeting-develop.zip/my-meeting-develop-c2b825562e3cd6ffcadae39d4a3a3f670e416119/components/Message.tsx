import * as React from "react";
import { StyleSheet, View } from "react-native";
import { Text } from "react-native-paper";
import FileMessage from "./FileMessage";
import TextMessage from "./TextMessage";

type MessageProps = {
  message: Message;
};

const Message = ({ message }: MessageProps) => {
  return (
    <View style={styles.container}>
      <View style={styles.meta}>
        <Text style={styles.metaText}>
          {message.from} [{message.time.toLocaleTimeString()}]
        </Text>
      </View>
      <View>
        {message.message.type === "text" ? (
          <TextMessage message={message.message as TextMessage} />
        ) : (
          <FileMessage message={message.message as FileMessage} />
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 15,
    paddingTop: 5,
    paddingBottom: 5,
  },
  meta: {
    marginBottom: 5,
  },
  metaText: {
    color: "#888",
  },
});

export default Message;
