import { Ionicons } from "@expo/vector-icons";
import * as FileSystem from "expo-file-system";
import * as IntentLauncher from "expo-intent-launcher";
import * as React from "react";
import { useState } from "react";
import { Appearance, StyleSheet, useColorScheme, View } from "react-native";
import { Caption, Subheading, TouchableRipple } from "react-native-paper";
import Colors from "../constants/Colors";
import { serverUrl } from "../constants/serverConfig";
import { downloadProgress, fileSize, onMobile } from "../utils/helpers";

enum DownloadStatus {
  None,
  Downloading,
  Paused,
  Completed,
  Error,
}

type FileMessageProps = {
  message: FileMessage;
};

const FileMessage = ({ message }: FileMessageProps) => {
  const colorScheme = useColorScheme();
  const [download, setDownload] = useState<FileSystem.DownloadResumable>();
  const [status, setStatus] = useState<DownloadStatus>(DownloadStatus.None);
  const [progress, setProgress] = useState<FileSystem.DownloadProgressData>();
  const [uri, setUri] = useState<string>("");

  const getDownloadUri = async () => {
    if (uri) {
      return uri;
    }
    const { filename, time } = message;
    return await fetch(
      serverUrl +
        `downloadUrl?name=${encodeURIComponent(filename)}&time=${time}`
    )
      .then((response) => response.json())
      .then((data) => {
        setUri(data.url);
        return data.url;
      });
  };

  const startDownload = async () => {
    const { filename } = message;
    const downloadUri = await getDownloadUri();
    if (!onMobile) {
      window.open(downloadUri);
      setStatus(DownloadStatus.Completed);
      return;
    }
    const fileUri = FileSystem.documentDirectory + filename;
    const resumable = FileSystem.createDownloadResumable(
      downloadUri,
      fileUri,
      undefined,
      (progress) => setProgress(progress)
    );
    setDownload(resumable);
    setStatus(DownloadStatus.Downloading);
    try {
      const result = await resumable.downloadAsync();
      if (!result || result.status >= 400) {
        console.log("[Error] Download error", result);
        setDownload(undefined);
        setStatus(DownloadStatus.Error);
        return;
      }
      setStatus(DownloadStatus.Completed);
      await open();
    } catch (error) {
      console.log("[Error] Download error", error);
      setStatus(DownloadStatus.Error);
    }
    setDownload(undefined);
  };

  const pause = async () => {
    if (!download) {
      return;
    }
    await download.pauseAsync();
    setStatus(DownloadStatus.Paused);
  };

  const resume = async () => {
    if (!download) {
      return;
    }
    await download.resumeAsync();
    setStatus(DownloadStatus.Downloading);
  };

  const open = async () => {
    const { filename } = message;
    const fileUri = FileSystem.documentDirectory + filename;
    FileSystem.getContentUriAsync(fileUri).then((contentUri) => {
      IntentLauncher.startActivityAsync("android.intent.action.VIEW", {
        data: contentUri,
        flags: 1, // FLAG_GRANT_READ_URI_PERMISSION
      });
    });
  };

  const handlePress = async () => {
    switch (status) {
      case DownloadStatus.Downloading:
        await pause();
        break;
      case DownloadStatus.Paused:
        await resume();
        break;
      case DownloadStatus.Completed:
        await open();
        break;
      default:
        await startDownload();
    }
  };

  let statusIcon = "";
  switch (status) {
    case DownloadStatus.Downloading:
      statusIcon = "pause-outline";
      break;
    case DownloadStatus.Paused:
      statusIcon = "play-outline";
      break;
    case DownloadStatus.Completed:
      statusIcon = "checkmark-outline";
      break;
    case DownloadStatus.Error:
      statusIcon = "close-outline";
      break;
    default:
      statusIcon = "document-outline";
  }

  const result = message.filename.split(".");
  const ext = result[result.length - 1].toUpperCase();

  return (
    <TouchableRipple
      style={styles.container}
      onPress={handlePress}
      rippleColor={
        colorScheme === "dark" ? Colors.dark.ripple : Colors.light.ripple
      }
      borderless
    >
      <View style={styles.content}>
        <View style={styles.icon}>
          <Ionicons
            // @ts-ignore
            name={statusIcon}
            size={40}
          />
        </View>
        <View style={styles.fileInfo}>
          <Subheading numberOfLines={1}>{message.filename}</Subheading>
          <Caption>
            {status === DownloadStatus.Downloading
              ? downloadProgress(progress)
              : `${fileSize(message.size)} ${ext}`}
          </Caption>
        </View>
      </View>
    </TouchableRipple>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 80,
    maxWidth: "100%",
    borderRadius: 5,
    backgroundColor:
      Appearance.getColorScheme() === "dark" ? "white" : "#f7f7f7",
    justifyContent: "center",
    alignSelf: "flex-start",
  },
  content: {
    flexDirection: "row",
    alignSelf: "flex-start",
  },
  icon: {
    justifyContent: "center",
    padding: 10,
    paddingRight: 0,
  },
  fileInfo: {
    padding: 10,
    marginRight: 10,
    flexDirection: "column",
  },
});

export default FileMessage;
