import * as React from "react";
import { Appearance, StyleSheet, useColorScheme, View } from "react-native";
import { Text, TouchableRipple } from "react-native-paper";
import Colors from "../constants/Colors";

type TextMessageProps = {
  message: TextMessage;
};

const TextMessage = ({ message }: TextMessageProps) => {
  const colorScheme = useColorScheme();

  return (
    <TouchableRipple
      style={styles.container}
      onPress={() => {}}
      rippleColor={
        colorScheme === "dark" ? Colors.dark.ripple : Colors.light.ripple
      }
      borderless
    >
      <View>
        <Text style={{ fontSize: 15 }}>{message.content}</Text>
      </View>
    </TouchableRipple>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 15,
    maxWidth: "100%",
    borderRadius: 5,
    backgroundColor:
      Appearance.getColorScheme() === "dark" ? "white" : "#f7f7f7",
    justifyContent: "center",
    alignSelf: "flex-start",
  },
});

export default TextMessage;
