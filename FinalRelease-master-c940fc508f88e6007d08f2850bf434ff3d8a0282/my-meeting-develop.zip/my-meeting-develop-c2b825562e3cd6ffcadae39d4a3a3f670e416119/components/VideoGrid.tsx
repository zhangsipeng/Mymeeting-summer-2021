import * as React from "react";
import { StyleSheet, View } from "react-native";

type VideoGridProps = {
  videos: React.ReactNode[];
};

const VideoGrid = ({ videos }: VideoGridProps) => {
  const count = videos.length;
  const numPerRow = count <= 2 ? 1 : 2;
  const rows = [];
  for (let i = 0; i < count; i += numPerRow) {
    const chunk = videos.slice(i, i + numPerRow);
    rows.push(chunk);
  }

  return (
    <>
      {rows.map((row, index) => (
        <View key={index} style={styles.row}>
          {row.map((video, index) => (
            <View key={index} style={styles.grid}>
              {video}
            </View>
          ))}
        </View>
      ))}
    </>
  );
};

const styles = StyleSheet.create({
  row: { flexDirection: "row", height: "50%" },
  grid: { flex: 1, margin: 10 },
  video: { width: "auto", height: "100%" },
});

export default VideoGrid;
