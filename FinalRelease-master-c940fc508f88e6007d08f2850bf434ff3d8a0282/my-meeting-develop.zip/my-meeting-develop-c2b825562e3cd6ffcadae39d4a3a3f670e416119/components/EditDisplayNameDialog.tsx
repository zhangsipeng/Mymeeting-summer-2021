import React, { useState } from "react";
import { Button, Dialog, TextInput } from "react-native-paper";
import Alert from "../utils/alert";
import { onMobile } from "../utils/helpers";

type Props = {
  visible: boolean;
  onCancel?: () => void;
  onFinish: (displayName: string) => void;
};

const EditDisplayNameDialog = ({ visible, onCancel, onFinish }: Props) => {
  const [displayName, setDisplayName] = useState<string>("");
  const [error, setError] = useState<boolean>(false);

  const validateName = (displayName: string) => {
    if (!displayName) {
      setError(true);
      return false;
    }
    setError(false);
    return true;
  };

  const onNameChange = (name: string) => {
    setDisplayName(name);
    validateName(name);
  };

  const handleFinish = () => {
    if (!validateName(displayName)) {
      Alert("错误", "请输入您的姓名");
      return;
    }
    onFinish(displayName);
  };

  return (
    <Dialog
      visible={visible}
      style={
        !onMobile && {
          minWidth: 500,
          alignSelf: "center",
        }
      }
      dismissable={false}
    >
      <Dialog.Title>修改姓名</Dialog.Title>
      <Dialog.Content>
        <TextInput
          label="您的姓名  "
          mode="outlined"
          value={displayName}
          error={error}
          onChangeText={onNameChange}
          autoCompleteType="name"
          onSubmitEditing={handleFinish}
        />
      </Dialog.Content>
      <Dialog.Actions>
        {onCancel && <Button onPress={onCancel}>取消</Button>}
        <Button onPress={handleFinish}>确定</Button>
      </Dialog.Actions>
    </Dialog>
  );
};

export default EditDisplayNameDialog;
