import * as React from "react";
import { useMemo } from "react";
import { Animated, Dimensions, StyleSheet, View } from "react-native";
import { ScalingDot } from "react-native-animated-pagination-dots";
import PagerView, {
  ViewPagerOnPageScrollEventData,
} from "react-native-pager-view";
import { useTheme } from "react-native-paper";
import useMeetingManager from "../hooks/useMeetingManager";
import useProducerManager from "../hooks/useProducerManager";
import { getOrientation } from "../utils/helpers";
import ParticipantVideo from "./ParticipantVideo";
import VideoGrid from "./VideoGrid";
import VideoList from "./VideoList";

type VideoPagesProps = {
  layout?: VideoLayout;
  children: React.ReactNode[];
};

const VideoPages = ({ layout = "grid", children }: VideoPagesProps) => {
  const { colors } = useTheme();
  const { screenSharing } = useMeetingManager();
  const {
    webcam,
    screenSharing: localScreenSharing,
    producerInfo,
  } = useProducerManager();

  const numPerPage = 4;
  const pages = [];
  let videos = children;

  // add screen sharing, self webcam and maybe sharing peer's webcam
  const firstPage = [];
  const localWebcam = (
    <ParticipantVideo
      displayName={producerInfo ? producerInfo.displayName : "foo"}
      key="localWebcam"
      audio={webcam.audio.enabled}
      video={webcam.video.enabled}
      stream={webcam.stream}
      style={styles.video}
      orientation={getOrientation(producerInfo?.platform)}
    />
  );

  // sharing screen locally
  firstPage.push(localWebcam);
  if (localScreenSharing.enabled) {
    firstPage.push(
      <ParticipantVideo
        displayName={producerInfo ? producerInfo.displayName : "foo"}
        key="localScreenSharing"
        audio={localScreenSharing.enabled}
        video={localScreenSharing.enabled}
        stream={localScreenSharing.stream}
        style={styles.video}
        orientation={getOrientation(producerInfo?.platform)}
      />
    );
  }
  // sharing screen by others
  else if (screenSharing.peer && screenSharing.active) {
    firstPage.push(
      <ParticipantVideo
        displayName={screenSharing.peer.displayName}
        key="local"
        audio={!!screenSharing.consumer}
        video={!!screenSharing.consumer}
        stream={screenSharing.peer?.stream}
        style={styles.video}
        orientation={getOrientation(screenSharing.peer?.platform)}
      />
    );
    // avoid duplicated webcam in list view
    if (layout === "grid") {
      firstPage.push(
        <ParticipantVideo
          displayName={screenSharing.peer.displayName}
          key="local"
          audio={!!screenSharing.consumer}
          video={!!screenSharing.consumer}
          stream={screenSharing.stream}
          style={styles.video}
          orientation={getOrientation(screenSharing.peer?.platform)}
        />
      );
    }
  }
  pages.push(firstPage);

  // add other peers
  for (let i = 0; i < videos.length; i += numPerPage) {
    const chunk = videos.slice(i, i + numPerPage);
    pages.push(chunk);
  }

  const AnimatedPagerView = Animated.createAnimatedComponent(PagerView);
  const width = Dimensions.get("window").width;
  const scrollOffsetAnimatedValue = React.useRef(new Animated.Value(0)).current;
  const positionAnimatedValue = React.useRef(new Animated.Value(0)).current;
  const inputRange = [0, pages.length];
  const scrollX = Animated.add(
    scrollOffsetAnimatedValue,
    positionAnimatedValue
  ).interpolate({
    inputRange,
    outputRange: [0, pages.length * width],
  });

  const onPageScroll = useMemo(
    () =>
      Animated.event<ViewPagerOnPageScrollEventData>(
        [
          {
            nativeEvent: {
              offset: scrollOffsetAnimatedValue,
              position: positionAnimatedValue,
            },
          },
        ],
        {
          useNativeDriver: false,
        }
      ),
    []
  );

  if (layout === "list") {
    return <VideoList videos={pages.flat()} />;
  }

  return (
    <>
      <AnimatedPagerView
        showPageIndicator={true}
        style={styles.pagerView}
        initialPage={0}
        onPageScroll={onPageScroll}
      >
        {pages.map((page, index) => (
          <View key={index}>
            <VideoGrid videos={page} />
          </View>
        ))}
      </AnimatedPagerView>
      <View style={styles.pageIndicator}>
        <ScalingDot
          data={pages.map((_, index) => ({ key: index }))}
          //@ts-ignore
          scrollX={scrollX}
          containerStyle={{
            top: 0,
          }}
          dotStyle={{
            width: 8,
            height: 8,
            backgroundColor: colors.primary, // Seems not working
          }}
        />
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  pagerView: {
    flex: 1,
    width: "100%",
    height: "100%",
    borderWidth: 1,
  },
  pageIndicator: {
    marginBottom: 10,
    width: "100%",
    alignItems: "center",
  },
  video: { width: "100%", height: "100%" },
});

export default VideoPages;
