import * as React from "react";
import { StyleSheet, View } from "react-native";
import { Surface } from "react-native-paper";

type VideoGridProps = {
  videos: React.ReactNode[];
};

const VideoGrid = ({ videos }: VideoGridProps) => {
  const numPerRow = 3;
  const count = videos.length;
  const rows = [];
  for (let i = 0; i < count; i += numPerRow) {
    const chunk = videos.slice(i, i + numPerRow);
    rows.push(chunk);
  }

  return (
    <>
      <View style={styles.container}>
        {rows.map((row, index) => (
          <View key={index} style={styles.row}>
            {row.map((video, index) => (
              <Surface
                key={index}
                style={[
                  styles.grid,
                  count > 3 && row.length < 3 && { maxWidth: "33.33%" },
                ]}
              >
                {video}
              </Surface>
            ))}
          </View>
        ))}
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flexWrap: "wrap",
    flexDirection: "column",
    height: "100%",
    width: "100%",
    justifyContent: "center",
  },
  row: {
    flexDirection: "row",
    flex: 1,
    width: "100%",
    justifyContent: "center",
  },
  grid: {
    flex: 1,
  },
  video: { width: "auto", height: "100%" },
});

export default VideoGrid;
