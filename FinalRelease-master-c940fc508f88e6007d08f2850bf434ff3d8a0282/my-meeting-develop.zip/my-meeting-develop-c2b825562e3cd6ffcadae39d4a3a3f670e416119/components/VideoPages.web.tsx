import * as React from "react";
import { useState } from "react";
import { StyleSheet, View } from "react-native";
import { IconButton } from "react-native-paper";
import useMeetingManager from "../hooks/useMeetingManager";
import useProducerManager from "../hooks/useProducerManager";
import { getOrientation } from "../utils/helpers";
import ParticipantVideo from "./ParticipantVideo";
import VideoGrid from "./VideoGrid";

type VideoPagesProps = {
  layout?: VideoLayout;
  children: React.ReactNode[];
};

const ICON_SIZE = 30;

const VideoPages = ({ children }: VideoPagesProps) => {
  const videos = children;

  const { screenSharing } = useMeetingManager();
  const {
    webcam,
    screenSharing: localScreenSharing,
    producerInfo,
  } = useProducerManager();

  const [page, setPage] = useState<number>(0);

  const localWebcam = (
    <ParticipantVideo
      displayName={producerInfo ? producerInfo.displayName : "加载中"}
      key="localWebcam"
      audio={webcam.audio.enabled}
      video={webcam.video.enabled}
      stream={webcam.stream}
      style={styles.video}
      orientation={getOrientation(producerInfo?.platform)}
    />
  );

  videos.push(localWebcam);
  if (localScreenSharing.enabled) {
    videos.push(
      <ParticipantVideo
        displayName={producerInfo ? producerInfo.displayName : "加载中"}
        key="localScreenSharing"
        audio={localScreenSharing.enabled}
        video={localScreenSharing.enabled}
        stream={localScreenSharing.stream}
        style={styles.video}
        orientation={getOrientation(producerInfo?.platform)}
      />
    );
  } // sharing screen by others
  else if (screenSharing.peer && screenSharing.active) {
    videos.push(
      <ParticipantVideo
        displayName={screenSharing.peer.displayName}
        key="local"
        audio={!!screenSharing.consumer}
        video={!!screenSharing.consumer}
        stream={screenSharing.stream}
        style={styles.video}
        orientation={getOrientation(screenSharing.peer?.platform)}
      />
    );
  }

  const count = videos.length;
  const numPerPage = 6;
  const pages = [];
  for (let i = 0; i < count; i += numPerPage) {
    const chunk = videos.slice(i, i + numPerPage);
    pages.push(chunk);
  }
  const totalPages = pages.length;

  return (
    <View style={styles.content}>
      <View style={[styles.pagination, { alignItems: "flex-end" }]}>
        {totalPages > 1 && page > 0 && (
          <IconButton
            icon="chevron-back-outline"
            onPress={() => setPage((page) => page - 1)}
            size={ICON_SIZE}
          />
        )}
      </View>
      <View style={{ width: "calc(100% - 120px)" }}>
        <VideoGrid videos={pages[page]} />
      </View>
      <View style={styles.pagination}>
        {totalPages > 1 && page < totalPages - 1 && (
          <IconButton
            icon="chevron-forward-outline"
            onPress={() => setPage((page) => page + 1)}
            size={ICON_SIZE}
          />
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  content: {
    flexDirection: "row",
    flex: 1,
    width: "100%",
    paddingTop: 20,
  },
  pagination: {
    width: 60,
    justifyContent: "center",
  },
  video: { width: "100%", height: "100%" },
});

export default VideoPages;
