import React, {
  forwardRef,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import { StyleProp, TextStyle } from "react-native";
import { TextInput } from "react-native-paper";
import CreateMeetingForm from "./CreateMeetingForm";

type Handle = {
  validateAndGetValues: () => Promise<{
    roomId: string;
    displayName: string;
    password: string;
  }>;
};

type Props = {
  formItemStyle?: StyleProp<TextStyle>;
  onSubmit?: () => void;
};

const JoinMeetingForm: React.ForwardRefRenderFunction<Handle, Props> = (
  { formItemStyle, onSubmit },
  ref
) => {
  const [roomId, setRoomId] = useState<string>("");
  const [roomIdError, setRoomIdError] = useState<boolean>(false);
  const createFormRef =
    useRef<React.ElementRef<typeof CreateMeetingForm>>(null);

  useImperativeHandle(ref, () => ({
    validateAndGetValues: () => {
      // 同时显示所有错误
      return Promise.all([
        new Promise<{ roomId: string }>((resolve, reject) => {
          if (!validateRoomId(roomId)) {
            return reject("请输入会议号码");
          }
          return resolve({ roomId });
        }),
        createFormRef.current?.validateAndGetValues() || Promise.reject(),
      ]).then((values) => Object.assign({}, ...values));
    },
  }));

  const validateRoomId = (roomId: string) => {
    if (!roomId) {
      setRoomIdError(true);
      return false;
    }
    setRoomIdError(false);
    return true;
  };

  const onRoomIdChange = (name: string) => {
    setRoomId(name);
    validateRoomId(name);
  };

  return (
    <>
      <TextInput
        style={formItemStyle}
        mode="outlined"
        label="会议号码  "
        keyboardType="number-pad"
        value={roomId}
        onChangeText={onRoomIdChange}
        autoCompleteType="off"
        error={roomIdError}
        onSubmitEditing={onSubmit}
      />
      <CreateMeetingForm
        ref={createFormRef}
        onSubmit={onSubmit}
        formItemStyle={formItemStyle}
      />
    </>
  );
};

export default forwardRef(JoinMeetingForm);
