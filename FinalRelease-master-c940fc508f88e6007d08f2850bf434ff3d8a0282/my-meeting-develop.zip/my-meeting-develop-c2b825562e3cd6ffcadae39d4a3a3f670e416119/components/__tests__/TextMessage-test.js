import * as React from "react";
import renderer from "react-test-renderer";
import TextMessage from "../TextMessage";

describe("test TextMessage", () => {
  it("renders correctly", () => {
    const tree = renderer
      .create(
        <TextMessage
          message={{
            type: "text",
            content: "Test",
          }}
        />
      )
      .toJSON();

    expect(tree).toMatchSnapshot();
  });
});
