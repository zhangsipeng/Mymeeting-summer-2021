import { Ionicons } from "@expo/vector-icons";
import * as React from "react";
import { StyleProp, TextStyle } from "react-native";

type AudioStatusProps = {
  status?: boolean;
  size?: number;
  style?: StyleProp<TextStyle>;
};

/**
 * 音频状态图标
 * @param status 音频状态，undefined为异常状态
 * @param size 图标大小
 * @param style 图标样式
 */
const AudioStatus = ({ status, size, style }: AudioStatusProps) => {
  return (
    <Ionicons
      name={
        status === undefined
          ? "alert-circle-outline"
          : status
          ? "mic-outline"
          : "mic-off-outline"
      }
      size={size}
      style={[status === undefined && { marginTop: 1 }, style]}
    />
  );
};

export default AudioStatus;
