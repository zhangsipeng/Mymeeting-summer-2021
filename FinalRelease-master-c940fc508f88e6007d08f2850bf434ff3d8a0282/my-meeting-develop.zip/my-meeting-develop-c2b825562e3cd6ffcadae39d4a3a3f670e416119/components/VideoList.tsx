import * as React from "react";
import { ScrollView, StyleSheet, View } from "react-native";

type VideoListProps = {
  videos: React.ReactNode[];
};

const VideoList = ({ videos }: VideoListProps) => {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {videos.map((video, index) => (
        <View key={index} style={styles.videoWrapper}>
          {video}
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    width: "100%",
  },
  content: {
    padding: 10,
    alignItems: "center",
    width: "100%",
  },
  videoWrapper: {
    marginBottom: 10,
    aspectRatio: 16 / 9,
    width: "100%",
  },
});

export default VideoList;
