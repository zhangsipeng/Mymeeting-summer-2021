import * as React from "react";
import { useState } from "react";
import { StyleProp, TextStyle } from "react-native";
import { TextInput } from "react-native-paper";
import { DatePickerModal, TimePickerModal } from "react-native-paper-dates";
import { CalendarDate } from "react-native-paper-dates/lib/typescript/src/Date/Calendar";

type Props = {
  value?: Date;
  onChange: (value: Date) => void;
  minDate?: Date;
  prefix?: string;
  itemStyle?: StyleProp<TextStyle>;
};

type ClockTime = {
  hours: number;
  minutes: number;
};

const ScheduleMeetingDialog = ({
  value,
  onChange,
  minDate,
  prefix = "",
  itemStyle,
}: Props) => {
  const [dateModalVisible, setDateModalVisible] = useState<boolean>(false);
  const [timeModalVisible, setTimeModalVisible] = useState<boolean>(false);

  const handleDateConfirm = (params: { date: CalendarDate }) => {
    const date = params.date;
    const now = new Date();
    if (date) {
      const hours = value ? value.getHours() : now.getHours();
      const minutes = value ? value.getMinutes() : now.getMinutes();
      date.setHours(hours);
      date.setMinutes(minutes);
      onChange(date);
      setDateModalVisible(false);
    }
  };

  const handleTimeConfirm = ({ hours, minutes }: ClockTime) => {
    const newDate = value ? new Date(value) : new Date();
    newDate.setHours(hours);
    newDate.setMinutes(minutes);
    newDate.setSeconds(0);
    onChange(newDate);
    setTimeModalVisible(false);
  };

  return (
    <>
      <TextInput
        mode="outlined"
        disabled
        label={`${prefix}日期  `}
        value={value?.toLocaleString() ?? ""}
        right={
          <TextInput.Icon
            name="calendar-outline"
            onPress={() => setDateModalVisible(true)}
          />
        }
        style={itemStyle}
      />
      <DatePickerModal
        mode="single"
        visible={dateModalVisible}
        onDismiss={() => setDateModalVisible(false)}
        date={value}
        onConfirm={handleDateConfirm}
        validRange={{
          startDate: minDate,
        }}
        label="选择日期"
        saveLabel="确定"
      />
      <TextInput
        mode="outlined"
        disabled
        label={`${prefix}时间  `}
        value={value?.toLocaleTimeString() ?? ""}
        right={
          <TextInput.Icon
            name="time-outline"
            onPress={() => setTimeModalVisible(true)}
          />
        }
        style={itemStyle}
      />
      <TimePickerModal
        visible={timeModalVisible}
        hours={value?.getHours()}
        minutes={value?.getMinutes()}
        onDismiss={() => setTimeModalVisible(false)}
        onConfirm={handleTimeConfirm}
        label="选择时间"
        cancelLabel="取消"
        confirmLabel="确定"
        animationType="fade"
      />
    </>
  );
};

export default ScheduleMeetingDialog;
