import React, { forwardRef, useImperativeHandle, useState } from "react";
import { StyleProp, TextStyle } from "react-native";
import { TextInput } from "react-native-paper";

type Handle = {
  validateAndGetValues: () => Promise<{
    displayName: string;
    password: string;
  }>;
};

type Props = {
  formItemStyle?: StyleProp<TextStyle>;
  onSubmit?: () => void;
};

const CreateMeetingForm: React.ForwardRefRenderFunction<Handle, Props> = (
  { formItemStyle, onSubmit },
  ref
) => {
  const [displayName, setDisplayName] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [nameError, setNameError] = useState<boolean>(false);

  useImperativeHandle(ref, () => ({
    validateAndGetValues: () => {
      if (!validateName(displayName)) {
        return Promise.reject("请输入您的姓名");
      }
      return Promise.resolve({ displayName, password });
    },
  }));

  const validateName = (displayName: string) => {
    if (!displayName) {
      setNameError(true);
      return false;
    }
    setNameError(false);
    return true;
  };

  const onNameChange = (name: string) => {
    setDisplayName(name);
    validateName(name);
  };

  return (
    <>
      <TextInput
        style={formItemStyle}
        mode="outlined"
        label="您的姓名  "
        value={displayName}
        onChangeText={onNameChange}
        autoCompleteType="name"
        error={nameError}
        onSubmitEditing={onSubmit}
      />
      <TextInput
        style={formItemStyle}
        mode="outlined"
        label="会议密码  "
        value={password}
        secureTextEntry={true}
        onChangeText={setPassword}
        autoCompleteType="off"
        onSubmitEditing={onSubmit}
      />
    </>
  );
};

export default forwardRef(CreateMeetingForm);
