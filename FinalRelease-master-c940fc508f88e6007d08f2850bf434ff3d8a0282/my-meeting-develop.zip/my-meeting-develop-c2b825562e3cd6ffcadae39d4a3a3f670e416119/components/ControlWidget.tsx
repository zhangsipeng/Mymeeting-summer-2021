import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import * as React from "react";
import { useState } from "react";
import {
  GestureResponderEvent,
  StyleSheet,
  useColorScheme,
  View,
} from "react-native";
import {
  Badge,
  Dialog,
  List,
  Portal,
  Surface,
  TouchableRipple,
  useTheme,
} from "react-native-paper";
import Colors from "../constants/Colors";
import { MeetingContainer } from "../hooks/useMeetingContainer";
import { onMobile } from "../utils/helpers";
import AudioStatus from "./AudioStatus";
import VideoStatus from "./VideoStatus";

const borderRadius = 5,
  iconSize = 30,
  buttonSize = onMobile ? 80 : 60;

type MenuItem = {
  key: string;
  icon: string;
  onPress: ((event: GestureResponderEvent) => void) &
    ((e: GestureResponderEvent) => void) &
    (() => void);
  title: React.ReactNode;
};

type ControlWidgetProps = MediaStateControl & {
  onExit: (event: GestureResponderEvent) => void;
  toggleChat: () => void;
  menu: MenuItem[];
};

const ControlWidget = ({
  audio,
  video,
  screenSharing,
  onExit,
  toggleChat,
  menu,
}: ControlWidgetProps) => {
  const colorScheme = useColorScheme();
  const {
    unreadCount: [unreadCount],
  } = MeetingContainer.useContainer();
  const rippleProps = {
    borderless: true,
    rippleColor:
      colorScheme === "dark" ? Colors.dark.ripple : Colors.light.ripple,
  };
  const navigation = useNavigation();
  const { colors } = useTheme();
  const iconDefaultStyle = colorScheme === "dark" ? { color: "#888" } : {};
  const videoIconDefaultStyle = colorScheme === "dark" ? { color: "#ddd" } : {};
  const activeStyle = { backgroundColor: colors.primary };
  const [menuVisible, setMenuVisible] = useState(false);

  const openMenu = () => setMenuVisible(true);
  const closeMenu = () => setMenuVisible(false);

  const toggleVideo = async () => {
    if (video.enabled) {
      await video.disable();
    } else {
      await video.enable();
    }
  };

  const toggleAudio = async () => {
    if (audio.enabled) {
      await audio.disable();
    } else {
      await audio.enable();
    }
  };

  const toggleScreenSharing = async () => {
    if (screenSharing.enabled) {
      await screenSharing.stop();
    } else {
      await screenSharing.start();
    }
  };

  const iconStyle = (active: boolean, isVideo: boolean = false) => {
    if (colorScheme === "dark") {
      return active
        ? { color: "white" }
        : isVideo
        ? videoIconDefaultStyle
        : iconDefaultStyle;
    }
    return { color: active ? "white" : "black" };
  };

  const handleToggleChat = () => {
    if (onMobile) {
      navigation.navigate("Chat");
    } else {
      toggleChat();
    }
  };

  return (
    <>
      <Portal>
        <Dialog
          visible={menuVisible}
          onDismiss={closeMenu}
          style={!onMobile && { alignSelf: "center", minWidth: 400 }}
        >
          {menu.map((item) => (
            <List.Item
              key={item.key}
              left={(props) => <List.Icon icon={item.icon} {...props} />}
              onPress={() => {
                item.onPress();
                closeMenu();
              }}
              title={item.title}
            />
          ))}
        </Dialog>
      </Portal>

      <Surface style={styles.surface}>
        <TouchableRipple
          style={styles.leftRipple}
          onPress={toggleAudio}
          {...rippleProps}
        >
          <View style={[styles.button, audio.enabled && activeStyle]}>
            <AudioStatus
              status={audio.enabled}
              size={iconSize}
              style={iconStyle(audio.enabled)}
            />
          </View>
        </TouchableRipple>
        <TouchableRipple
          {...rippleProps}
          style={styles.innerRipple}
          onPress={toggleVideo}
        >
          <View style={[styles.button, video.enabled && activeStyle]}>
            <VideoStatus
              status={video.enabled}
              size={iconSize}
              style={iconStyle(video.enabled, true)}
            />
          </View>
        </TouchableRipple>
        <TouchableRipple
          {...rippleProps}
          style={styles.innerRipple}
          onPress={toggleScreenSharing}
        >
          <View style={[styles.button, screenSharing.enabled && activeStyle]}>
            <Ionicons
              name="share-outline"
              size={iconSize}
              style={iconStyle(screenSharing.enabled)}
            />
          </View>
        </TouchableRipple>
        <TouchableRipple
          {...rippleProps}
          style={styles.innerRipple}
          onPress={handleToggleChat}
        >
          <View style={styles.button}>
            <Ionicons
              name="chatbox-outline"
              size={iconSize}
              style={iconDefaultStyle}
            />
            {unreadCount ? (
              <Badge style={styles.badge}>
                {unreadCount <= 99 ? unreadCount : "99+"}
              </Badge>
            ) : null}
          </View>
        </TouchableRipple>
        <TouchableRipple
          {...rippleProps}
          style={styles.innerRipple}
          onPress={openMenu}
        >
          <View style={styles.button}>
            <Ionicons
              name="ellipsis-horizontal-outline"
              size={iconSize}
              style={iconDefaultStyle}
            />
          </View>
        </TouchableRipple>
        <TouchableRipple
          {...rippleProps}
          style={styles.rightRipple}
          onPress={onExit}
        >
          <View
            style={[
              styles.button,
              {
                backgroundColor: colors.danger,
              },
            ]}
          >
            <Ionicons
              name="exit-outline"
              size={iconSize}
              style={colorScheme !== "dark" && { color: "white" }}
            />
          </View>
        </TouchableRipple>
      </Surface>
    </>
  );
};

const styles = StyleSheet.create({
  surface: {
    maxHeight: buttonSize,
    elevation: 12,
    borderRadius,
    flexDirection: "row",
    marginLeft: 10,
    marginRight: 10,
    backgroundColor: "white",
    width: "100%",
    maxWidth: buttonSize * 6,
    justifyContent: "center",
  },
  button: {
    aspectRatio: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "white",
  },
  leftRipple: {
    flex: 1,
    maxWidth: buttonSize,
    borderTopLeftRadius: 5,
    borderBottomLeftRadius: 5,
    marginRight: 1,
  },
  innerRipple: {
    flex: 1,
    maxWidth: buttonSize,
    marginRight: 1,
  },
  rightRipple: {
    flex: 1,
    maxWidth: buttonSize,
    borderTopRightRadius: 5,
    borderBottomRightRadius: 5,
  },
  badge: {
    position: "absolute",
    right: 0,
    top: 0,
    backgroundColor: Colors.danger,
  },
});

export default ControlWidget;
