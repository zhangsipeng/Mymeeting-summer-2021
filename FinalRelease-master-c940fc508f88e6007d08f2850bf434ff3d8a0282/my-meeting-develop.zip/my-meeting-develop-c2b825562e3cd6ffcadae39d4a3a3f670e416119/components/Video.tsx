import { useNavigation } from "@react-navigation/native";
import React from "react";
import { Pressable, useColorScheme, View } from "react-native";
import { Text } from "react-native-paper";
import { RTCView } from "react-native-webrtc-web-shim";

type VideoProps = {
  stream?: GeneralMediaStream;
  placeholder?: string;
  style?: object;
  video?: boolean;
  orientation?: Orientation;
};

const Video = ({
  stream,
  video,
  placeholder,
  style,
  orientation = "landscape",
  ...props
}: VideoProps) => {
  const navigation = useNavigation();
  const colorScheme = useColorScheme();

  if (!video || !stream) {
    return (
      <View
        style={[
          {
            flexDirection: "row",
            width: 320,
            height: 240,
            backgroundColor: "white",
            alignItems: "center",
            justifyContent: "center",
          },
          style,
        ]}
        {...props}
      >
        <Text
          style={{
            color: colorScheme === "dark" ? "white" : "black",
            fontSize: 20,
            textAlign: "center",
          }}
        >
          {placeholder || "无视频"}
        </Text>
      </View>
    );
  }

  const goFullScreen = () => {
    if (stream) {
      navigation.navigate("FullScreenVideo", {
        stream,
        orientation,
      });
    }
  };

  return (
    // 防止网页端video溢出
    <Pressable onPress={goFullScreen} style={{ width: "100%", height: "100%" }}>
      <RTCView
        stream={stream}
        style={[{ width: 320, height: 240, backgroundColor: "black" }, style]}
        {...props}
      />
    </Pressable>
  );
};

export default Video;
