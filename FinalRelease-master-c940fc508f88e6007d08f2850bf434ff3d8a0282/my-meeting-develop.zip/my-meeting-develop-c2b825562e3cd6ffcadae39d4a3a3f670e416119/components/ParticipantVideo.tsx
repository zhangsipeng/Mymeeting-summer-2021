import { Ionicons } from "@expo/vector-icons";
import * as React from "react";
import { Appearance, StyleSheet } from "react-native";
import { Text, View } from "../components/Themed";
import AudioStatus from "./AudioStatus";
import Video from "./Video";
import VideoStatus from "./VideoStatus";

type ParticipantVideoProps = {
  stream?: GeneralMediaStream;
  displayName: string;
  audio?: boolean;
  video?: boolean;
  style?: object;
  orientation?: Orientation;
};

const colorScheme = Appearance.getColorScheme();

const ParticipantVideo = ({
  stream,
  displayName,
  audio,
  video,
  style,
  orientation = "landscape",
}: ParticipantVideoProps) => {
  return (
    <View style={{ height: "100%", width: "100%" }}>
      <Video
        stream={stream}
        style={style}
        video={video}
        orientation={orientation}
      />
      <View style={styles.label}>
        <Ionicons
          name="person-outline"
          size={14}
          style={[{ marginRight: 3 }, styles.color]}
        />
        <Text style={[styles.displayName, styles.color]}>{displayName}</Text>
        <AudioStatus status={audio} size={16} style={styles.color} />
        <VideoStatus
          status={video}
          size={16}
          style={[{ marginTop: 1 }, styles.color]}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  label: {
    padding: 4,
    position: "absolute",
    left: 0,
    bottom: 0,
    borderTopRightRadius: 5,
    display: "flex",
    flexDirection: "row",
    backgroundColor:
      colorScheme === "dark" ? "rgba(0,0,0,0.4)" : "rgba(0,0,0,0.03)",
  },
  displayName: {
    fontSize: 13,
    paddingRight: 4,
    borderRightWidth: 1,
    borderRightColor: "#888",
  },
  color: {
    color: "#888",
  },
});

export default ParticipantVideo;
