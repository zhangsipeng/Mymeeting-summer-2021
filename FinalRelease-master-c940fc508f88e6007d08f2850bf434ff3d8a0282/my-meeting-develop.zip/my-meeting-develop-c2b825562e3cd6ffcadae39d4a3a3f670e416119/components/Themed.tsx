/**
 * Learn more about Light and Dark modes:
 * https://docs.expo.io/guides/color-schemes/
 */

import { Ionicons } from "@expo/vector-icons";
import * as React from "react";
import { Text as DefaultText, View as DefaultView } from "react-native";
import { Button as DefaultButton } from "react-native-paper";
import Colors from "../constants/Colors";
import useColorScheme from "../hooks/useColorScheme";

export function useThemeColor(
  props: { light?: string; dark?: string },
  colorName: keyof typeof Colors.light & keyof typeof Colors.dark
) {
  const theme = useColorScheme();
  const colorFromProps = props[theme];

  if (colorFromProps) {
    return colorFromProps;
  } else {
    return Colors[theme][colorName];
  }
}

type ThemeProps = {
  lightColor?: string;
  darkColor?: string;
};

export type TextProps = ThemeProps & DefaultText["props"];
export type ViewProps = ThemeProps & DefaultView["props"];

export function Text(props: TextProps) {
  const { style, lightColor, darkColor, ...otherProps } = props;
  const color = useThemeColor({ light: lightColor, dark: darkColor }, "text");

  return <DefaultText style={[{ color }, style]} {...otherProps} />;
}

export function View(props: ViewProps) {
  const { style, lightColor, darkColor, ...otherProps } = props;
  const backgroundColor = useThemeColor(
    { light: lightColor, dark: darkColor },
    "background"
  );

  return <DefaultView style={[{ backgroundColor }, style]} {...otherProps} />;
}

export type ButtonProps = React.ComponentProps<typeof DefaultButton>;

/**
 * 自定义React Native Paper Button，适配Ionicons
 */
export const Button = (props: ButtonProps) => {
  const { icon, ...otherProps } = props;

  if (typeof icon === "string") {
    return (
      <DefaultButton
        {...otherProps}
        icon={(props) => (
          // @ts-ignore
          <Ionicons name={icon} {...props} style={{ marginRight: -5 }} />
        )}
      />
    );
  }

  return <DefaultButton {...props} />;
};
