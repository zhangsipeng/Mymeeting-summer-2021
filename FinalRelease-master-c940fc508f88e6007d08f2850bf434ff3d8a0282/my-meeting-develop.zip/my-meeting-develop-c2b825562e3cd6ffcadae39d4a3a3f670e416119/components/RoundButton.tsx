import { Ionicons } from "@expo/vector-icons";
import React from "react";
import {
  Dimensions,
  GestureResponderEvent,
  StyleProp,
  TextStyle,
  View,
} from "react-native";
import { Subheading, TouchableRipple } from "react-native-paper";
import Colors from "../constants/Colors";
import { onMobile } from "../utils/helpers";

type RoundButtonProps = {
  icon: string;
  title: string;
  onPress: (event: GestureResponderEvent) => void;
  size?: number;
  iconStyle?: StyleProp<TextStyle>;
};

const RoundButton = ({
  icon,
  title,
  onPress,
  size = Math.min(Dimensions.get("screen").width / 4, 100),
  iconStyle,
}: RoundButtonProps) => (
  <View>
    <TouchableRipple
      borderless
      rippleColor={Colors.dark.ripple}
      onPress={onPress}
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: Colors.primary,
      }}
    >
      <Ionicons
        // @ts-ignore
        name={icon}
        size={size * 0.6}
        color="white"
        // @ts-ignore
        style={[iconStyle, !onMobile && { userSelect: "none" }]}
      />
    </TouchableRipple>
    <Subheading style={{ textAlign: "center" }}>{title}</Subheading>
  </View>
);

export default RoundButton;
