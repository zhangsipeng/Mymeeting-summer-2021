export default ({ config }) => {
  const versionName = process.env.VERSION_NAME;
  if (versionName) {
    config.version = versionName;
  }
  return {
    ...config,
  };
};
