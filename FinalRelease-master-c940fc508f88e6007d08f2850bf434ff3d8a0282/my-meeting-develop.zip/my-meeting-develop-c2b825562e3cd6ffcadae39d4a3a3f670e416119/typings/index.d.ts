/**
 * 视频视图
 */
type VideoLayout = "grid" | "list";

/**
 * 自定义Socket
 * @description 在socket Io的type基础上加上request方便请求
 */
type CustomSocket = import("socket.io-client").Socket & {
  request: (type: string, data?: {}) => Promise<any>;
};

/**
 * 通用视频流
 * @description TypeScript(Web)与react-native-webrtc的MediaStream类型不同，但可兼容
 */
type GeneralMediaStream =
  | MediaStream
  | import("react-native-webrtc").MediaStream;

type Consumer = import("mediasoup-client/lib/types").Consumer;

type RtpParameters = import("mediasoup-client/lib/types").RtpParameters;

type Producer = import("mediasoup-client/lib/types").Producer;

type ProducerState = {
  webcam: StreamProducer;
  screen: StreamProducer;
};

type StreamProducer = {
  audio?: Producer;
  video?: Producer;
  stream: GeneralMediaStream;
};

type screenSharingState = {
  consumer?: Consumer;
  stream?: GeneralMediaStream;
  peer?: PeerInfo;
  active: boolean;
};

type MeetingInfo = {
  roomId?: string;
  password?: string;
};

type ProducerInfo = {
  id: string;
  role: Role;
  displayName: string;
  platform: "android" | "ios" | "web" | "windows" | "macos";
  rtpCapabilities: RtpCapabilities;
};

type ConsumerInfo = {
  id: string;
  producerId: string;
  rtpParameters: RtpParameters;
  kind: "audio" | "video";
};

type ConsumerStatus = "paused" | "playing" | "closed";

type PeerInfo = {
  id: string;
  role: Role;
  displayName: string;
  platform: "android" | "ios" | "web" | "windows" | "macos";
  address: string;
  stream: GeneralMediaStream;
  videoConsumer: Consumer;
  audioConsumer: Consumer;
};

type ScheduledMeeting = {
  roomId: string;
  startTime: Date;
  stopTime: Date;
  password: string;
};

/**
 * Server发来的socket请求格式
 */
type ServerRequestType = {
  method: string;
  data: any;
};

/**
 * 媒体设备状态及控制
 */
type MediaStateControl = {
  audio: {
    enabled: boolean;
    enable: Function;
    disable: Function;
  };
  video: {
    enabled: boolean;
    enable: Function;
    disable: Function;
  };
  screenSharing: {
    enabled: boolean;
    start: Function;
    stop: Function;
  };
};

/*
 * Server发来的socket通知格式
 */
type ServerNotificationType = {
  method: string;
  data: any;
};

type AppData = {
  mediaType: MediaType;
};

type NewConsumerRequestData = {
  peerId: string;
  kind: "audio" | "video";
  rtpParameters: RtpParameters;
  producerId: string;
  id: string;
  appData: AppData;
};

type TextMessage = {
  type: "text";
  content: string;
};

type FileMessage = {
  type: "file";
  filename: string;
  size: number;
  time: Date;
};

type PeerRoleChangedRequestData = {
  peerId: string;
  role: Role;
};

type ChangeRoleRequestData = {
  role: Role;
};

type Message = {
  from: string;
  to: string;
  message: TextMessage | FileMessage;
  time: Date;
};

type RequestResponse = {
  status: "succeed" | "fail";
  message: string;
};

type ReturnIdResponse = {
  peerId: string;
  roomId: string;
};

type RoomRights = {
  audioMuted: boolean;
  webcamMuted: boolean;
  screenMuted: boolean;
};

type Orientation = "portrait" | "landscape";
