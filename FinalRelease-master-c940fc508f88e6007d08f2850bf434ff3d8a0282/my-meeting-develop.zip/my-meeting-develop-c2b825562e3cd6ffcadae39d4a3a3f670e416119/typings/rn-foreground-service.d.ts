/* eslint-disable camelcase */

type NotificationConfig = {
  id: number;
  title: string;
  message: string;
  number?: string;
  icon?: string | "ic_notification";
  largeIcon?: string | "ic_launcher";
  visibility?: "private" | "public" | "secret";
  ongoing?: boolean;
  importance?: number[];
};

type NotificationButtonsConfig = {
  button?: boolean;
  buttonText?: string;
  buttonOnPress?: string;
  button2?: boolean;
  button2Text?: string;
  button2OnPress?: string;
  mainOnPress?: string;
};

type TaskConfig = {
  delay?: number;
  onLoop?: boolean;
  taskId?: string;
  onSuccess?: Function;
  onError?: Function;
};

type TaskState = {
  task: Task;
  nextExecutionTime: Date;
  delay: number;
  onLoop: boolean;
  taskId: TaskID;
  onSuccess: Function;
  onError: Function;
};

type ServiceConfig = NotificationConfig & NotificationButtonsConfig;
type Task = Function;
type TaskID = string;

declare module "@supersami/rn-foreground-service" {
  export function register(): void;

  export function start(args: ServiceConfig): Promise<void>;
  export function update(args: ServiceConfig): Promise<void>;
  export function stop(): void;
  export function is_running(): boolean;

  export function add_task(task: Task, config: TaskConfig): TaskID;
  export function update_task(task: Task, config: TaskConfig): TaskID;
  export function remove_task(taskId: TaskID): void;
  export function is_task_running(): boolean;
  export function remove_all_tasks(): void;
  export function get_task(taskId: TaskID): TaskState;
  export function get_all_tasks(): TaskState[];
}
