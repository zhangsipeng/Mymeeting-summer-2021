declare module "react-native-webrtc-web-shim" {
  export * from "react-native-webrtc";

  export interface RTCViewProps {
    stream: GeneralMediaStream;
    mirror?: boolean | undefined;
    zOrder?: number | undefined;
    objectFit?: "contain" | "cover" | undefined;
    style?: ViewStyle | undefined;
  }

  export class RTCView extends (await import("react")).Component<
    RTCViewProps,
    any
  > {}
}
