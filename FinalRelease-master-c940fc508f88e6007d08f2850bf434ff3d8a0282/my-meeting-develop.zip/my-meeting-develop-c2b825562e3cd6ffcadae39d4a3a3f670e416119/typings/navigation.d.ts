type RootStackParamList = {
  Root: undefined;
  FullScreenVideo: {
    stream: GeneralMediaStream;
    orientation?: Orientation;
  };
  Meeting: { peerId: string; roomId: string };
  NotFound: undefined;
};

type BottomTabParamList = {
  StartMeeting: undefined;
  Schedule: undefined;
  Settings: undefined;
};

type StartMeetingStackParamList = {
  StartMeeting: undefined;
};

type MeetingStackParamList = {
  Meeting: {
    displayName?: string;
    roomId?: string;
    password: string;
  };
  Chat: undefined;
  Participants: undefined;
};

type ScheduleStackParamList = {
  Schedule: undefined;
};

type SettingsStackParamList = {
  Settings: undefined;
};
