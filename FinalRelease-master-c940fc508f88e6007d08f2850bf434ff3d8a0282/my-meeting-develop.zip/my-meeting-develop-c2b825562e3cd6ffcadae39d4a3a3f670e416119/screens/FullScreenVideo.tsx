import { StackScreenProps } from "@react-navigation/stack";
import * as ScreenOrientation from "expo-screen-orientation";
import { setStatusBarHidden } from "expo-status-bar";
import React, { useEffect } from "react";
import { Dimensions, Pressable, View } from "react-native";
import { RTCView } from "react-native-webrtc-web-shim";
import { onMobile } from "../utils/helpers";

const FullScreenVideo = ({
  route,
  navigation,
}: StackScreenProps<RootStackParamList, "FullScreenVideo">) => {
  const { stream, orientation } = route.params;
  const videoStyle = {
    width: Dimensions.get("screen").height,
    height: "100%", //Dimensions.get("screen").width,
  };

  useEffect(() => {
    if (!onMobile) {
      return;
    }
    if (!orientation || orientation === "landscape") {
      ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE);
    } else {
      ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT);
    }
    setStatusBarHidden(true, "slide");
  }, []);

  const exitFullScreen = () => {
    if (onMobile) {
      ScreenOrientation.unlockAsync();
      setStatusBarHidden(false, "slide");
    }
    if (navigation.canGoBack()) {
      navigation.goBack();
    }
  };

  return (
    <View
      style={{
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Pressable onPress={exitFullScreen}>
        <RTCView stream={stream} style={videoStyle} />
      </Pressable>
    </View>
  );
};

export default FullScreenVideo;
