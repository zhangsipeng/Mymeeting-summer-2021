import { useNavigation } from "@react-navigation/native";
import * as React from "react";
import { useRef, useState } from "react";
import { StyleSheet } from "react-native";
import { Button, Dialog, Portal, Title } from "react-native-paper";
import CreateMeetingForm from "../components/CreateMeetingForm";
import JoinMeetingForm from "../components/JoinMeetingForm";
import RoundButton from "../components/RoundButton";
import ScheduleMeetingDialog from "../components/ScheduleMeetingDialog";
import { View } from "../components/Themed";
import Alert from "../utils/alert";
import { onMobile } from "../utils/helpers";
import Schedule from "./Schedule";

const StartMeeting = () => {
  const navigation = useNavigation();

  const createFormRef =
    useRef<React.ElementRef<typeof CreateMeetingForm>>(null);
  const joinFormRef = useRef<React.ElementRef<typeof JoinMeetingForm>>(null);

  const [createMeetingVisible, setCreateMeetingVisible] = useState(false);
  const [joinMeetingVisible, setJoinMeetingVisible] = useState(false);
  const [scheduleMeetingVisible, setScheduleMeetingVisible] = useState(false);

  const joinMeeting = () => {
    joinFormRef.current
      ?.validateAndGetValues()
      .then((values) => {
        setJoinMeetingVisible(false);
        navigation.navigate("Meeting", {
          screen: "Meeting",
          params: values,
        });
      })
      .catch((error: string) => Alert("错误", error));
  };

  const createMeeting = () => {
    createFormRef.current
      ?.validateAndGetValues()
      .then((values) => {
        setCreateMeetingVisible(false);
        navigation.navigate("Meeting", {
          screen: "Meeting",
          params: values,
        });
      })
      .catch((error: string) => Alert("错误", error));
  };

  const onCreateMeetingPressed = async () => {
    setCreateMeetingVisible(true);
  };

  const onJoinMeetingPressed = async () => {
    setJoinMeetingVisible(true);
  };
  const onScheduleMeetingPressed = async () => {
    setScheduleMeetingVisible(true);
  };

  return (
    <View style={styles.container}>
      <Title style={styles.title}>MyMeeting</Title>
      <View style={styles.content}>
        {!onMobile && (
          <View style={styles.schedule}>
            <Title style={{ textAlign: "center", fontSize: 20 }}>日程</Title>
            <Schedule />
          </View>
        )}
        <View style={styles.buttons}>
          <RoundButton
            icon="add-outline"
            title="创建会议"
            onPress={onCreateMeetingPressed}
            // 图标居中
            iconStyle={{ paddingLeft: 5 }}
          />
          <RoundButton
            icon="enter-outline"
            title="加入会议"
            onPress={onJoinMeetingPressed}
            // 视觉修正
            iconStyle={{ paddingRight: 5 }}
          />
          <RoundButton
            icon="calendar"
            title="预定会议"
            onPress={onScheduleMeetingPressed}
          />
        </View>
      </View>
      <Portal>
        <Dialog
          visible={createMeetingVisible}
          onDismiss={() => setCreateMeetingVisible(false)}
          style={!onMobile && styles.dialog}
        >
          <Dialog.Title>创建会议</Dialog.Title>
          <Dialog.Content>
            <CreateMeetingForm
              ref={createFormRef}
              onSubmit={createMeeting}
              formItemStyle={styles.formItem}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={createMeeting}>创建会议</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
      <Portal>
        <Dialog
          visible={joinMeetingVisible}
          onDismiss={() => setJoinMeetingVisible(false)}
          style={!onMobile && styles.dialog}
        >
          <Dialog.Title>加入会议</Dialog.Title>
          <Dialog.Content>
            <JoinMeetingForm
              ref={joinFormRef}
              onSubmit={joinMeeting}
              formItemStyle={styles.formItem}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={joinMeeting}>加入会议</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
      <Portal>
        <ScheduleMeetingDialog
          visible={scheduleMeetingVisible}
          onDismiss={() => setScheduleMeetingVisible(false)}
        />
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignContent: "center",
    flexDirection: "column",
  },
  title: {
    textAlign: "center",
    fontSize: 30,
    marginBottom: 50,
    marginTop: 50,
  },
  content: {
    padding: onMobile ? 0 : 50,
    paddingTop: 0,
    paddingBottom: 0,
    flexDirection: "row",
  },
  schedule: {
    flex: 1,
  },
  buttons: {
    display: "flex",
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
  },
  dialog: {
    minWidth: 500,
    alignSelf: "center",
  },
  formItem: {
    margin: 10,
  },
});

export default StartMeeting;
