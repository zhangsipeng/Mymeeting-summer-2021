import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation } from "@react-navigation/core";
import React, { useEffect, useState } from "react";
import { StyleSheet, View, VirtualizedList } from "react-native";
import {
  Button,
  Headline,
  IconButton,
  List,
  Text,
  Title,
} from "react-native-paper";
import Alert from "../utils/alert";

const ScheduleItem = ({
  roomId,
  startTime,
  stopTime,
  password,
  index,
}: ScheduledMeeting & { index: number }) => {
  const navigation = useNavigation();

  const renderTime = (time: Date) => {
    const date = new Date(time);
    return `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
  };

  const joinMeeting = () => {
    navigation.navigate("Meeting", {
      screen: "Meeting",
      params: { roomId, password, join: true },
    });
  };

  return (
    <List.Item
      left={() => (
        <View style={styles.alignCenter}>
          <Title style={styles.index}>{index + 1}</Title>
        </View>
      )}
      title={
        <View>
          <View>
            <Title>会议号码：{roomId}</Title>
          </View>
          <View>
            <Text>密码：{password || "无密码"}</Text>
          </View>
        </View>
      }
      description={`时间：${renderTime(startTime)} - ${renderTime(stopTime)}`}
      right={() => (
        <View style={[styles.alignCenter, { paddingRight: 5 }]}>
          <IconButton icon="enter-outline" size={30} onPress={joinMeeting} />
        </View>
      )}
    />
  );
};

const Schedule = () => {
  const navigation = useNavigation();
  const [meetings, setMeetings] = useState<ScheduledMeeting[]>([]);

  const retrieveData = async () => {
    try {
      const value = await AsyncStorage.getItem("scheduledMeetings");
      if (value !== null) {
        setMeetings(JSON.parse(value));
      } else {
        setMeetings([]);
      }
    } catch (error) {
      Alert("错误", "数据读取失败，错误：" + (error as Error).message);
    }
  };

  useEffect(() => {
    retrieveData();
  }, []);

  useEffect(
    () =>
      navigation.addListener("focus", () => {
        retrieveData();
      }),
    [navigation]
  );

  return (
    <View style={styles.container}>
      <VirtualizedList<ScheduledMeeting>
        data={meetings}
        getItem={(data, index) => data[index]}
        getItemCount={(data) => data.length}
        keyExtractor={(_, index) => index.toString()}
        renderItem={({ item, index }) => (
          <ScheduleItem {...item} index={index} />
        )}
        ListEmptyComponent={
          <View style={[styles.alignCenter, { flexDirection: "column" }]}>
            <Ionicons name="file-tray-outline" size={50} />
            <Headline>您还没有预定会议</Headline>
            <Button
              mode="contained"
              onPress={() => navigation.navigate("Root")}
              style={{ marginTop: 10 }}
            >
              现在预定
            </Button>
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 10,
    paddingBottom: 10,
    backgroundColor: "white",
  },
  index: {
    margin: 10,
    color: "gray",
    fontSize: 25,
  },
  alignCenter: {
    flexDirection: "row",
    alignItems: "center",
  },
});

export default Schedule;
