import { Ionicons } from "@expo/vector-icons";
import * as React from "react";
import { useEffect, useState } from "react";
import { StyleSheet, ToastAndroid, View, VirtualizedList } from "react-native";
import {
  Button,
  Headline,
  IconButton,
  List,
  Menu,
  Text,
  Title,
  useTheme,
} from "react-native-paper";
import AudioStatus from "../components/AudioStatus";
import VideoStatus from "../components/VideoStatus";
import { MediaType, Role } from "../constants/enums";
import useParticipantsManager from "../hooks/useParticipantsManager";
import usePeerManager from "../hooks/usePeerManager";
import useProducerManager from "../hooks/useProducerManager";
import { consumerStatus, onMobile } from "../utils/helpers";

type ParticipantItemProps = {
  participant: {
    displayName: string;
    audio?: boolean;
    video?: boolean;
    id: string;
    role: Role;
  };
  index: number;
  canManage: boolean;
};

const ParticipantItem = ({
  participant,
  index,
  canManage,
}: ParticipantItemProps) => {
  const participantsManager = useParticipantsManager();

  const { colors } = useTheme();
  const iconSize = 20;
  const [menuVisible, setMenuVisible] = useState(false);

  const openMenu = () => setMenuVisible(true);
  const closeMenu = () => setMenuVisible(false);

  const renderRole = (role: Role) => {
    switch (role) {
      case "Host":
        return "(主持人)";
      case "CoHost":
        return "(联席主持人)";
      default:
        return "";
    }
  };

  return (
    <List.Item
      title={
        <Text style={{ fontSize: 16 }}>
          {participant.displayName} {renderRole(participant.role)}
        </Text>
      }
      left={() => <Title style={styles.index}>{index + 2}</Title>}
      right={() => (
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <AudioStatus
            status={participant.audio}
            size={iconSize}
            style={styles.icon}
          />
          <VideoStatus
            status={participant.video}
            size={iconSize}
            style={styles.icon}
          />
          {canManage && (
            <Menu
              visible={menuVisible}
              onDismiss={closeMenu}
              anchor={
                <IconButton
                  icon="ellipsis-horizontal-outline"
                  onPress={openMenu}
                />
              }
            >
              <Menu.Item
                key="mute"
                icon="volume-mute-outline"
                disabled={!participant.audio}
                onPress={() =>
                  participantsManager.mutePeer(participant.id, MediaType.audio)
                }
                title="静音"
              />
              <Menu.Item
                key="cameraOff"
                icon="volume-mute-outline"
                disabled={!participant.video}
                onPress={() =>
                  participantsManager.mutePeer(participant.id, MediaType.webcam)
                }
                title="关闭视频"
              />
              <Menu.Item
                key="co-host"
                icon="person-add-outline"
                disabled={!(participant.role === Role.Participant)}
                onPress={() =>
                  participantsManager.changePeerRole(
                    participant.id,
                    Role.CoHost
                  )
                }
                title="设为联席主持人"
              />
              <Menu.Item
                key="kick"
                icon="exit-outline"
                onPress={() => participantsManager.kickOut(participant.id)}
                title={<Text style={{ color: colors.danger }}>踢出</Text>}
              />
            </Menu>
          )}
        </View>
      )}
      style={{ borderBottomColor: "#888", borderBottomWidth: 1 }}
    />
  );
};

const Participants = () => {
  const participantsManager = useParticipantsManager();
  const producerManager = useProducerManager();
  const peerManager = usePeerManager();

  const [roomRights, setRoomRights] = useState<RoomRights>({
    audioMuted: false,
    webcamMuted: false,
    screenMuted: false,
  });

  useEffect(() => {
    refreshRoomRights();
  }, []);

  const refreshRoomRights = async () => {
    setRoomRights(await participantsManager.getRoomRights());
  };

  const handleMute = async (type: MediaType) => {
    switch (type) {
      case MediaType.audio:
        !roomRights.audioMuted
          ? await participantsManager.muteAll(type)
          : await participantsManager.unmuteAll(type);
        ToastAndroid.show(
          roomRights.audioMuted ? "已取消全体静音" : "已全体静音",
          ToastAndroid.SHORT
        );
        break;
      case MediaType.webcam:
        !roomRights.webcamMuted
          ? await participantsManager.muteAll(type)
          : await participantsManager.unmuteAll(type);
        break;
      case MediaType.screen:
        !roomRights.screenMuted
          ? await participantsManager.muteAll(type)
          : await participantsManager.unmuteAll(type);
        ToastAndroid.show(
          roomRights.screenMuted ? "已禁止屏幕共享" : "已允许屏幕共享",
          ToastAndroid.SHORT
        );
        break;
      default:
        break;
    }
    await refreshRoomRights();
  };

  return (
    <View style={styles.container}>
      {!onMobile && (
        <View style={styles.title}>
          <Ionicons name="people-outline" size={30} style={styles.titleIcon} />
          <Headline>参会者</Headline>
        </View>
      )}
      <VirtualizedList<PeerInfo>
        ListHeaderComponent={
          <>
            {producerManager.producerInfo?.role !== Role.Participant && (
              <View style={styles.controls}>
                <Button
                  mode="contained"
                  icon={
                    roomRights.audioMuted ? "mic-outline" : "mic-off-outline"
                  }
                  onPress={() => handleMute(MediaType.audio)}
                  style={styles.button}
                >
                  {roomRights?.audioMuted ? "取消全体静音" : "全体静音"}
                </Button>
                <Button
                  mode="contained"
                  icon="easel-outline"
                  onPress={() => handleMute(MediaType.screen)}
                  style={styles.button}
                >
                  {roomRights?.screenMuted ? "允许屏幕共享" : "禁止屏幕共享"}
                </Button>
              </View>
            )}
            <ParticipantItem
              participant={{
                displayName:
                  producerManager.producerInfo?.displayName || "未知",
                id: producerManager.producerInfo?.id || "未知",
                audio: producerManager.webcam.audio.enabled,
                video: producerManager.webcam.video.enabled,
                role: producerManager.producerInfo?.role
                  ? producerManager.producerInfo.role
                  : Role.Participant,
              }}
              canManage={false}
              index={-1}
            />
          </>
        }
        initialNumToRender={10}
        data={Array.from(peerManager.peers.values())}
        renderItem={({ item, index }) => (
          <ParticipantItem
            participant={{
              displayName: item.displayName,
              id: item.id,
              audio: consumerStatus(item.audioConsumer),
              video: consumerStatus(item.videoConsumer),
              role: item.role,
            }}
            index={index}
            canManage={producerManager.producerInfo?.role !== Role.Participant}
          />
        )}
        keyExtractor={(peer) => peer.id}
        getItem={(data, index) => data[index]}
        getItemCount={(data) => data.length}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 10,
    paddingBottom: 10,
    backgroundColor: "white",
  },
  title: {
    padding: 20,
    paddingTop: 0,
    paddingBottom: 10,
    borderBottomColor: "#ccc",
    borderBottomWidth: 1,
    borderStyle: "solid",
    flexDirection: "row",
  },
  titleIcon: {
    marginRight: 10,
    marginTop: 3,
  },
  controls: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-around",
    flexWrap: "wrap",
  },
  button: {
    margin: 5,
  },
  index: {
    margin: 5,
    marginTop: 7,
    width: 20,
    color: "gray",
    fontSize: 16,
  },
  icon: { marginRight: 5 },
});

export default Participants;
