import { Ionicons } from "@expo/vector-icons";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system";
import * as React from "react";
import { useEffect, useRef, useState } from "react";
import { StyleSheet, VirtualizedList } from "react-native";
import {
  Button,
  Chip,
  Dialog,
  Headline,
  Paragraph,
  Portal,
  ProgressBar,
  Snackbar,
  TextInput,
} from "react-native-paper";
import Message from "../components/Message";
import { View } from "../components/Themed";
import { serverUrl } from "../constants/serverConfig";
import useChatManager from "../hooks/useChatManager";
import { MeetingContainer } from "../hooks/useMeetingContainer";
import { onMobile } from "../utils/helpers";

const Chat = () => {
  const [text, setText] = useState<string>("");
  const listRef = useRef<VirtualizedList<Message>>(null);
  const [snackbarVisible, setSnackbarVisible] = useState<boolean>(false);
  const [uploadProgress, setUploadProgress] = useState<number | undefined>(
    undefined
  );
  const [uploading, setUploading] = useState<boolean>(false);
  const [fileName, setFileName] = useState<string>("");
  const {
    unreadCount: [, setUnreadCount],
  } = MeetingContainer.useContainer();
  const { send: onSend, messages } = useChatManager();

  // 进入时清除未读数
  useEffect(() => setUnreadCount(0), []);

  useEffect(() => {
    listRef.current?.scrollToEnd(); // TODO: Use view height instead of screen height
  }, [messages]);

  const onDismissSnackBar = () => setSnackbarVisible(false);

  const sendTextMessage = async () => {
    if (!text) {
      return;
    }
    await onSend({ type: "text", content: text } as TextMessage);
    setText("");
  };

  const sendFile = async () => {
    // 选择文件并自动复制到缓存目录
    const result = await DocumentPicker.getDocumentAsync();
    if (result.type === "cancel") {
      return;
    }
    const { uri, name, size } = result;
    const message = {
      type: "file",
      filename: name,
      size,
    } as FileMessage;
    setFileName(name);
    setUploading(true);
    const data = await fetch(
      serverUrl + `uploadUrl?name=${encodeURIComponent(name)}&size=${size}`
    )
      .then((response) => response.json())
      .then((data) => {
        message.time = data.time;
        return data;
      });

    if (!onMobile) {
      setUploadProgress(0);
      const xhr = new XMLHttpRequest();
      xhr.open("PUT", data.url);
      xhr.onreadystatechange = () => {
        if (xhr.status === 200) {
          setUploading(false);
          setSnackbarVisible(true);
          onSend(message);
        } else {
          console.log("[Error] Upload failed");
          setUploading(false);
          setUploadProgress(undefined);
        }
      };
      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const percent = event.loaded / event.total;
          setUploadProgress(percent);
        }
      };
      xhr.send(result.file);
    } else {
      setUploadProgress(undefined);
      await FileSystem.uploadAsync(data.url, "file://" + uri, {
        httpMethod: "PUT",
      }).then(() => {
        FileSystem.deleteAsync("file://" + uri, { idempotent: true }); // 删除缓存
      });
      setUploading(false);
      setSnackbarVisible(true);
      onSend(message);
    }
  };

  return (
    <View style={styles.container}>
      {!onMobile && (
        <View style={styles.title}>
          <Ionicons name="chatbox-outline" size={30} style={styles.icon} />
          <Headline>讨论</Headline>
        </View>
      )}
      <View style={styles.messages}>
        <VirtualizedList<Message>
          onEndReached={() => setUnreadCount(0)}
          ref={listRef}
          initialNumToRender={10}
          data={messages}
          renderItem={({ item }) => <Message message={item} />}
          keyExtractor={(item) => item.time.getTime().toString()}
          getItem={(data, index) => data[index]}
          getItemCount={(data) => data.length}
        />
      </View>
      <View style={styles.input}>
        <Chip icon="folder-outline" onPress={sendFile}>
          分享文件
        </Chip>
        <TextInput
          mode="outlined"
          label="发送信息..."
          onChangeText={(text) => setText(text)}
          value={text}
          onSubmitEditing={sendTextMessage}
          multiline={true}
          right={
            <TextInput.Icon name="send-outline" onPress={sendTextMessage} />
          }
          blurOnSubmit={false}
        />
      </View>
      <Portal>
        <Dialog visible={uploading} dismissable={false}>
          <Dialog.Title>上传文件</Dialog.Title>
          <Dialog.Content>
            <Paragraph>正在上传{fileName}...</Paragraph>
            <ProgressBar
              visible={uploading}
              indeterminate={!uploadProgress}
              progress={uploadProgress}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setUploading(false)}>取消</Button>
          </Dialog.Actions>
        </Dialog>
        <Snackbar
          visible={snackbarVisible}
          onDismiss={onDismissSnackBar}
          duration={2000}
          action={{
            label: "确定",
            onPress: onDismissSnackBar,
          }}
        >
          上传成功
        </Snackbar>
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 10,
    paddingBottom: 10,
    flexDirection: "column",
    alignContent: "space-between",
    width: "100%",
  },
  title: {
    padding: 20,
    paddingTop: 0,
    paddingBottom: 10,
    borderBottomColor: "#ccc",
    borderBottomWidth: 1,
    borderStyle: "solid",
    flexDirection: "row",
  },
  icon: {
    marginRight: 10,
    marginTop: 3,
  },
  messages: {
    flexBasis: 3,
    flexGrow: 7,
  },
  input: {
    padding: 10,
  },
});

export default Chat;
