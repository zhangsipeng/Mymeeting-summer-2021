import { useFocusEffect } from "@react-navigation/native";
import { StackScreenProps } from "@react-navigation/stack";
import * as React from "react";
import { useEffect, useState } from "react";
import { BackHandler, StatusBar, StyleSheet, View } from "react-native";
import Spinner from "react-native-loading-spinner-overlay";
import { Portal, Surface, Text, useTheme } from "react-native-paper";
import { registerGlobals } from "react-native-webrtc-web-shim";
import ControlWidget from "../components/ControlWidget";
import EditDisplayNameDialog from "../components/EditDisplayNameDialog";
import MeetingInfoDialog from "../components/MeetingInfoDialog";
import ParticipantVideo from "../components/ParticipantVideo";
import VideoPages from "../components/VideoPages";
import { MeetingStatus, Role } from "../constants/enums";
import { MeetingContainer } from "../hooks/useMeetingContainer";
import useMeetingManager from "../hooks/useMeetingManager";
import usePeerManager from "../hooks/usePeerManager";
import useProducerManager from "../hooks/useProducerManager";
import Alert from "../utils/alert";
import {
  consumerStatus,
  getOrientation,
  goBack,
  onMobile,
} from "../utils/helpers";
import Chat from "./Chat";
import Participants from "./Participants";

const Meeting = ({
  route,
  navigation,
}: StackScreenProps<MeetingStackParamList, "Meeting">) => {
  const { colors } = useTheme();
  const { displayName, roomId, password } = route.params ?? {};

  const [layout, setLayout] = useState<VideoLayout>("grid");
  const [showMeetingInfo, setShowMeetingInfo] = useState<boolean>(false);

  const [showNameDialog, setShowNameDialog] = useState<boolean>(false);

  const [showChat, setShowChat] = useState<boolean>(false);
  const [showParticipants, setShowParticipants] = useState<boolean>(false);

  const meetingManager = useMeetingManager();
  const {
    webcam,
    screenSharing: localScreenSharing,
    producerInfo,
  } = useProducerManager();
  const peerManager = usePeerManager();
  const {
    meetingInfo: [meetingInfo],
    meetingStatus: [meetingStatus],
  } = MeetingContainer.useContainer();

  // close the socket when exiting
  // hardware back button
  useFocusEffect(() => {
    const onBackPress = () => {
      handleStopMeeting();
      return true;
    };
    BackHandler.addEventListener("hardwareBackPress", onBackPress);
    return () =>
      BackHandler.removeEventListener("hardwareBackPress", onBackPress);
  });

  // init the meeting
  useEffect(() => {
    if (onMobile) {
      registerGlobals();
    }
    startMeeting(displayName);
  }, []);

  useEffect(() => {
    if (!roomId && meetingInfo?.roomId) {
      navigation.setParams({ roomId: meetingInfo.roomId });
    }
  }, [meetingInfo?.roomId]);

  const switchLayout = () => {
    setLayout((layout) => (layout === "grid" ? "list" : "grid"));
  };

  const startMeeting = (displayName?: string) => {
    if (!displayName) {
      setShowNameDialog(true);
      return;
    }
    if (roomId) {
      meetingManager.joinMeeting(roomId, displayName, password);
    } else {
      meetingManager.createMeeting(displayName, password);
    }
  };

  const handleStopMeeting = async () => {
    Alert(
      "结束会议",
      "您确定要结束会议吗？",
      [
        {
          text: "取消",
          style: "cancel",
        },
        {
          text: "确定",
          onPress: async () => {
            if (await meetingManager.stopMeeting()) {
              meetingManager.cleanUp();
              goBack(navigation);
            }
          },
          style: "destructive",
        },
      ],
      { cancelable: true }
    );
  };

  const handleExitMeeting = () => {
    Alert(
      "退出会议",
      "您确定要退出会议吗？",
      [
        {
          text: "取消",
          style: "cancel",
        },
        {
          text: "确定",
          onPress: async () => {
            await meetingManager.exitMeeting();
          },
          style: "destructive",
        },
      ],
      { cancelable: true }
    );
  };

  const handleNameSubmit = (displayName: string) => {
    navigation.setParams({ displayName });
    setShowNameDialog(false);
    startMeeting(displayName);
  };

  return (
    <View style={styles.container}>
      <Spinner
        visible={meetingStatus === MeetingStatus.Connecting}
        textContent="正在连接..."
        // 使用StyleSheet在Web端会报错
        textStyle={{ color: "white" }}
        animation="fade"
      />
      {showParticipants && (
        <View style={{ flex: 2 }}>
          <Participants />
        </View>
      )}
      <View style={styles.content}>
        {!onMobile && (
          <Surface style={styles.topLabel}>
            <Text>会议号：{meetingInfo?.roomId ?? "加载中"}</Text>
          </Surface>
        )}
        <VideoPages layout={layout}>
          {Array.from(peerManager.peers.values()).map((peer) => {
            return (
              <ParticipantVideo
                displayName={peer.displayName}
                stream={peer.stream}
                audio={consumerStatus(peer.audioConsumer)}
                video={consumerStatus(peer.videoConsumer)}
                style={styles.video}
                key={peer.id}
                orientation={getOrientation(peer.platform)}
              />
            );
          })}
        </VideoPages>
        <View style={styles.control}>
          <ControlWidget
            audio={webcam.audio}
            video={webcam.video}
            screenSharing={localScreenSharing}
            onExit={handleExitMeeting}
            toggleChat={() => setShowChat(!showChat)}
            menu={[
              {
                key: "switchLayout",
                icon: "grid-outline",
                onPress: switchLayout,
                title: "切换视图",
              },
              {
                key: "participantList",
                icon: "people-outline",
                onPress: () =>
                  onMobile
                    ? navigation.navigate("Participants")
                    : setShowParticipants(!showParticipants),
                title: "参会者列表",
              },
              ...(onMobile && webcam.video.enabled
                ? [
                    {
                      key: "switchCamera",
                      icon: "camera-reverse-outline",
                      onPress: () => {
                        webcam.stream
                          .getVideoTracks()
                          // @ts-ignore
                          .forEach((track) => track._switchCamera());
                      },
                      title: "切换摄像头",
                    },
                  ]
                : []),
              {
                key: "meetingInfo",
                icon: "information-outline",
                onPress: () => setShowMeetingInfo(true),
                title: "会议详情",
              },
              ...(producerInfo?.role === Role.Host
                ? [
                    {
                      key: "stopMeeting",
                      icon: "stop-outline",
                      onPress: handleStopMeeting,
                      title: (
                        <Text style={{ color: colors.danger }}>结束会议</Text>
                      ),
                    },
                  ]
                : []),
            ]}
          />
        </View>
        <Portal>
          <MeetingInfoDialog
            name={displayName}
            info={meetingInfo}
            visible={showMeetingInfo}
            onDismiss={() => setShowMeetingInfo(false)}
          />
        </Portal>
        <Portal>
          <EditDisplayNameDialog
            visible={showNameDialog}
            onFinish={handleNameSubmit}
            onCancel={() => goBack(navigation)}
          />
        </Portal>
      </View>
      {showChat && (
        <View style={{ flex: 2 }}>
          <Chat />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  topLabel: {
    padding: 10,
    borderRadius: 5,
    elevation: 2,
  },
  container: {
    height: onMobile ? "100%" : "100vh",
    flexDirection: "row",
  },
  content: {
    height: onMobile ? "100%" : "100vh",
    alignItems: "center",
    paddingTop: onMobile ? StatusBar.currentHeight : 0,
    flex: 6,
  },
  control: {
    padding: 10,
    width: "100%",
    alignItems: "center",
  },
  video: {
    width: "100%",
    height: "100%",
  },
});

export default Meeting;
