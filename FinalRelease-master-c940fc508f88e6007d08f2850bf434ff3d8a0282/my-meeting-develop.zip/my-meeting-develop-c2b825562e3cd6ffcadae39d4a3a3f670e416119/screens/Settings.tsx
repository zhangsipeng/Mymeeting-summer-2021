import Constants from "expo-constants";
import { AppManifest } from "expo-constants/build/Constants.types";
import * as Updates from "expo-updates";
import * as React from "react";
import { useState } from "react";
import { Appearance, StyleSheet, View } from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import { Button, Dialog, List, Paragraph, Portal } from "react-native-paper";
import Alert from "../utils/alert";

const Settings = () => {
  const [showDebugInfo, setShowDebugInfo] = useState<boolean>(false);
  const [showVersionInfo, setShowVersionInfo] = useState<boolean>(false);
  const manifest: AppManifest | null = Constants.manifest;

  const checkUpdate = () => {
    Updates.checkForUpdateAsync()
      .then((result) => {
        if (result.isAvailable) {
          Alert("检查更新", "有可更新的新版本", [
            {
              text: "关闭",
              style: "cancel",
            },
            {
              text: "下载更新",
              onPress: fetchUpdate,
            },
          ]);
        } else {
          Alert("检查更新", "当前已是最新版本");
        }
      })
      .catch((error) => Alert("检查更新", error.message));
  };

  const fetchUpdate = () => {
    Updates.fetchUpdateAsync().then((result) => {
      if (result.isNew) {
        Alert("下载更新", "更新已下载完毕，重启后生效", [
          {
            text: "稍后重启",
            style: "cancel",
          },
          {
            text: "立即重启",
            onPress: () => Updates.reloadAsync(),
          },
        ]);
      } else {
        Alert("下载更新", "无可下载的更新");
      }
    });
  };

  return (
    <View style={{ flex: 1 }}>
      <List.Section>
        <List.Subheader>应用信息</List.Subheader>
        <List.Item
          title="调试信息"
          onPress={() => setShowDebugInfo(true)}
          left={() => <List.Icon icon="bug-outline" />}
        />
        <List.Item
          title="版本信息"
          left={() => <List.Icon icon="information-circle-outline" />}
          onPress={() => setShowVersionInfo(true)}
        />
      </List.Section>
      <Portal>
        <Dialog
          visible={showDebugInfo}
          onDismiss={() => setShowDebugInfo(false)}
        >
          <Dialog.Title>调试信息</Dialog.Title>
          <Dialog.ScrollArea style={styles.scrollArea}>
            <ScrollView>
              <Paragraph>
                {JSON.stringify(
                  {
                    name: Constants.name,
                    deviceName: Constants.deviceName,
                    systemVersion: Constants.systemVersion,
                    nativeAppVersion: Constants.nativeAppVersion,
                    nativeBuildVersion: Constants.nativeBuildVersion,
                    sessionId: Constants.sessionId,
                    expoVersion: Constants.expoVersion,
                    expoRuntimeVersion: Constants.expoRuntimeVersion,
                    statusBarHeight: Constants.statusBarHeight,
                    platform: Constants.platform,
                    colorScheme: Appearance.getColorScheme(),
                    manifest: Constants.manifest,
                  },
                  undefined,
                  2
                )}
              </Paragraph>
            </ScrollView>
          </Dialog.ScrollArea>
        </Dialog>
      </Portal>
      <Portal>
        <Dialog
          visible={showVersionInfo}
          onDismiss={() => setShowVersionInfo(false)}
        >
          <Dialog.Title>版本信息</Dialog.Title>
          <Dialog.Content style={styles.scrollArea}>
            <Paragraph>Release channel: {Updates.releaseChannel}</Paragraph>
            <Paragraph>Version: {manifest && manifest.version}</Paragraph>
            <Paragraph>
              Published Time: {manifest && manifest.publishedTime}
            </Paragraph>
          </Dialog.Content>
          <Dialog.Actions>
            <Button
              onPress={() =>
                Updates.reloadAsync().catch((error) =>
                  Alert("重载", error.message)
                )
              }
            >
              重载
            </Button>
            <Button onPress={checkUpdate}>检查更新</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  scrollArea: {
    paddingBottom: 20,
  },
});

export default Settings;
