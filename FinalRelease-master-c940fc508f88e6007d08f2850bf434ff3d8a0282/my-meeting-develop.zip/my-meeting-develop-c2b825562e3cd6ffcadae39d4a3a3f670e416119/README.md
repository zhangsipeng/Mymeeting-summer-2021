# MyMeeting

## 环境配置

- IDE：Visual Studio Code
- 插件：Prettier(代码自动格式化工具), ESLint(代码规范检查工具)
- 配置文件（`.vscode/settings.json`):

  ```json
  {
    "editor.codeActionsOnSave": { "source.organizeImports": true },
    "editor.formatOnSave": true
  }
  ```

## 运行

- 安装依赖：`yarn`
- 构建 APK 并安装开发客户端
  - Android: `expo run:android`
  - iOS: `expo run:ios`，然后打开 Xcode 构建
- 使用开发客户端开发：`yarn start` 或 `expo start --dev-client`

## 发布

### Android

- 安装 Expo 命令行工具：`yarn global add expo-cli`
- 登录：`expo login -u googleplex -p [password]`
- 发布 JS Bundle：
  - Release: `expo publish`
  - Dev: `expo publish --release-channel dev`
- 编译 APK：`cd android && ./gradlew assembleRelease`
- 签名：`apksigner sign --ks .\mymeeting.keystore --ks-key-alias mymeeting --ks-pass pass:password --out app-release.apk .\app-release-unsigned.apk`
