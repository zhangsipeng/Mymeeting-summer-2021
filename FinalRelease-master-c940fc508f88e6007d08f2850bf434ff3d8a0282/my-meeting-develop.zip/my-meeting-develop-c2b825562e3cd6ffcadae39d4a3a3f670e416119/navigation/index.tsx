/**
 * If you are not familiar with React Navigation, check out the "Fundamentals" guide:
 * https://reactnavigation.org/docs/getting-started
 *
 */
import {
  DarkTheme,
  DefaultTheme,
  NavigationContainer,
} from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import * as React from "react";
import { ColorSchemeName } from "react-native";
import Colors from "../constants/Colors";
import Chat from "../screens/Chat";
import FullScreenVideo from "../screens/FullScreenVideo";
import Meeting from "../screens/Meeting";
import NotFoundScreen from "../screens/NotFoundScreen";
import Participants from "../screens/Participants";
import StartMeeting from "../screens/StartMeeting";
import { onMobile } from "../utils/helpers";
import BottomTabNavigator from "./BottomTabNavigator";
import LinkingConfiguration from "./LinkingConfiguration";

export default function Navigation({
  colorScheme,
}: {
  colorScheme: ColorSchemeName;
}) {
  return (
    <NavigationContainer
      linking={LinkingConfiguration}
      theme={
        colorScheme === "dark"
          ? DarkTheme
          : {
              ...DefaultTheme,
              colors: {
                ...DefaultTheme.colors,
                primary: Colors.primary,
              },
            }
      }
    >
      <RootNavigator />
    </NavigationContainer>
  );
}

// A root stack navigator is often used for displaying modals on top of all other content
// Read more here: https://reactnavigation.org/docs/modal
const Stack = createStackNavigator<RootStackParamList>();

function RootNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {onMobile ? (
        <Stack.Screen name="Root" component={BottomTabNavigator} />
      ) : (
        <Stack.Screen
          name="Root"
          component={StartMeeting}
          options={{ title: "MyMeeting" }}
        />
      )}
      <Stack.Screen
        name="FullScreenVideo"
        component={FullScreenVideo}
        options={{ title: "会议 - MyMeeting" }}
      />
      <Stack.Screen name="Meeting" component={MeetingNavigator} />
      <Stack.Screen
        name="NotFound"
        component={NotFoundScreen}
        options={{ title: "页面未找到 - MyMeeting" }}
      />
    </Stack.Navigator>
  );
}

const MeetingStack = createStackNavigator<MeetingStackParamList>();

function MeetingNavigator() {
  return (
    <MeetingStack.Navigator initialRouteName="Meeting">
      <MeetingStack.Screen
        name="Meeting"
        component={Meeting}
        options={{ headerShown: false, title: "会议 - MyMeeting" }}
      />
      <MeetingStack.Screen
        name="Chat"
        component={Chat}
        options={{ headerTitle: "讨论", title: "讨论 - MyMeeting" }}
      />
      <MeetingStack.Screen
        name="Participants"
        component={Participants}
        options={{ headerTitle: "参会者", title: "参会者 - MyMeeting" }}
      />
    </MeetingStack.Navigator>
  );
}
