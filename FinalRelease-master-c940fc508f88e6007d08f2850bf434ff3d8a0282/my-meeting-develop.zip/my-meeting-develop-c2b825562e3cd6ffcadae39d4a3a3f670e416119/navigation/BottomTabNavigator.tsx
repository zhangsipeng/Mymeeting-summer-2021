/**
 * Learn more about createBottomTabNavigator:
 * https://reactnavigation.org/docs/bottom-tab-navigator
 */

import { Ionicons } from "@expo/vector-icons";
import { createMaterialBottomTabNavigator } from "@react-navigation/material-bottom-tabs";
import { createStackNavigator } from "@react-navigation/stack";
import * as React from "react";
import Schedule from "../screens/Schedule";
import Settings from "../screens/Settings";
import StartMeeting from "../screens/StartMeeting";

const BottomTab = createMaterialBottomTabNavigator<BottomTabParamList>();

export default function BottomTabNavigator() {
  return (
    <BottomTab.Navigator initialRouteName="StartMeeting">
      <BottomTab.Screen
        name="StartMeeting"
        component={StartMeetingNavigator}
        options={{
          tabBarIcon: ({ color }) => (
            <TabBarIcon name="people-outline" color={color} />
          ),
          tabBarLabel: "会议",
        }}
      />
      <BottomTab.Screen
        name="Schedule"
        component={ScheduleNavigator}
        options={{
          tabBarIcon: ({ color }) => (
            <TabBarIcon name="calendar-outline" color={color} />
          ),
          tabBarLabel: "日程",
        }}
      />
      <BottomTab.Screen
        name="Settings"
        component={SettingsNavigator}
        options={{
          tabBarIcon: ({ color }) => (
            <TabBarIcon name="settings-outline" color={color} />
          ),
          tabBarLabel: "设置",
        }}
      />
    </BottomTab.Navigator>
  );
}

// You can explore the built-in icon families and icons on the web at:
// https://icons.expo.fyi/
function TabBarIcon(props: {
  name: React.ComponentProps<typeof Ionicons>["name"];
  color: string;
}) {
  return <Ionicons size={25} {...props} />;
}

// Each tab has its own navigation stack, you can read more about this pattern here:
// https://reactnavigation.org/docs/tab-based-navigation#a-stack-navigator-for-each-tab
const StartMeetingStack = createStackNavigator<StartMeetingStackParamList>();

function StartMeetingNavigator() {
  return (
    <StartMeetingStack.Navigator initialRouteName="StartMeeting">
      <StartMeetingStack.Screen
        name="StartMeeting"
        component={StartMeeting}
        options={{ headerShown: false }}
      />
    </StartMeetingStack.Navigator>
  );
}

const ScheduleStack = createStackNavigator<ScheduleStackParamList>();

function ScheduleNavigator() {
  return (
    <ScheduleStack.Navigator>
      <ScheduleStack.Screen
        name="Schedule"
        component={Schedule}
        options={{ headerTitle: "日程" }}
      />
    </ScheduleStack.Navigator>
  );
}

const SettingsStack = createStackNavigator<SettingsStackParamList>();

function SettingsNavigator() {
  return (
    <SettingsStack.Navigator>
      <SettingsStack.Screen
        name="Settings"
        component={Settings}
        options={{ headerTitle: "设置" }}
      />
    </SettingsStack.Navigator>
  );
}
