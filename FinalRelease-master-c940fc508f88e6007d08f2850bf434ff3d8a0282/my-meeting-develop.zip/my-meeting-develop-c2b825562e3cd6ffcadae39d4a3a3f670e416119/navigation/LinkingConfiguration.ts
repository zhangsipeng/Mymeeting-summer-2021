/**
 * Learn more about deep linking with React Navigation
 * https://reactnavigation.org/docs/deep-linking
 * https://reactnavigation.org/docs/configuring-links
 */

import * as Linking from "expo-linking";

export default {
  prefixes: [
    Linking.makeUrl("/"),
    "mymeeting://",
    "https://mymeeting.cf",
    "https://www.mymeeting.cf",
  ],
  config: {
    screens: {
      Root: {
        screens: {
          StartMeeting: {
            screens: {
              StartMeeting: "/",
            },
          },
        },
      },
      Meeting: {
        screens: {
          Meeting: "meeting/:roomId?",
          Chat: "meeting/chat",
          Participants: "meeting/participants",
        },
      },
      NotFound: "*",
    },
  },
};
