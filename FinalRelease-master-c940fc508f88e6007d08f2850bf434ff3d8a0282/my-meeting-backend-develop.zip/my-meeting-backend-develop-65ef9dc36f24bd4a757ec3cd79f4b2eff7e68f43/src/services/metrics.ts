import { Express } from "express";
import { collectDefaultMetrics, Registry, Gauge } from "prom-client";

export default class MetricsService {
  public registry: Registry;
  public rooms: Gauge<string>;
  public peers: Gauge<string>;

  constructor(app: Express) {
    this.registry = new Registry();
    collectDefaultMetrics({ register: this.registry });
    this.rooms = new Gauge<string>({
      name: "backend_rooms_total",
      help: "Total number of rooms"
    });
    this.peers = new Gauge<string>({
      name: "backend_peers_total",
      help: "Total number of peers"
    });
    this.registry.registerMetric(this.rooms);
    this.registry.registerMetric(this.peers);

    app.get("/metrics", async (req, res) => {
      try {
	res.set("Content-Type", this.registry.contentType);
	res.end(await this.registry.metrics());
      } catch (error) {
        res.status(500).end(error);
      }
    });
  }
};
