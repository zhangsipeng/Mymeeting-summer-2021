import core from "express";
import * as https from "https";
import { getLogger } from "log4js";
import * as mediasoup from "mediasoup";
import { types as mediasoupTypes } from "mediasoup";
import schedule from "node-schedule";
import os from "os";
import * as socketIo from "socket.io";
import { Server } from "socket.io";
import serverConfig from "../../config/serverConfig";
import Room from "../lib/Room";

const logger = getLogger("Server");

export default class MediasoupService {
  private rooms = new Map<string, Room>();
  private allocatedRoomId = new Array<number>();
  private nextWorkerId = 0;

  constructor(
    private io: socketIo.Server,
    private workers: Array<mediasoupTypes.Worker>,
    app: core.Express
  ) {
    this.setupSocketIo();
    this.setupApp(app);
    setInterval(() => {
      let all = 0;
      let closed = 0;

      this.rooms.forEach((room) => {
        all++;
        if (room.closed) {
          closed++;
        }
        if (!room.getScheduled()) {
          room.checkDeserted();
        }
      });

      logger.info("room total: %s, closed: %s", all, closed);
    }, serverConfig.roomStatusInterval * 1000);
  }

  public static async create(httpsSever: https.Server, app: core.Express) {
    const workers = await this.createWorkers();
    const io = new Server(httpsSever, {
      path: "/server",
      pingTimeout: 3000,
      pingInterval: 5000,
      transports: ["websocket"],
      allowUpgrades: false,
    });
    return new MediasoupService(io, workers, app);
  }

  private static async createWorkers() {
    const numWorkers = os.cpus().length;
    logger.info(
      "mediasoup version: %s, running %d mediasoup Workers...",
      mediasoup.version,
      numWorkers
    );
    const workers = new Array<mediasoupTypes.Worker>();
    for (let i = 0; i < numWorkers; ++i) {
      // eslint-disable-next-line no-await-in-loop
      const worker = (await mediasoup
        .createWorker({
          rtcMinPort: serverConfig.worker.rtcMinPort,
          rtcMaxPort: serverConfig.worker.rtcMaxPort,
          dtlsCertificateFile: serverConfig.tls.cert,
          dtlsPrivateKeyFile: serverConfig.tls.key,
        })
        .catch((info) => {
          logger.info(info);
        })) as mediasoupTypes.Worker;
      worker.on("died", () => {
        logger.error(
          "Mediasoup Worker died, exiting  in 2 seconds... [pid:%d]",
          worker.pid
        );

        setTimeout(() => process.exit(1), 2000);
      });
      workers.push(worker);
    }
    return workers;
  }

  private static isValidDate(date: Date) {
    return !isNaN(date.getTime());
  }

  public cleanUp() {
    this.rooms.forEach((room) => room.close());
    this.workers.forEach((worker) => worker.close());
    this.io.close();
  }

  private getAvailableWorker() {
    const worker = this.workers[this.nextWorkerId];
    if (++this.nextWorkerId === this.workers.length) {
      this.nextWorkerId = 0;
    }
    return worker;
  }

  private getAvailableRoomId() {
    let roomId: number;
    let tries = 0;
    do {
      tries++;
      roomId = Math.floor(Math.random() * 100); //不含最大值，含最小值
    } while (tries < 100 && this.allocatedRoomId.includes(roomId));
    return roomId.toString();
  }

  private async setupApp(app: core.Express) {
    app.get("/scheduleAMeeting", (req, res) => {
      try {
        if (
          typeof req.query.startTime !== "string" ||
          typeof req.query.stopTime !== "string" ||
          (typeof req.query.password !== "string" &&
            typeof req.query.password !== "undefined")
        ) {
          throw "incorrect format.";
        }
        const startTime = new Date(req.query.startTime);
        const stopTime = new Date(req.query.stopTime);
        const password = req.query.password;

        if (
          !MediasoupService.isValidDate(startTime) ||
          !MediasoupService.isValidDate(stopTime)
        ) {
          throw "invalid date.";
        }
        if (stopTime.getTime() <= startTime.getTime()) {
          throw "stopTime can not be less than or equal to startTime.";
        }
        if (startTime.getTime() <= new Date().getTime()) {
          throw "the startTime can not be less than current time";
        }

        const roomId = this.getAvailableRoomId();
        this.allocatedRoomId.push(parseInt(roomId));
        schedule.scheduleJob(startTime, async () => {
          this.getOrCreateRoom(roomId, password, true);
        });
        schedule.scheduleJob(stopTime, async () => {
          const room = this.rooms.get(roomId);
          room?.broadcast("meetingStopped");
          room?.close();
        });
        logger.info(
          '[roomId: "%s", startTime: "%s", stopTime:"%s", password: "%s"] scheduled successfully',
          roomId,
          startTime.toString(),
          stopTime.toString(),
          password
        );
        res.status(200).json({ roomId: roomId });
      } catch (error) {
        logger.info(error);
        res.status(400).json({ error: error });
      }
    });
  }

  private setupSocketIo() {
    this.registerValidateMiddleware();

    logger.info("run websocket server....");

    this.io.on("connection", async (socket) => {
      const { peerId, displayName, createRoom, password } =
        socket.handshake.query;

      logger.debug(
        `New Socket Connection: [peerId: ${peerId}, displayName: ${displayName}, createRoom: ${createRoom}, password: ${password}]`
      );
      let { roomId } = socket.handshake.query;

      try {
        if (createRoom) {
          roomId = this.getAvailableRoomId();
        }

        // @ts-ignore
        const room = await this.getOrCreateRoom(roomId, password);

        // use peerId to check if this is a reconnection
        if (!peerId) {
          // @ts-ignore
          room.handlePeer(socket, displayName);
        } else {
          // @ts-ignore
          room.handlePeerReconnect(peerId, socket);
        }
      } catch (error) {
        logger.error(
          'room creation or room joining failed [error:"%o"]',
          error
        );
        socket.disconnect(true);
      }
    });
  }

  private registerValidateMiddleware = () => {
    // missing peerId?
    this.io.use((socket, next) => {
      if (
        !socket.handshake.query.displayName ||
        // @ts-ignore
        socket.handshake.query.displayName.length === 0
      ) {
        logger.info("Join Room Failed, missing displayName!");
        next(new Error("没有用户名"));
      } else next();
    });
    // missing roomId?
    this.io.use((socket, next) => {
      const { createRoom, roomId } = socket.handshake.query;
      if (!createRoom && (!roomId || roomId.length === 0)) {
        logger.info("Join Room Failed, missing roomId!");
        next(new Error("请输入房间号"));
      } else next();
    });
    // room exist and password correct?
    this.io.use((socket, next) => {
      const { createRoom, password } = socket.handshake.query;
      let { roomId } = socket.handshake.query;
      if (!createRoom) {
        // @ts-ignore
        roomId = parseInt(roomId).toString(); //去掉前面可能多余的0
        // @ts-ignore
        const room = this.rooms.get(roomId);
        if (!room) {
          logger.info("Join Room Failed, room does not exist!");
          next(new Error("房间不存在"));
        }
        // @ts-ignore
        else if (!room.verifyPassword(password)) {
          logger.info("Join Room Failed, password incorrect!");
          next(new Error("密码错误"));
        } else next();
      } else next();
    });
  };

  private async getOrCreateRoom(
    roomId: string,
    password: string | undefined,
    scheduled = false
  ) {
    let room = this.rooms.get(roomId);
    if (!room) {
      const worker = this.getAvailableWorker();
      room = await Room.create(worker, roomId, password, scheduled);
      this.rooms.set(roomId, room);
      if (!this.allocatedRoomId.includes(parseInt(roomId)))
        this.allocatedRoomId.push(parseInt(roomId));
      room.on("close", () => {
        this.rooms.delete(roomId);
        this.allocatedRoomId.splice(
          this.allocatedRoomId.indexOf(parseInt(roomId)),
          1
        );
      });
    }
    return room;
  }
}
