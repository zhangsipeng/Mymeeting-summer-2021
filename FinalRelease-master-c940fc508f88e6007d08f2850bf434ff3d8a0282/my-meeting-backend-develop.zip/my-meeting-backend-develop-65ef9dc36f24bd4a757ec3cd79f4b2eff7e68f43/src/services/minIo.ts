import { Express } from "express";
import { getLogger } from "log4js";
import * as MinIO from "minio";
import serverConfig from "../../config/serverConfig";

const logger = getLogger("minIo");

const setupMinIo = (app: Express) => {
  const client = new MinIO.Client({
    endPoint: serverConfig.minIo.endPoint,
    port: serverConfig.minIo.port,
    useSSL: true,
    accessKey: serverConfig.minIo.accessKey,
    secretKey: serverConfig.minIo.secretKey,
  });

  app.get("/uploadUrl", (req, res) => {
    const time = Date.now();
    const fileName = time + "-" + req.query.name;
    logger.info("File upload request: " + fileName);
    client.presignedPutObject("sharing", fileName, (err, url) => {
      if (err) {
        logger.error("Upload file failed: " + url);
        throw err;
      }
      res.json({ url, time });
    });
  });

  app.get("/downloadUrl", (req, res) => {
    const fileName =
      (req.query.time as string) + "-" + (req.query.name as string);
    logger.info("File download request: " + fileName);
    client.presignedGetObject("sharing", fileName, (err, url) => {
      if (err) {
        logger.error("Download file failed: " + url);
        throw err;
      }
      res.json({ url });
    });
  });

  return client;
};

export default setupMinIo;
