import { getLogger } from "log4js";
import moment from "moment";
import redis from "redis";
import serverConfig from "../../config/serverConfig";

const logger = getLogger("redis");

class RedisClient {
  private client;
  constructor() {
    this.client = redis.createClient(
      serverConfig.redis.port,
      serverConfig.redis.ip
    );

    this.client.auth(serverConfig.redis.password);

    this.client.on("error", (error) => {
      logger.error(error);
    });

    this.client.on("ready", () => {
      logger.info("redis client is ready.");
      this.client.keys(`room*`, (err, keys) => {
        keys.forEach((key) => {
          this.client.del(key);
        });
      });
    });
  }

  public recordRoomDuration(
    roomId: string,
    startTime: moment.Moment,
    stopTime: moment.Moment
  ) {
    const startKey = `room:${roomId}:startTime`;
    const endKey = `room:${roomId}:stopTime`;
    this.client.set(startKey, startTime.format());
    this.client.set(endKey, stopTime.format());

    logger.info(`Record Room ${roomId}`);
  }

  public updateRoomLoad(roomId: string, peerNum: number, producerNum: number) {
    const peersKey = `room:${roomId}:peerNum`;
    const producersKey = `room:${roomId}:producerNum`;
    this.client.set(peersKey, peerNum.toString());
    this.client.set(producersKey, producerNum.toString());
  }

  public removeRoomInfo(roomId: string) {
    this.client.keys(`room:${roomId}:*`, (err, keys) => {
      keys.forEach((key) => {
        this.client.del(key);
      });
    });
  }

  public recordRoomUrl(roomId: string) {
    const key = `room:${roomId}:serverUrl`;
    this.client.set(key, serverConfig.serverUrl);
  }
}

export default new RedisClient();
