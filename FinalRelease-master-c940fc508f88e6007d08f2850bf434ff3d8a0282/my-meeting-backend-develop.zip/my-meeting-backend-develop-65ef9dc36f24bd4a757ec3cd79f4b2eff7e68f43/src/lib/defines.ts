import moment from "moment";

export enum Role {
  Host = "Host",
  Participant = "Participant",
  CoHost = "CoHost",
}

export enum RoomStatus {
  started = "started",
  paused = "paused",
  stopped = "stopped",
}

export enum MediaType {
  webcam = "webcam",
  screen = "screen",
  audio = "audio",
}

export class RoomInfo {
  status: RoomStatus = RoomStatus.stopped;

  startTime: moment.Moment;

  stopTime: moment.Moment | undefined;

  constructor() {
    this.startTime = moment();
  }
}

export enum RequestMethod {
  getRouterRtpCapabilities = "getRouterRtpCapabilities",
  getRights = "getRights",
  changeDisplayName="changeDisplayName",
  join = "join",
  mutePeer = "mutePeer",
  muteAll = "muteAll",
  unmuteAll = "unmuteAll",
  createWebRtcTransport = "createWebRtcTransport",
  connectWebRtcTransport = "connectWebRtcTransport",
  restartIce = "restartIce",
  produce = "produce",
  pauseProducer = "pauseProducer",
  resumeProducer = "resumeProducer",
  closeProducer = "closeProducer",
  getProducerStats = "getProducerStats",
  getConsumerStats = "getConsumerStats",
  getTransportStats = "getTransportStats",
  changeRole = "changeRole",
  chatMessage = "chatMessage",
  closePeer = "closePeer",
  stopMeeting = "stopMeeting",
  kickOutPeer = "kickOutPeer",
  unmuted = "unmuted",
  rejoin = "rejoin",
  getRoomRights = "getRoomRights",
  exitMeeting = "exitMeeting",
  serverReady = "serverReady",
}
