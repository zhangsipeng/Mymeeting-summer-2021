import { EventEmitter } from "events";
import { getLogger } from "log4js";
import { types as mediasoupTypes } from "mediasoup";
import * as socketIo from "socket.io";
import { Role } from "./defines";

const logger = getLogger("Peer");

export default class Peer extends EventEmitter {
  role: Role;

  producers = new Map<string, mediasoupTypes.Producer>();

  transports = new Map<string, mediasoupTypes.WebRtcTransport>();

  consumers = new Map<string, mediasoupTypes.Consumer>();

  closed = false;

  joined = false;

  displayName: string | undefined;

  platform: string | undefined;

  address: string;

  enterTime = Date.now();

  disconnectCheck = 0;

  intervalHandler: NodeJS.Timeout | null;

  rtpCapabilities: mediasoupTypes.RtpCapabilities | undefined;

  audioRights: boolean;

  webcamRights: boolean;

  constructor(
    public id: string,
    public roomId: string,
    public socket: socketIo.Socket,
    displayName: string
  ) {
    super();

    this.socket.join(roomId);
    this.role = Role.Participant;
    this.address = socket.handshake.address;
    this.intervalHandler = null;
    this.audioRights = true;
    this.webcamRights = true;
    this.displayName = displayName;
    this.setMaxListeners(Infinity);
    this.handlePeer();
  }

  public request(method: string, data = {}) {
    return new Promise((resolve) => {
      this.socket.emit("request", { method, data }, null);
      resolve("resolved");
    });
  }

  public notification(method: string, data = {}) {
    this.socket.emit("notification", { method, data });
  }

  public broadcast(method: string, data = {}) {
    this.socket.broadcast
      .to(this.roomId)
      .emit("notification", { method, data });
  }

  public close() {
    logger.info("Peer %s call close()", this.id);

    this.closed = true;
    this.closeResource();

    setTimeout(() => this.socket.disconnect(true), 5000);

    if (this.intervalHandler) {
      clearInterval(this.intervalHandler);
    }
    this.emit("close");
  }

  public removeDuplicate() {
    logger.info("Peer %s call removeDuplicate()", this.id);

    this.closed = true;
    this.closeResource();

    if (this.socket) {
      this.socket.disconnect(true);
    }

    if (this.intervalHandler) {
      clearInterval(this.intervalHandler);
    }
  }

  public setNewSocket(socket: socketIo.Socket) {
    this.socket = socket;
    this.handlePeer();
  }

  public checkClose() {
    if (!this.socket.connected) {
      this.disconnectCheck++;
    } else {
      if (this.intervalHandler) {
        clearInterval(this.intervalHandler);
      }
      this.intervalHandler = null;
    }

    if (this.disconnectCheck > 6) {
      this.close();
    }
  }

  public addTransport(id: string, transport: mediasoupTypes.WebRtcTransport) {
    this.transports.set(id, transport);
  }

  public getTransport(id: string) {
    return this.transports.get(id);
  }

  public getConsumerTransport() {
    return Array.from(this.transports.values()).find(
      (t: any) => t.appData.consuming
    );
  }

  public removeTransport(id: string) {
    this.transports.delete(id);
  }

  public addProducer(id: string, producer: mediasoupTypes.Producer) {
    this.producers.set(id, producer);
  }

  public getProducer(id: string) {
    return this.producers.get(id);
  }

  public removeProducer(id: string) {
    this.producers.delete(id);
  }

  public addConsumer(id: string, consumer: mediasoupTypes.Consumer) {
    this.consumers.set(id, consumer);
  }

  public getConsumer(id: string) {
    return this.consumers.get(id);
  }

  public removeConsumer(id: string) {
    const consumer = this.consumers.get(id);
    if (consumer) {
      consumer.close();
      clearInterval(consumer.appData.intervalHandler);
    }
    this.consumers.delete(id);
  }

  public peerInfo() {
    const peerInfo = {
      id: this.id,
      role: this.role,
      displayName: this.displayName,
      platform: this.platform,
      address: this.address,
      durationTime: (Date.now() - this.enterTime) / 1000,
    };

    return peerInfo;
  }

  private closeResource() {
    this.producers.forEach((producer) => {
      producer.close();
    });

    this.consumers.forEach((consumer) => {
      clearInterval(consumer.appData.intervalHandler);
      consumer.close();
    });

    this.transports.forEach((transport) => {
      transport.close();
    });

    this.transports.clear();
    this.producers.clear();
    this.consumers.clear();
  }

  private handlePeer() {
    this.socket.on("disconnect", (reason) => {
      if (this.closed) {
        return;
      }
      logger.debug(
        '"socket disconnect" event [id:%s], reason: %s',
        this.id,
        reason
      );

      // clear all its consumers
      this.consumers.forEach((consumer) => consumer.close());
      this.consumers = new Map();

      // disconnect manually
      if (
        reason === "client namespace disconnect" ||
        reason === "server namespace disconnect"
      ) {
        this.close();
        return;
      }

      // network error
      this.disconnectCheck = 0;
      if (this.intervalHandler) {
        clearInterval(this.intervalHandler);
      }

      this.intervalHandler = setInterval(() => {
        this.checkClose();
      }, 20000);
    });

    this.socket.on("error", (error) => {
      logger.info("socket error, peer: %s, error: %s", this.id, error);
    });
  }
}
