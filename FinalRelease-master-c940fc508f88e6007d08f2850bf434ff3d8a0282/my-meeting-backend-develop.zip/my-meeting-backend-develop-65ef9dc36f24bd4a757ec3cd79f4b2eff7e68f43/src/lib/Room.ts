import { EventEmitter } from "events";
import { getLogger } from "log4js";
import {
  getSupportedRtpCapabilities,
  types as mediasoupTypes,
} from "mediasoup";
import moment from "moment";
import * as socketIo from "socket.io";
import { v4 as generateUUID } from "uuid";
import { serverConfig } from "../../config/serverConfig";
import redisClient from "../services/redis";
import {
  MediaType,
  RequestMethod,
  Role,
  RoomInfo,
  RoomStatus,
} from "./defines";
import Peer from "./Peer";

type ClientRequestType = {
  method: string;
  data: any;
};

const logger = getLogger("Room");

const mediaCodecs = new Array<mediasoupTypes.RtpCodecCapability>();
getSupportedRtpCapabilities().codecs?.forEach((codec) => {
  switch (codec.mimeType) {
    case "video/H264":
    case "video/VP8":
    case "video/VP9":
    case "audio/opus":
      mediaCodecs.push(codec);
  }
});

export default class Room extends EventEmitter {
  public peers = new Map<string, Peer>();
  public closed = false;
  public audioMuted = false;
  public webcamMuted = false;
  public screenMuted = false;
  public screenSharing = false;

  private roomInfo = new RoomInfo();

  constructor(
    public id: string,
    private mediasoupRouter: mediasoupTypes.Router,
    private password: string,
    private scheduled: boolean
  ) {
    super();

    logger.info('Constructing Room [roomId:"%s"]', id);
    this.setMaxListeners(Infinity);
    redisClient.recordRoomUrl(this.id);
  }

  static async create(
    mediasoupWorker: mediasoupTypes.Worker,
    roomId: string,
    password: string | undefined,
    scheduled: boolean
  ) {
    const mediasoupRouter = await mediasoupWorker.createRouter({ mediaCodecs });
    (global as any).metrics.rooms.inc();
    if (!password) {
      return new Room(roomId, mediasoupRouter, "", scheduled);
    }
    return new Room(roomId, mediasoupRouter, password, scheduled);
  }

  public close() {
    if (this.roomInfo.status === RoomStatus.stopped) {
      return;
    }
    logger.info("Closing Room: %s", this.id);
    this.closed = true;
    this.roomInfo.status = RoomStatus.stopped;
    this.roomInfo.stopTime = moment();
    redisClient.recordRoomDuration(
      this.id,
      this.roomInfo.startTime,
      this.roomInfo.stopTime
    );
    this.peers.forEach((peer) => {
      if (!peer.closed) {
        peer.close();
	(global as any).metrics.peers.dec();
      }
    });
    this.peers.clear();
    this.mediasoupRouter.close();
    redisClient.removeRoomInfo(this.id);
    (global as any).metrics.rooms.dec();
    this.emit("close");
  }

  // add a peer
  public addPeer(socket: socketIo.Socket, displayName: string) {
    const peerId = generateUUID();
    const peer = new Peer(peerId, this.id, socket, displayName);

    peer.audioRights = !this.audioMuted;
    peer.webcamRights = !this.webcamMuted;
    this.setupSocketHandler(peer);
    this.peers.set(peer.id, peer);
    this.updateRedisRoomInfo();
    (global as any).metrics.peers.inc();

    peer.on("close", () => {
      logger.info("%s closed, room:  %s", peer.id, this.id);
      if (this.closed) {
        return;
      }

      peer.broadcast("peerClosed", { id: peer.id });
      this.peers.delete(peer.id);
      this.updateRedisRoomInfo();
      (global as any).metrics.peers.dec();

      if (!this.scheduled && this.checkEmpty()) {
        this.close();
      }
    });
    return peer;
  }

  public setupSocketHandler(peer: Peer) {
    peer.socket.on("request", (request, cb) => {
      logger.debug(
        'Peer "request" event [room:"%s", method:"%s", peerId:"%s"]',
        this.id,
        request.method,
        peer.id
      );

      this.handleSocketRequest(peer, request, cb).catch((error) => {
        logger.error('"request" failed [error:"%o"]', error);
        cb(error);
      });
    });
  }

  public handlePeer(socket: socketIo.Socket, displayName: string) {
    this.roomInfo.status = RoomStatus.started;

    const peer = this.addPeer(socket, displayName);
    // tell the client that server is ready for start transport
    peer.notification(RequestMethod.serverReady);

    logger.info(
      'New Peer [id:"%s", socket:"%s", address: "%s"]',
      peer.id,
      socket.id,
      socket.handshake.address
    );
  }

  public verifyPassword(password: string) {
    if (this.password === "") {
      return true;
    }
    return this.password === password;
  }

  public handlePeerReconnect(peerId: string, socket: socketIo.Socket) {
    const peer = this.getPeer(peerId);
    peer?.socket.leave(this.id);
    peer?.socket.disconnect(true);
    if (!peer) return;
    peer.setNewSocket(socket);
    peer.socket.join(this.id);
    this.setupSocketHandler(peer);
    if (peer.intervalHandler) clearInterval(peer.intervalHandler);
    logger.info("peer %s reconnected!", this.id);
  }

  public broadcast(method: string, data = {}) {
    this.peers.forEach((peer) => {
      if (!peer.closed) {
        peer.notification(method, data);
      }
    });
  }

  public getScheduled() {
    return this.scheduled;
  }

  public checkDeserted() {
    // close empty rooms
    if (this.checkEmpty()) {
      logger.info("room %s is empty , now close it!", this.id);
      this.close();
    }
  }

  private getPeer(peerId: string) {
    return this.peers.get(peerId);
  }

  private checkEmpty() {
    return this.peers.size === 0;
  }

  private updateRedisRoomInfo() {
    let producerNum = 0;
    this.peers.forEach((peer) => {
      producerNum += peer.producers.size;
    });
    redisClient.updateRoomLoad(this.id, this.peers.size, producerNum);
  }

  private getRights(peerId: string, type: MediaType) {
    const peer = this.getPeer(peerId);
    if (!peer) return false;
    if ((this.screenMuted || this.screenSharing) && type === MediaType.screen)
      return false;
    if (peer.role !== Role.Participant) return true;
    if (this.audioMuted && type === MediaType.audio) return false;
    if (this.webcamMuted && type === MediaType.webcam) return false;
    switch (type) {
      case MediaType.audio: {
        return peer.audioRights;
      }
      case MediaType.webcam: {
        return peer.webcamRights;
      }
      case MediaType.screen: {
        return true;
      }
      default:
        return false;
    }
  }

  private async handleSocketRequest(
    peer: Peer,
    request: ClientRequestType,
    cb: any
  ) {
    switch (request.method) {
      case RequestMethod.getRouterRtpCapabilities: {
        cb(this.mediasoupRouter.rtpCapabilities);

        break;
      }

      case RequestMethod.join: {
        const { displayName, platform, rtpCapabilities } = request.data;

        peer.displayName = displayName;
        peer.platform = platform;
        peer.rtpCapabilities = rtpCapabilities;

        const peerInfos = new Array<any>();

        // create a consumer for every other peer that has already joined the room
        this.peers.forEach((joinedPeer) => {
          if (joinedPeer.id !== peer.id) {
            peerInfos.push(joinedPeer.peerInfo());
            joinedPeer.producers.forEach((producer) => {
              this.createConsumer(peer, joinedPeer, producer);
            });
          }
        });

        const role: Role = this.peers.size === 1 ? Role.Host : Role.Participant;
        peer.role = this.peers.size === 1 ? Role.Host : Role.Participant;
        // notify the new peer about other peers' info and its role
        cb({ peers: peerInfos, role, peerId: peer.id, roomId: this.id });

        // notify other peers about the newly joined peer
        this.notification(peer.socket, "newPeer", { ...peer.peerInfo() }, true);
        peer.joined = true;

        logger.debug(
          'New peer joined [peer: "%s", displayName: "%s", role:"%s", platform: "%s"]',
          peer.id,
          displayName,
          role,
          platform
        );
        break;
      }

      case RequestMethod.changeDisplayName: {
        const { newName } = request.data;
        peer.displayName = newName;
        peer.broadcast("peerDisplayNameChanged", { peerId: peer.id, newName });
        cb({ state: "success", newName: newName });
        break;
      }

      case RequestMethod.mutePeer: {
        if (peer.role === Role.Participant) {
          cb({
            status: "fail",
            message: "No rights to mute others",
          });
          return;
        }
        const { toPeerId, mediaType } = request.data;
        const toPeer = this.getPeer(toPeerId);
        if (!toPeer) {
          cb({
            status: "fail",
            message: "No such peer to mute",
          });
          break;
        }
        if (toPeer.role === Role.Host) {
          cb({
            status: "fail",
            message: "No rights to mute The Host",
          });
          break;
        }
        if (mediaType === MediaType.audio) toPeer.audioRights = false;
        else if (mediaType === MediaType.webcam) toPeer.webcamRights = false;
        toPeer.producers.forEach((producer) => {
          if (producer.appData.mediaType === mediaType && !producer.paused) {
            producer.pause();
          }
        });
        toPeer?.notification("toPauseProducer", { mediaType });
        cb({ status: "succeed" });
        break;
      }

      case RequestMethod.getRoomRights: {
        cb({
          audioMuted: this.audioMuted,
          webcamMuted: this.webcamMuted,
          screenMuted: this.screenMuted,
        });
        break;
      }

      case RequestMethod.changeRole: {
        if (peer.role !== Role.Host) {
          cb({
            status: "fail",
            message: "No rights to change other's role",
          });
          return;
        }

        const { role, toPeerId } = request.data;

        const toPeer = this.getPeer(toPeerId);
        if (!toPeer) {
          logger.error("Peer not found: %s", toPeerId);
          break;
        }

        toPeer.role = role;
        toPeer.notification("changeRole", { role });
        toPeer.broadcast("peerRoleChanged", { peerId: toPeer.id, role });

        cb({ status: "succeed" });
        break;
      }

      case RequestMethod.muteAll: {
        if (peer.role === Role.Participant) {
          cb({
            status: "fail",
            message: "No rights to mute all",
          });
          return;
        }
        try {
          const { mediaType } = request.data;
          if (mediaType === MediaType.audio) this.audioMuted = true;
          else if (mediaType === MediaType.webcam) this.webcamMuted = true;
          else if (mediaType === MediaType.screen) this.screenMuted = true;
          this.peers.forEach((toPeer) => {
            if (toPeer.id === peer.id) return;
            if (mediaType === "audio") toPeer.audioRights = false;
            else toPeer.webcamRights = false;
            toPeer.producers.forEach((producer) => {
              if (
                producer.appData.mediaType === mediaType &&
                !producer.paused
              ) {
                producer.pause();
              }
            });
            toPeer.notification("toPauseProducer", { mediaType });
          });
        } catch (err) {
          cb({ status: "fail" });
          break;
        }
        cb({ status: "succeed" });
        break;
      }

      case RequestMethod.unmuteAll: {
        const { mediaType } = request.data;
        if (peer.role === Role.Participant) {
          cb({
            status: "fail",
            message: "No rights to unmute all",
          });
          return;
        }
        if (mediaType === MediaType.audio) this.audioMuted = false;
        else if (mediaType === MediaType.webcam) this.webcamMuted = false;
        else if (mediaType === MediaType.screen) this.screenMuted = false;
        if (request.data.mediaType === MediaType.audio) {
          this.peers.forEach((peer) => {
            peer.audioRights = true;
          });
        } else {
          this.peers.forEach((peer) => {
            peer.webcamRights = true;
          });
        }
        cb({ status: "succeed" });
        break;
      }

      case RequestMethod.rejoin: {
        const peerInfos = new Array<any>();
        this.peers.forEach((joinedPeer) => {
          if (joinedPeer.id !== peer.id) {
            peerInfos.push(joinedPeer.peerInfo());
            joinedPeer.producers.forEach((producer) => {
              this.createConsumer(peer, joinedPeer, producer);
            });
          }
        });

        cb({ peers: peerInfos });

        logger.debug('Peer rejoined [peer: "%s"]', peer.id);
        break;
      }

      case RequestMethod.createWebRtcTransport: {
        const { forceTcp, producing, consuming, rtpCapabilities } =
          request.data;
        const transport = await this.mediasoupRouter.createWebRtcTransport({
          listenIps: serverConfig.webRtcTransport.listenIps,
          enableUdp: !forceTcp,
          enableTcp: true,
          preferUdp: true,
          appData: { producing, consuming },
        });

        peer.addTransport(transport.id, transport);
        peer.rtpCapabilities = rtpCapabilities;

        cb({
          id: transport.id,
          iceParameters: transport.iceParameters,
          iceCandidates: transport.iceCandidates,
          dtlsParameters: transport.dtlsParameters,
        });
        break;
      }

      case RequestMethod.connectWebRtcTransport: {
        const { transportId, dtlsParameters } = request.data;
        const transport = peer.getTransport(transportId);

        if (!transport) {
          throw new Error(`transport with id "${transportId}" not found`);
        }
        await transport.connect({ dtlsParameters });
        cb();

        break;
      }

      case RequestMethod.restartIce: {
        const { transportId } = request.data;
        const transport = peer.getTransport(transportId);

        if (!transport) {
          throw new Error(`Transport with id "${transportId}" not found`);
        }

        const iceParameters = await transport.restartIce();

        cb({ iceParameters });

        break;
      }

      case RequestMethod.getRights: {
        const { mediaType } = request.data;
        if (!this.getRights(peer.id, mediaType)) {
          cb({ status: "fail", message: "privilege required" });
        } else {
          cb({ status: "succeed" });
        }
        logger.info(
          "Peer[%s] checks rights, mediaType: %s",
          peer.displayName,
          mediaType
        );
        break;
      }

      case RequestMethod.produce: {
        const { transportId, kind, rtpParameters } = request.data;
        let { appData } = request.data;

        const transport = peer.getTransport(transportId);

        if (!transport) {
          logger.error(`transport with id "${transportId}" not found`);
          cb();
          break;
        }

        appData = { ...appData, peerId: peer.id };

        const producer = await transport.produce({
          kind,
          rtpParameters,
          appData,
        });
        peer.addProducer(producer.id, producer);
        this.updateRedisRoomInfo();

        producer.on("videoOrientationChange", (videoOrientation) => {
          logger.debug(
            'Producer "videoOrientationChange" event [producerId:"%s", videoOrientation:"%o"]',
            producer.id,
            videoOrientation
          );
        });

        const mediaType: string = appData.mediaType;
        if (mediaType === MediaType.screen) {
          this.screenSharing = true;
          logger.debug("screenSharing");
        }

        logger.info(
          "Produce, peer: %s, producerId: %s, kind: %s, mediaType: %s",
          peer.id,
          producer.id,
          kind,
          appData.mediaType
        );
        cb({ id: producer.id });

        this.peers.forEach((otherPeer) => {
          if (otherPeer.id === peer.id) {
            return;
          }
          this.createConsumer(otherPeer, peer, producer);
        });
        break;
      }

      case RequestMethod.pauseProducer: {
        const producerId = request.data.id;
        if (producerId === "newId") {
          cb({ state: "success" });
          break;
        }
        const producer = peer.getProducer(producerId);
        producer?.pause();
        const mediaType: string = producer?.appData.mediaType;
        if (mediaType === MediaType.screen) {
          this.screenSharing = false;
        }

        cb({ state: "success" });
        break;
      }

      case RequestMethod.resumeProducer: {
        const producerId = request.data.id;
        if (producerId === "newId") {
          cb({ state: "success" });
          break;
        }
        const producer = peer.getProducer(producerId);
        producer?.resume();
        const mediaType: string = producer?.appData.mediaType;
        if (mediaType === MediaType.screen) {
          this.screenSharing = true;
        }

        cb({ state: "success" });
        break;
      }

      case RequestMethod.closeProducer: {
        const { producerId } = request.data;
        const producer = peer.getProducer(producerId);

        if (!producer) {
          logger.error(`producer with id "${producerId}" not found`);
          cb({ status: "success" });
          break;
        }

        logger.info(
          "closeProducer, peer: %s, producerId: %s",
          peer.id,
          producer.id
        );

        producer.close();
        peer.removeProducer(producer.id);
        this.updateRedisRoomInfo();
        cb({ status: "success" });
        break;
      }

      case RequestMethod.chatMessage: {
        const { to } = request.data;
        if (to === "all") {
          this.notification(
            peer.socket,
            RequestMethod.chatMessage,
            request.data,
            true
          );
        } else {
          const toPeer = this.getPeer(to);
          if (toPeer) {
            this.notification(
              toPeer.socket,
              RequestMethod.chatMessage,
              request.data,
              false
            );
          }
        }
        cb();

        break;
      }

      case RequestMethod.stopMeeting: {
        if (peer.role !== Role.Host) {
          cb({ status: "fail", message: "privilege required" });
          return;
        }
        this.roomInfo.status = RoomStatus.stopped;
        peer.broadcast("meetingStopped");
        cb({ status: "succeed" });
        this.close();

        logger.info("Peer: %s stop meeting", peer.displayName);
        break;
      }

      case RequestMethod.exitMeeting: {
        peer.close();
        cb();

        // stop the meeting automatically after host leaves
        if (peer.role === Role.Host) {
          peer.broadcast("meetingStopped");
          this.close();
        }

        logger.info("Peer: %s exit meeting", peer.displayName);
        break;
      }

      case RequestMethod.kickOutPeer: {
        if (peer.role === Role.Participant) {
          cb({ status: "fail", message: "privilege required" });
          return;
        }
        const { toPeerId } = request.data;
        const toPeer = this.getPeer(toPeerId);
        if (toPeer?.role === Role.Host) {
          cb({ status: "fail", message: "can't kick the host" });
          return;
        }
        toPeer?.notification("kickedOut");
        toPeer?.close();
        cb({ status: "succeed" });
        break;
      }

      default: {
        logger.error('unknown request.method "%s"', request.method);
        cb(500, `unknown request.method "${request.method}"`);
      }
    }
  }

  private async createConsumer(
    consumerPeer: Peer,
    producerPeer: Peer,
    producer: mediasoupTypes.Producer
  ) {
    logger.debug(
      '_createConsumer() [consumerPeer:"%s", producerPeer:"%s", producer:"%s"]',
      consumerPeer.id,
      producerPeer.id,
      producer.id
    );

    if (
      !consumerPeer.rtpCapabilities ||
      !this.mediasoupRouter.canConsume({
        producerId: producer.id,
        rtpCapabilities: consumerPeer.rtpCapabilities,
      })
    ) {
      logger.debug("exit anyway error!");
      return;
    }

    // Must take the Transport the remote Peer is using for consuming.
    const transport = consumerPeer.getConsumerTransport();

    if (!transport) {
      logger.warn("_createConsumer() | Transport for consuming not found");
      return;
    }

    let consumer: mediasoupTypes.Consumer;
    try {
      consumer = await transport.consume({
        producerId: producer.id,
        rtpCapabilities: consumerPeer.rtpCapabilities,
        paused: producer.kind === "video",
      });
    } catch (error) {
      logger.warn('_createConsumer() | [error:"%o"]', error);
      return;
    }

    consumerPeer.addConsumer(consumer.id, consumer);

    consumer.on("transportclose", () => {
      consumerPeer.removeConsumer(consumer.id);
    });

    consumer.on("producerclose", () => {
      consumerPeer.removeConsumer(consumer.id);
      this.notification(consumerPeer.socket, "consumerClosed", {
        consumerId: consumer.id,
        kind: consumer.kind,
        peerId: producerPeer.id,
      });
    });

    consumer.on("producerpause", () => {
      this.notification(consumerPeer.socket, "consumerPaused", {
        consumerId: consumer.id,
        peerId: producerPeer.id,
      });
    });

    consumer.on("producerresume", () => {
      this.notification(consumerPeer.socket, "consumerResumed", {
        consumerId: consumer.id,
        peerId: producerPeer.id,
      });
    });

    try {
      consumerPeer.request("newConsumer", {
        peerId: producerPeer.id,
        kind: producer.kind,
        producerId: producer.id,
        id: consumer.id,
        rtpParameters: consumer.rtpParameters,
        type: consumer.type,
        appData: producer.appData,
        producerPaused: consumer.producerPaused,
      });

      if (producer.kind === "video") {
        await consumer.resume();
      }
    } catch (error) {
      logger.warn('_createConsumer() | [error:"%o"]', error);
    }
  }

  /**
   * // TODO: remove this function
   * @deprecated use the notification method inside the peer
   * @param socket
   * @param method
   * @param data
   * @param broadcast
   */
  private notification(
    socket: socketIo.Socket,
    method: string,
    data = {},
    broadcast = false
  ) {
    if (broadcast) {
      socket.broadcast.to(this.id).emit("notification", { method, data });
    } else {
      socket.emit("notification", { method, data });
    }
  }
}
