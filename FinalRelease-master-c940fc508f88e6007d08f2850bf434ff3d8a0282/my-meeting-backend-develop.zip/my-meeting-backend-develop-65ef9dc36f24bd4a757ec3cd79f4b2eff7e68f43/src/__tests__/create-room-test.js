/* eslint-disable @typescript-eslint/no-var-requires */
const Client = require("socket.io-client");
const tls = require("../utils/tls").default;
const https = require("https");
const serverConfig = require("../../config/serverConfig").default;
const MediasoupService = require("../services/mediasoup").default;
const configureLog = require("log4js").configure;
const app = require("../app").default;
const {
  Device,
  useSdesMid,
  useAbsSendTime,
  useFIR,
  useNACK,
  usePLI,
  useREMB,
  RTCRtpCodecParameters,
} = require("msc-node");

// utils
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function socketPromise(socket) {
  return function request(method, data = {}) {
    return new Promise((resolve) => {
      socket.emit("request", { method, data }, resolve);
    });
  };
}

async function loadDevice(routerRtpCapabilities) {
  try {
    const device = new Device({
      headerExtensions: {
        video: [useSdesMid(), useAbsSendTime()],
      },
      codecs: {
        video: [
          new RTCRtpCodecParameters({
            mimeType: "video/VP8",
            clockRate: 90000,
            payloadType: 98,
            rtcpFeedback: [useFIR(), useNACK(), usePLI(), useREMB()],
          }),
        ],
      },
    });
    await device.load({ routerRtpCapabilities });
    return device;
  } catch (error) {
    console.error(error);
  }
  return null;
}

async function createTransport(socket, device, isConsumer) {
  const transportData = await socket.request("createWebRtcTransport", {
    forceTcp: false,
    rtpCapabilities: device.rtpCapabilities,
    consuming: isConsumer,
    producing: !isConsumer,
  });
  if (transportData.error) {
    console.log("[Error] Can not get transport data: ", transportData.error);
    return;
  }

  const transport = isConsumer
    ? device.createRecvTransport(transportData)
    : device.createSendTransport(transportData);
  transport.on("connect", ({ dtlsParameters }, callback, errback) => {
    socket
      .request("connectWebRtcTransport", {
        transportId: transportData.id,
        dtlsParameters,
      })
      .then(callback)
      .catch(errback);
  });

  if (!isConsumer) {
    transport.on(
      "produce",
      async ({ kind, rtpParameters, appData }, callback, errback) => {
        try {
          const { id } = await socket.request("produce", {
            transportId: transport.id,
            kind,
            rtpParameters,
            appData,
          });
          callback({ id });
        } catch (err) {
          errback(err);
        }
      }
    );
  }

  transport.on("connectionstatechange", async (state) => {
    switch (state) {
      case "connecting":
        break;
      case "connected": {
        console.log("[Info] Transport connected, receiving...");
        break;
      }
      case "failed":
        console.log("[Error] Transport connect failed...");
        transport.close();
        break;

      default:
        break;
    }
  });
  return transport;
}

describe("create-room-test", () => {
  const serverUrl = serverConfig.serverUrl;
  let mediasoupService,
    httpsServer,
    clientSocket,
    device,
    consumerTransport,
    producerTransport;

  beforeAll(async () => {
    configureLog("./log4js.json");
    httpsServer = https.createServer(tls, app);
    mediasoupService = await MediasoupService.create(httpsServer, app);
    httpsServer.listen(serverConfig.listeningPort, "0.0.0.0");
  });

  afterAll(async () => {
    // TODO: the resources created are not cleaned up completely since jest can't exit properly
    clientSocket.close();
    mediasoupService.cleanUp();
    httpsServer.close();
  });

  test("connect", (done) => {
    clientSocket = new Client(serverUrl, {
      path: "/server",
      transports: ["websocket"],
      query: {
        createRoom: "true",
        displayName: "jest",
        password: "123456",
      },
      reconnection: false,
    });
    clientSocket.on("connect", done);
    clientSocket.on("connect_error", (err) => console.log(err.message));
    clientSocket.request = socketPromise(clientSocket);
  });

  test("get router capabilities", async () => {
    const capData = await clientSocket.request("getRouterRtpCapabilities");
    // TODO: fix the snap shot
    // expect(capData).toMatchSnapshot();
    device = await loadDevice(capData);
    if (!device) throw "Load device failed";
  });

  test("create producer transport", async () => {
    producerTransport = await createTransport(clientSocket, device, false);
    if (!producerTransport) throw "Create producer transport failed";
  });

  test("create consumer transport", async () => {
    consumerTransport = await createTransport(clientSocket, device, true);
    if (!consumerTransport) throw "Create consumer transport failed";
  });

  test("join room", async () => {
    const { peers, role, peerId, roomId } = await clientSocket.request("join", {
      displayName: "jest test",
      platform: "node.js",
      rtpCapabilities: device.rtpCapabilities,
    });
    expect(peers).toStrictEqual([]);
    expect(role).toBe("Host");
  });
});
