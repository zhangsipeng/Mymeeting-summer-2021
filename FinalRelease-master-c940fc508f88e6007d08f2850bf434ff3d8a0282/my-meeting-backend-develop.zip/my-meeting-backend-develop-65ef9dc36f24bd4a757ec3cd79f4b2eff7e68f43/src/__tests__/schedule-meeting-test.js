/* eslint-disable @typescript-eslint/no-var-requires */
const Client = require("socket.io-client");
const tls = require("../utils/tls").default;
const https = require("https");
const serverConfig = require("../../config/serverConfig").default;
const MediasoupService = require("../services/mediasoup").default;
const configureLog = require("log4js").configure;
const app = require("../app").default;
const request = require("supertest");

describe("schedule-meeting-test", () => {
  const serverUrl = serverConfig.serverUrl;
  let mediasoupService,
    httpsServer,
    startTime,
    stopTime,
    password,
    roomId,
    clientSocket;

  beforeAll(async () => {
    configureLog("./log4js.json");
    httpsServer = https.createServer(tls, app);
    mediasoupService = await MediasoupService.create(httpsServer, app);
    httpsServer.listen(serverConfig.listeningPort, "0.0.0.0");
  });

  afterAll(async () => {
    // TODO: the resources created are not cleaned up completely since jest can't exit properly
    mediasoupService.cleanUp();
    httpsServer.close();
  });

  test("send http request", async () => {
    //jest.useFakeTimers();
    startTime = new Date();
    startTime.setMinutes(startTime.getMinutes() + 5);
    stopTime = new Date(startTime);
    stopTime.setMinutes(stopTime.getMinutes() + 2);
    password = 123456;

    const response = await request(app).get("/scheduleAMeeting").query({
      startTime: startTime.toJSON(),
      stopTime: stopTime.toJSON(),
      password: password,
    });
    expect(response.body).toHaveProperty("roomId");
    roomId = response.body.roomId;
  });

  test("join room when startTime has not arrive yet", (done) => {
    clientSocket = new Client(serverUrl, {
      path: "/server",
      transports: ["websocket"],
      query: {
        roomId: "1",
        displayName: "jest peer",
        password: "123456",
      },
      reconnection: false,
    });
    clientSocket.on("connect_error", (err) => {
      expect(err.message).toStrictEqual("房间不存在");
      done();
    });
  });
});
