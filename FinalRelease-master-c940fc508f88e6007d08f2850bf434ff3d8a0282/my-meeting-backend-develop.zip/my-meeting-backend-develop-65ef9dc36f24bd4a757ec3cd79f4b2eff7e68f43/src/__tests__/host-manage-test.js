/* eslint-disable @typescript-eslint/no-var-requires */
const Client = require("socket.io-client");
const tls = require("../utils/tls").default;
const https = require("https");
const serverConfig = require("../../config/serverConfig").default;
const MediasoupService = require("../services/mediasoup").default;
const configureLog = require("log4js").configure;
const app = require("../app").default;
const {
  Device,
  useSdesMid,
  useAbsSendTime,
  useFIR,
  useNACK,
  usePLI,
  useREMB,
  RTCRtpCodecParameters,
} = require("msc-node");
const { createSocket } = require("dgram");

// utils
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function socketPromise(socket) {
  return function request(method, data = {}) {
    return new Promise((resolve) => {
      socket.emit("request", { method, data }, resolve);
    });
  };
}

async function loadDevice(routerRtpCapabilities) {
  try {
    const device = new Device({
      headerExtensions: {
        video: [useSdesMid(), useAbsSendTime()],
      },
      codecs: {
        video: [
          new RTCRtpCodecParameters({
            mimeType: "video/VP8",
            clockRate: 90000,
            payloadType: 98,
            rtcpFeedback: [useFIR(), useNACK(), usePLI(), useREMB()],
          }),
        ],
      },
    });
    await device.load({ routerRtpCapabilities });
    return device;
  } catch (error) {
    console.error(error);
  }
  return null;
}

async function createTransport(socket, device, isConsumer) {
  const transportData = await socket.request("createWebRtcTransport", {
    forceTcp: false,
    rtpCapabilities: device.rtpCapabilities,
    consuming: isConsumer,
    producing: !isConsumer,
  });
  if (transportData.error) {
    console.log("[Error] Can not get transport data: ", transportData.error);
    return;
  }

  const transport = isConsumer
    ? device.createRecvTransport(transportData)
    : device.createSendTransport(transportData);
  transport.on("connect", ({ dtlsParameters }, callback, errback) => {
    socket
      .request("connectWebRtcTransport", {
        transportId: transportData.id,
        dtlsParameters,
      })
      .then(callback)
      .catch(errback);
  });

  if (!isConsumer) {
    transport.on(
      "produce",
      async ({ kind, rtpParameters, appData }, callback, errback) => {
        try {
          const { id } = await socket.request("produce", {
            transportId: transport.id,
            kind,
            rtpParameters,
            appData,
          });
          callback({ id });
        } catch (err) {
          errback(err);
        }
      }
    );
  }

  transport.on("connectionstatechange", async (state) => {
    switch (state) {
      case "connecting":
        break;
      case "connected": {
        console.log("[Info] Transport connected, receiving...");
        break;
      }
      case "failed":
        console.log("[Error] Transport connect failed...");
        transport.close();
        break;

      default:
        break;
    }
  });
  return transport;
}

describe("create-room-test", () => {
  const serverUrl = serverConfig.serverUrl;
  let mediasoupService,
    httpsServer,
    hostSocket,
    hostDevice,
    hostConsumerTransport,
    hostProducerTransport;

  beforeAll(async () => {
    configureLog("./log4js.json");
    httpsServer = https.createServer(tls);
    mediasoupService = await MediasoupService.create(httpsServer, app);
    httpsServer.listen(serverConfig.listeningPort, "0.0.0.0");
  });

  afterAll(async () => {
    // TODO: the resources created are not cleaned up completely since jest can't exit properly
    hostSocket.close();
    mediasoupService.cleanUp();
    httpsServer.close();
  });

  test("create room connect", (done) => {
    hostSocket = new Client(serverUrl, {
      path: "/server",
      transports: ["websocket"],
      query: {
        createRoom: "true",
        displayName: "jest",
        password: "123456",
      },
      reconnection: false,
    });
    hostSocket.on("connect", done);
    hostSocket.on("connect_error", (err) => console.log(err.message));
    hostSocket.request = socketPromise(hostSocket);
  });

  test("host setup", async () => {
    const capData = await hostSocket.request("getRouterRtpCapabilities");
    // TODO: fix the snap shot
    // expect(capData).toMatchSnapshot();
    hostDevice = await loadDevice(capData);
    if (!hostDevice) throw "Load device failed";

    hostProducerTransport = await createTransport(
      hostSocket,
      hostDevice,
      false
    );
    if (!hostProducerTransport) throw "Create producer transport failed";

    hostConsumerTransport = await createTransport(hostSocket, hostDevice, true);
    if (!hostConsumerTransport) throw "Create consumer transport failed";

    const { peers, role, peerId, roomId } = await hostSocket.request("join", {
      displayName: "jest test",
      platform: "node.js",
      rtpCapabilities: hostDevice.rtpCapabilities,
    });
    expect(peers).toStrictEqual([]);
    expect(role).toBe("Host");
    hostRoomId = roomId;
  });

  test("init right", async () => {
    const rights = await hostSocket.request("getRoomRights");
    expect(rights).toStrictEqual({
      audioMuted: false,
      webcamMuted: false,
      screenMuted: false,
    });
  });

  test("mute all webcam", async () => {
    const res = await hostSocket.request("muteAll", { mediaType: "webcam" });
    expect(res).toStrictEqual({ status: "succeed" });
    const rights = await hostSocket.request("getRoomRights");
    expect(rights).toStrictEqual({
      audioMuted: false,
      webcamMuted: true,
      screenMuted: false,
    });
  });

  test("mute all audio", async () => {
    const res = await hostSocket.request("muteAll", { mediaType: "audio" });
    expect(res).toStrictEqual({ status: "succeed" });
    const rights = await hostSocket.request("getRoomRights");
    expect(rights).toStrictEqual({
      audioMuted: true,
      webcamMuted: true,
      screenMuted: false,
    });
  });

  test("mute screen", async () => {
    const res = await hostSocket.request("muteAll", { mediaType: "screen" });
    expect(res).toStrictEqual({ status: "succeed" });
    const rights = await hostSocket.request("getRoomRights");
    expect(rights).toStrictEqual({
      audioMuted: true,
      webcamMuted: true,
      screenMuted: true,
    });
  });

  test("unmute webcam", async () => {
    const res = await hostSocket.request("unmuteAll", { mediaType: "webcam" });
    expect(res).toStrictEqual({ status: "succeed" });
    const rights = await hostSocket.request("getRoomRights");
    expect(rights).toStrictEqual({
      audioMuted: true,
      webcamMuted: false,
      screenMuted: true,
    });
  });

  test("unmute webcam", async () => {
    const res = await hostSocket.request("unmuteAll", { mediaType: "webcam" });
    expect(res).toStrictEqual({ status: "succeed" });
    const rights = await hostSocket.request("getRoomRights");
    expect(rights).toStrictEqual({
      audioMuted: true,
      webcamMuted: false,
      screenMuted: true,
    });
  });

  test("unmute audio", async () => {
    const res = await hostSocket.request("unmuteAll", { mediaType: "audio" });
    expect(res).toStrictEqual({ status: "succeed" });
    const rights = await hostSocket.request("getRoomRights");
    expect(rights).toStrictEqual({
      audioMuted: false,
      webcamMuted: false,
      screenMuted: true,
    });
  });

  test("unmute screen", async () => {
    const res = await hostSocket.request("unmuteAll", { mediaType: "screen" });
    expect(res).toStrictEqual({ status: "succeed" });
    const rights = await hostSocket.request("getRoomRights");
    expect(rights).toStrictEqual({
      audioMuted: false,
      webcamMuted: false,
      screenMuted: false,
    });
  });
});
