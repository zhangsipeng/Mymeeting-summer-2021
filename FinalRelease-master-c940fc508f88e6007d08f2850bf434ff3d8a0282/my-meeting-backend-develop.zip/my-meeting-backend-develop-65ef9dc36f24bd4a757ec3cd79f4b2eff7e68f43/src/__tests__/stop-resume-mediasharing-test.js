/* eslint-disable @typescript-eslint/no-var-requires */
const Client = require("socket.io-client");
const tls = require("../utils/tls").default;
const https = require("https");
const serverConfig = require("../../config/serverConfig").default;
const MediasoupService = require("../services/mediasoup").default;
const configureLog = require("log4js").configure;
const app = require("../app").default;
const { FakeMediaStreamTrack } = require("fake-mediastreamtrack");
const {
  Device,
  useSdesMid,
  useAbsSendTime,
  useFIR,
  useNACK,
  usePLI,
  useREMB,
  RTCRtpCodecParameters,
} = require("msc-node");

// utils
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function socketPromise(socket) {
  return function request(method, data = {}) {
    return new Promise((resolve) => {
      socket.emit("request", { method, data }, resolve);
    });
  };
}

async function loadDevice(routerRtpCapabilities) {
  try {
    const device = new Device({
      headerExtensions: {
        video: [useSdesMid(), useAbsSendTime()],
      },
      codecs: {
        video: [
          new RTCRtpCodecParameters({
            mimeType: "video/VP8",
            clockRate: 90000,
            payloadType: 98,
            rtcpFeedback: [useFIR(), useNACK(), usePLI(), useREMB()],
          }),
        ],
      },
    });
    await device.load({ routerRtpCapabilities });
    return device;
  } catch (error) {
    console.error(error);
  }
  return null;
}

async function createTransport(socket, device, isConsumer) {
  const transportData = await socket.request("createWebRtcTransport", {
    forceTcp: false,
    rtpCapabilities: device.rtpCapabilities,
    consuming: isConsumer,
    producing: !isConsumer,
  });
  if (transportData.error) {
    console.log("[Error] Can not get transport data: ", transportData.error);
    return;
  }

  const transport = isConsumer
    ? device.createRecvTransport(transportData)
    : device.createSendTransport(transportData);
  transport.on("connect", ({ dtlsParameters }, callback, errback) => {
    socket
      .request("connectWebRtcTransport", {
        transportId: transportData.id,
        dtlsParameters,
      })
      .then(callback)
      .catch(errback);
  });

  if (!isConsumer) {
    transport.on(
      "produce",
      async ({ kind, rtpParameters, appData }, callback, errback) => {
        try {
          const { id } = await socket.request("produce", {
            transportId: transport.id,
            kind,
            rtpParameters,
            appData,
          });
          callback({ id });
        } catch (err) {
          errback(err);
        }
      }
    );
  }

  transport.on("connectionstatechange", async (state) => {
    switch (state) {
      case "connecting":
        break;
      case "connected": {
        console.log("[Info] Transport connected, receiving...");
        break;
      }
      case "failed":
        console.log("[Error] Transport connect failed...");
        transport.close();
        break;

      default:
        break;
    }
  });
  return transport;
}

describe("start-mediaSharing-test", () => {
  const serverUrl = serverConfig.serverUrl;
  let mediasoupService,
    httpsServer,
    hostSocket,
    hostDevice,
    hostConsumerTransport,
    hostProducerTransport,
    hostRoomId,
    peerSocket,
    peerDevice,
    peerId,
    hostId,
    newConsumer,
    newProducer;

  beforeAll(async () => {
    configureLog("./log4js.json");
    httpsServer = https.createServer(tls, app);
    mediasoupService = await MediasoupService.create(httpsServer, app);
    httpsServer.listen(serverConfig.listeningPort, "0.0.0.0");
  });

  afterAll(async () => {
    // TODO: the resources created are not cleaned up completely since jest can't exit properly
    hostSocket.close();
    mediasoupService.cleanUp();
    httpsServer.close();
  });

  test("create room connect", (done) => {
    hostSocket = new Client(serverUrl, {
      path: "/server",
      transports: ["websocket"],
      query: {
        createRoom: "true",
        displayName: "jest",
        password: "123456",
      },
      reconnection: false,
    });
    hostSocket.on("connect", done);
    hostSocket.on("connect_error", (err) => console.log(err.message));
    hostSocket.on("notification", (notification) => {
      switch (notification.method) {
        case "consumerPaused": {
          console.log("consumerPaused !");
          let id = notification.data.consumerId;
          expect(id).toBe(newConsumer.id);
          newConsumer.paused = true;
          break;
        }
        case "consumerResumed": {
          let id = notification.data.consumerId;

          expect(id).toBe(newConsumer.id);
          newConsumer.paused = false;

          break;
        }

        default: {
          // throw "unknown notification method" ;
        }
      }
    });
    hostSocket.on("request", (request) => {
      switch (request.method) {
        case "newConsumer": {
          newConsumer = {
            id: request.data.id,
            producerId: request.data.producerId,
            kind: request.data.kind,
            rtpParameters: request.data.rtpParameters,
            peerId: request.data.peerId,
            paused: false,
          };
          break;
        }
        default: {
          //    throw "Unknown request method"
        }
      }
    });
    hostSocket.request = socketPromise(hostSocket);
  });

  test("host setup", async () => {
    const capData = await hostSocket.request("getRouterRtpCapabilities");
    // TODO: fix the snap shot
    // expect(capData).toMatchSnapshot();
    hostDevice = await loadDevice(capData);
    if (!hostDevice) throw "Load device failed";

    hostProducerTransport = await createTransport(
      hostSocket,
      hostDevice,
      false
    );
    if (!hostProducerTransport) throw "Create producer transport failed";

    hostConsumerTransport = await createTransport(hostSocket, hostDevice, true);
    if (!hostConsumerTransport) throw "Create consumer transport failed";

    const { peers, role, peerId, roomId } = await hostSocket.request("join", {
      displayName: "jest test",
      platform: "node.js",
      rtpCapabilities: hostDevice.rtpCapabilities,
    });
    expect(peers).toStrictEqual([]);
    expect(role).toBe("Host");
    hostRoomId = roomId;
    hostId = peerId;
  });

  test("peer socket connect", (done) => {
    peerSocket = Client(serverUrl, {
      path: "/server",
      transports: ["websocket"],
      query: {
        roomId: hostRoomId,
        displayName: "jest peer",
        password: "123456",
      },
      reconnection: false,
    });
    peerSocket.on("connect", done);
    peerSocket.request = socketPromise(peerSocket);
  });

  test("peer setup", async () => {
    const capData = await peerSocket.request("getRouterRtpCapabilities");
    // TODO: fix the snap shot
    // expect(capData).toMatchSnapshot();
    peerDevice = await loadDevice(capData);
    if (!peerDevice) throw "Load peerDevice failed";

    producerTransport = await createTransport(peerSocket, peerDevice, false);
    if (!producerTransport) throw "Create producer transport failed";

    consumerTransport = await createTransport(peerSocket, peerDevice, true);
    if (!consumerTransport) throw "Create consumer transport failed";

    const {
      peers,
      role,
      peerId: peerId_,
      roomId: peerRoomId,
    } = await peerSocket.request("join", {
      displayName: "jest",
      platform: "node.js",
      rtpCapabilities: peerDevice.rtpCapabilities,
    });
    expect(peerRoomId).toStrictEqual(hostRoomId);
    expect(peers.length).toStrictEqual(1);
    expect(peers[0].displayName).toStrictEqual("jest test");
    expect(role).toBe("Participant");
    peerId = peerId_;
  });

  test("stop sharing webcam", async () => {
    // const stream=await getUserMedia("webcam");
    //     expect(stream).not.toBe(null);
    const track = new FakeMediaStreamTrack({ kind: "video" });
    const params = {
      track,
      appData: { state: "on", type: "webcam", peerId: peerId },
    };
    newProducer = await producerTransport.produce(params);

    const res = await peerSocket.request("pauseProducer", {
      id: newProducer.id,
    });
    newProducer.pause();
    expect(res).toStrictEqual({ state: "success" });
  });

  test("resume sharing webcam", async () => {
    expect(newProducer.appData.type).toStrictEqual("webcam");
    expect(newProducer.paused).toBe(true);
    const res = await peerSocket.request("resumeProducer", { id: "newId" });
    expect(res).toStrictEqual({ state: "success" });
    newProducer.resume();
    expect(newProducer.paused).toBe(false);
  });

  //   test("stop sharing screen",async()=>{
  //       const stream=await getUserMedia("screen");
  //       expect(stream).not.toBe(null);
  //       const track=stream.getVideoTracks()[0];
  //       const params = { track, appData: { state: "on", type:"screen", peerId: peerId } };
  //        newProducer = await producerTransport.produce(params);
  //        expect(newProducer.paused).toBe(false);
  //        const res=await peerSocket.request("pauseProducer",{id:newProducer.id})
  //        expect(res).toStrictEqual({state:"success"})
  //        expect(newConsumer.paused).toBe(true);
  //   })

  //   test("resume sharing screen",async()=>{
  //     expect(newProducer.appData.type).toStrictEqual("screen")
  //     expect(newProducer.paused).toBe(true);
  //     const res=await peerSocket.request("resumerProducer",{id:newProducer.id})
  //     expect(res).toStrictEqual({state:"success"});
  //     expect(newConsumer.paused).toBe(false);
  //   })

  //   test("stop sharing audio",async()=>{
  //       const stream=await getUserMedia("audio");
  //       expect(stream).not.toBe(null);
  //       const track=stream.getAudioTracks()[0];
  //       const params = { track, appData: { state: "on", type:"audio", peerId: peerId } };
  //        newProducer = await producerTransport.produce(params);
  //        expect(newProducer.paused).toBe(false);
  //        const res=await peerSocket.request("pauseProducer",{id:newProducer.id})
  //        expect(res).toStrictEqual({state:"success"})
  //        expect(newConsumer.paused).toBe(true);
  // })

  // test("resume sharing audio",async()=>{
  //   expect(newProducer.appData.type).toStrictEqual("audio")
  //   expect(newProducer.paused).toBe(true);
  //   const res=await peerSocket.request("resumerProducer",{id:newProducer.id})
  //   expect(res).toStrictEqual({state:"success"});
  //   expect(newConsumer.paused).toBe(false);
  // })
});
