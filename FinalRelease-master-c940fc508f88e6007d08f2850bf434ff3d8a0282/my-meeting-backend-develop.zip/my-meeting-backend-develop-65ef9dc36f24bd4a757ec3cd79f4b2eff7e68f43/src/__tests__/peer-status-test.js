/* eslint-disable @typescript-eslint/no-var-requires */
const fetch = require("isomorphic-fetch");
const Client = require("socket.io-client");
const tls = require("../utils/tls").default;
const https = require("https");
const serverConfig = require("../../config/serverConfig").default;
const MediasoupService = require("../services/mediasoup").default;
const configureLog = require("log4js").configure;
const app = require("../app").default;
const { FakeMediaStreamTrack } = require("fake-mediastreamtrack");
const {
  Device,
  useSdesMid,
  useAbsSendTime,
  useFIR,
  useNACK,
  usePLI,
  useREMB,
  RTCRtpCodecParameters,
  MediaStreamTrack,
} = require("msc-node");

const { exec } = require("child_process");
const { createSocket } = require("dgram");

// utils
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function socketPromise(socket) {
  return function request(method, data = {}) {
    return new Promise((resolve) => {
      socket.emit("request", { method, data }, resolve);
    });
  };
}
async function getUserMedia(type) {
  let stream;
  try {
    switch (type) {
      case "screen":
        stream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
        });
        break;
      case "webcam":
        stream = await navigator.mediaDevices.getUserMedia({
          video: true,
        });
        break;
      case "audio":
        stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
        });
        break;
      default:
        break;
    }
  } catch (err) {
    console.error("getUserMedia() failed:", err.message);
    throw err;
  }
  return stream;
}

async function loadDevice(routerRtpCapabilities) {
  try {
    const device = new Device({
      headerExtensions: {
        video: [useSdesMid(), useAbsSendTime()],
      },
      codecs: {
        video: [
          new RTCRtpCodecParameters({
            mimeType: "video/VP8",
            clockRate: 90000,
            payloadType: 98,
            rtcpFeedback: [useFIR(), useNACK(), usePLI(), useREMB()],
          }),
        ],
      },
    });
    await device.load({ routerRtpCapabilities });
    return device;
  } catch (error) {
    console.error(error);
  }
  return null;
}

async function createTransport(socket, device, isConsumer) {
  const transportData = await socket.request("createWebRtcTransport", {
    forceTcp: false,
    rtpCapabilities: device.rtpCapabilities,
    consuming: isConsumer,
    producing: !isConsumer,
  });
  if (transportData.error) {
    console.log("[Error] Can not get transport data: ", transportData.error);
    return;
  }

  const transport = isConsumer
    ? device.createRecvTransport(transportData)
    : device.createSendTransport(transportData);
  transport.on("connect", ({ dtlsParameters }, callback, errback) => {
    socket
      .request("connectWebRtcTransport", {
        transportId: transportData.id,
        dtlsParameters,
      })
      .then(callback)
      .catch(errback);
    // setTimeout(callback);
  });

  if (!isConsumer) {
    transport.on(
      "produce",
      async ({ kind, rtpParameters, appData }, callback, errback) => {
        try {
          const { id } = await socket.request("produce", {
            transportId: transport.id,
            kind,
            rtpParameters,
            appData,
          });
          // id = "newId";
          callback({ id });
        } catch (err) {
          errback(err);
        }
      }
    );
  }

  transport.on("connectionstatechange", async (state) => {
    switch (state) {
      case "connecting":
        break;
      case "connected": {
        console.log("[Info] Transport connected, receiving...");
        break;
      }
      case "failed":
        console.log("[Error] Transport connect failed...");
        transport.close();
        break;

      default:
        break;
    }
  });
  return transport;
}

// before test, please run yarn start to start the backend manually in another terminal
describe("start-mediaSharing-test", () => {
  const serverUrl = serverConfig.serverUrl;
  let mediasoupService,
    httpsServer,
    hostSocket,
    hostDevice,
    hostConsumerTransport,
    hostProducerTransport,
    peerProducerTransport,
    peerConsumerTransport,
    hostRoomId,
    peerSocket,
    peerDevice,
    peerId,
    hostId,
    newConsumer;

  beforeAll(async () => {
    configureLog("./log4js.json");
    httpsServer = https.createServer(tls, app);
    mediasoupService = await MediasoupService.create(httpsServer, app);
    httpsServer.listen(serverConfig.listeningPort, "0.0.0.0");
  });

  afterAll(async () => {
    // TODO: the resources created are not cleaned up completely since jest can't exit properly
    hostSocket.close();
    mediasoupService.cleanUp();
    httpsServer.close();
  });

  test("create room connect", (done) => {
    hostSocket = new Client(serverUrl, {
      path: "/server",
      transports: ["websocket"],
      query: {
        createRoom: "true",
        displayName: "jest",
        password: "123456",
      },
      reconnection: false,
    });
    hostSocket.on("connect", done);
    hostSocket.on("connect_error", (err) => console.log(err.message));
    hostSocket.on("request", async (request) => {
      switch (request.method) {
        case "newConsumer": {
          newConsumer = {
            id: request.data.id,
            producerId: request.data.producerId,
            kind: request.data.kind,
            rtpParameters: request.data.rtpParameters,
            peerId: request.data.peerId,
            paused: false,
          };
          break;
        }
        default: {
          throw "Unknown request method";
        }
      }
    });
    hostSocket.request = socketPromise(hostSocket);
  });

  test("host setup", async () => {
    const capData = await hostSocket.request("getRouterRtpCapabilities");
    // TODO: fix the snap shot
    // expect(capData).toMatchSnapshot();
    hostDevice = await loadDevice(capData);
    if (!hostDevice) throw "Load device failed";

    hostProducerTransport = await createTransport(
      hostSocket,
      hostDevice,
      false
    );
    if (!hostProducerTransport) throw "Create producer transport failed";

    hostConsumerTransport = await createTransport(hostSocket, hostDevice, true);
    if (!hostConsumerTransport) throw "Create consumer transport failed";

    const { peers, role, peerId, roomId } = await hostSocket.request("join", {
      displayName: "jest test",
      platform: "node.js",
      rtpCapabilities: hostDevice.rtpCapabilities,
    });
    expect(peers).toStrictEqual([]);
    expect(role).toBe("Host");
    hostRoomId = roomId;
  });

  test("peer socket connect", (done) => {
    peerSocket = Client(serverUrl, {
      path: "/server",
      transports: ["websocket"],
      query: {
        roomId: hostRoomId,
        displayName: "jest peer",
        password: "123456",
      },
      reconnection: false,
    });
    peerSocket.on("connect", done);
    peerSocket.request = socketPromise(peerSocket);
  });

  test("peer setup", async () => {
    const capData = await peerSocket.request("getRouterRtpCapabilities");
    // TODO: fix the snap shot
    // expect(capData).toMatchSnapshot();
    peerDevice = await loadDevice(capData);
    if (!peerDevice) throw "Load peerDevice failed";

    peerProducerTransport = await createTransport(
      peerSocket,
      peerDevice,
      false
    );
    if (!peerProducerTransport) throw "Create producer transport failed";

    peerConsumerTransport = await createTransport(peerSocket, peerDevice, true);
    if (!peerConsumerTransport) throw "Create consumer transport failed";

    const {
      peers,
      role,
      peerId: peerId_,
      roomId: peerRoomId,
    } = await peerSocket.request("join", {
      displayName: "jest",
      platform: "node.js",
      rtpCapabilities: peerDevice.rtpCapabilities,
    });
    expect(peerRoomId).toStrictEqual(hostRoomId);
    expect(peers.length).toStrictEqual(1);
    expect(peers[0].displayName).toStrictEqual("jest test");
    expect(role).toBe("Participant");
    peerId = peerId_;
  });

  test("peer schedule meeting", async () => {
    //  let res=await fetch("https://www.baidu.com")
    let res = await fetch(
      serverConfig.serverUrl +
        "scheduleAMeeting?startTime=2020-12-2&endTime=2020-12-3&password=123"
    );
    //  .then(
    //      function(response){response=>response.json})
    //  .catch(function(err){
    //      throw err;
    //  })
    expect(res.status).toBe(200);

    //     let httpRequest = new XMLHttpRequest();
    //     httpRequest.open('GET', "https://123.60.6.61/scheduleAMeeting?startTime=2020年12月1日&endTime=2020年12月2日&password=123", true);//第二步：打开连接  将请求参数写在url中
    //     httpRequest.send();

    //     httpRequest.onreadystatechange = function () {
    //         if (httpRequest.readyState == 4 && httpRequest.status == 200) {
    //             done();

    //         }
    //         else{
    //             throw "bad request"
    //         }
    //     };
  });

  test("get upload url", async () => {
    let res = await fetch(serverConfig.serverUrl + "uploadUrl");
    expect(res.json.url).not.toBe(null);
  });

  test("get download url", async () => {
    let res = await fetch(serverConfig.serverUrl + "uploadUrl");
    expect(res.json.url).not.toBe(null);
  });
});
