import serverConfig from "../../config/serverConfig";
import fs from "fs";
import { getLogger } from "log4js";

const logger = getLogger("Server");

const certFile = serverConfig.tls.cert;
const keyFile = serverConfig.tls.key;
const caFile = serverConfig.tls.ca;
// check ssl
[certFile, keyFile, caFile].forEach((file) => {
  if (!fs.existsSync(file)) {
    logger.error("%s do not exist!", file);
    process.exit(-1);
  }
});

const tls = {
  cert: fs.readFileSync(certFile),
  key: fs.readFileSync(keyFile),
  ca: fs.readFileSync(caFile),
};

export default tls;
