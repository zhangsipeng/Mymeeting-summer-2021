import https from "https";
import { configure } from "log4js";
import serverConfig from "../config/serverConfig";
import app from "./app";
import MediasoupService from "./services/mediasoup";
import tls from "./utils/tls";

// logging
configure("./log4js.json");

// create server
const httpsServer = https.createServer(tls, app);

// Run socketIo and mediasoup
MediasoupService.create(httpsServer, app);

httpsServer.listen(serverConfig.listeningPort, "0.0.0.0");
