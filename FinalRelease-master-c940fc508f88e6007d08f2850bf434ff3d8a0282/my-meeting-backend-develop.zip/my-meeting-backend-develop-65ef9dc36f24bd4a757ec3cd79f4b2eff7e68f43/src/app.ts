import compression from "compression";
import cors from "cors";
import express from "express";
import * as helmet from "helmet";
import morgan from "morgan";
import setupMinIo from "./services/minIo";
import MetricsService from "./services/metrics";

process.title = "my-meeting";

// server configuration
const app = express();
// compress all responses
app.use(compression());
// HTTP request logger
app.use(morgan("dev"));
// set http headers
app.use(helmet.hsts());
// parse request
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// cors support
app.use(cors());

app.get("/", (req, res) => {
  res.status(200).send({ res: "Welcome to my meeting backend" });
});

setupMinIo(app);

(global as any).metrics = new MetricsService(app);

export default app;
