type ClientRequestType = {
  method: string;
  data: any;
};

type MediaType = "audio" | "webcam" | "screen";
