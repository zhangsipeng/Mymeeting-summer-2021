# my-meeting-backend

## dockerize

build image: `docker build . -t team15/my-meeting-backend`

run: `docker run -it --network host team15/my-meeting-backend`

## test

run: `jest --forceExit -i --silent`
