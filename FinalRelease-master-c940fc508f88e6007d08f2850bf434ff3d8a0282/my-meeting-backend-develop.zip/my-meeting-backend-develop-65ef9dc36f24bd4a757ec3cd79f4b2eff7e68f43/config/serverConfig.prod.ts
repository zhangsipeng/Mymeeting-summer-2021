export const serverConfig = {
  listeningPort: 10000,
  listeningRedirectPort: 10100,

  worker: {
    logLevel: "warn",
    rtcMinPort: 40000,
    rtcMaxPort: 49999,
  },

  minIo: {
    accessKey: process.env.MINIO_ACCESS_KEY || "",
    secretKey: process.env.MINIO_SECRET_KEY || "",
    endPoint: "www.mymeeting.cf",
    port: 9000,
  },

  redis: {
    ip: "redis-master.default.svc.cluster.local",
    port: 6379,
    password: process.env.REDIS_PASSWORD || "",
  },

  webRtcTransport: {
    listenIps: [
      {
        ip: "0.0.0.0",
        announcedIp: "123.60.6.61",
      },
    ],
  },

  roomStatusInterval: 20, // seconds

  tls: {
    cert: "/etc/ssl/certificate.crt",
    key: "/etc/ssl/private.key",
    ca: "/etc/ssl/ca_bundle.crt",
  },

  serverUrl: "https://www.mymeeting.cf:10000/",
};
export default serverConfig;
