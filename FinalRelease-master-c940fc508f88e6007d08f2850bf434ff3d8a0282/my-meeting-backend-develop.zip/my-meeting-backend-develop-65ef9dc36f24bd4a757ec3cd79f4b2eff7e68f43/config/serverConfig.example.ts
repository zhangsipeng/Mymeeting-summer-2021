export const serverConfig = {
  listeningPort: 10000,
  listeningRedirectPort: 10100,

  worker: {
    logLevel: "warn",
    rtcMinPort: 40000,
    rtcMaxPort: 49999,
  },

  minIo: {
    accessKey: "********",
    secretKey: "********",
    endPoint: "********",
    port: 10101,
  },

  redis: {
    ip: "********",
    port: 6379,
    password: "********",
  },

  webRtcTransport: {
    listenIps: [
      {
        ip: "0.0.0.0",
        announcedIp: "your.ip",
      },
    ],
  },

  roomStatusInterval: 20, // seconds

  tls: {
    cert: "./ssl/certificate.crt",
    key: "./ssl/private.key",
    ca: "./ssl/ca_bundle.crt",
  },

  serverUrl: "https://your.domain:10000/",
};
export default serverConfig;
